#ifndef CDEFS_H_
#define CDEFS_H_

#define GROUP_ID_EIG_GR (0)
#define GROUP_ID_EIG_ALU (1)
#define GROUP_ID_EIG_ALU16 (2)
#define GROUP_ID_EIG_LS (3)
#define GROUP_ID_EIG_LS16 (4)
#define GROUP_ID_EIG_BR (5)
#define GROUP_ID_EIG_BR16 (6)
#define GROUP_ID_EIG_J (7)
#define GROUP_ID_EIG_J16 (8)

#endif /*CDEFS_H_*/
