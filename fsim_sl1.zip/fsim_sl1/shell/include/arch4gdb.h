#ifndef SLARCH_H_
#define SLARCH_H_

#include "defs.h"

/* All the possible SL ABIs. */
enum sl_abi {
	SL_ABI_AUTO = 0,
	SL_ABI_B32 = 1,
	SL_ABI_V32 = 2,
};

class SLArch {
	private:
	
	enum sl_abi _abi;
	INT _numGPRs;
	INT _numCRs;
	INT _numSRs;
	INT _numSIMDRs;
	INT _numRegs;
	INT _cr0Idx;
	INT _sr0Idx;
	INT _rf0Idx;
	INT _pcIdx;
	INT _spIdx;
	INT _jaIdx;
	INT _raIdx;
	char ** _regNames;
	
	public:
	
	SLArch(void);
	SLArch(enum sl_abi abi);
		
	enum sl_abi getAbi(void);
	INT		getNumRegs(void);
	INT		getNumGPRs(void);
	INT		getNumCRs(void);
	INT		getNumSRs(void);
	INT		getNumSIMDRs(void);
	INT		getCR0Idx(void);
	INT		getSR0Idx(void);
	INT		getRF0Idx(void);
	INT		getPCIdx(void);
	INT		getSPIdx(void);
	INT		getJAIdx(void);
	INT		getRAIdx(void);
	char **	getRegNames(void);
	INT		getRegSize (INT regNum);
	char *	getRegName (INT regNum);
	
	void	setAbi(enum sl_abi abi);
};

#endif /*SLARCH_H_*/
