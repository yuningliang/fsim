#include "sl1shell.h"
#include "regdefs.h"

SL1Shell::SL1Shell() : Shell<SL1_CLASS_LIST>() {
	_profiler = new Profiler<SL1Instr, SL1Machine> (_status, _machine, EIG_max);
	_gdbServer = new GDBServer<SL1MMU, SL1Machine> ((CoreMMU&)_mmu, _machine);
	machine().profiler(_profiler);
	for(INT i = 0; i<MAX_MEM_VIEW; i++) {
		SL1Register* reg = new SL1Register(status(), i);
		SL1Exec* exec = new SL1Exec((SL1MMU&)mmu(), *reg, status());
		SL1Disasm* dis = new SL1Disasm((SL1MMU&)mmu(), *reg, i);
		machine().setThread(exec, dis, (SL1THREAD)i);
	}
	mmu().curthread(THREAD_ID_CORE);	
	mmu().cBufAddrReg(REGS_ADDR_CIRBUF0_BEGIN, REGS_ADDR_CIRBUF0_END, 0);
	mmu().cBufAddrReg(REGS_ADDR_CIRBUF1_BEGIN, REGS_ADDR_CIRBUF1_END, 1);
	mmu().registerMemoryRange(RANGE_IDX_SRAM, CORE_DARAM_BASE, CORE_DARAM_SPACE, FALSE);

	mmu().curthread(THREAD_ID_BB);
	mmu().cBufAddrReg(REGS_ADDR_CIRBUF0_BEGIN, REGS_ADDR_CIRBUF0_END, 0);
	mmu().cBufAddrReg(REGS_ADDR_CIRBUF1_BEGIN, REGS_ADDR_CIRBUF1_END, 1);
	mmu().registerMemoryRange(RANGE_IDX_SRAM, DSP_DARAM_BASE, DSP_DARAM_SPACE, FALSE);

#if _WARN_LAYOUT

#endif	
	machine().curthread(THREAD_ID_CORE);
	mmu().curthread(THREAD_ID_CORE);	
}
