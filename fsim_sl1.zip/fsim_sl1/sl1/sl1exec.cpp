#include "sl1exec.h"

SL1Exec::SL1Exec(SL1MMU& mmu, SL1Register& reg, ProcessStatus<SL1Instr>& status) : 
						CoreExec<SL1MMU, SL1Register, SL1Instr>(mmu, reg, status),
						_ffe(*(new SL1FFE(mmu))),_viterbi(*(new SL1VITERBI(mmu)))
						,_traceback(*(new SL1TRACEBACK(mmu))) {
	
}


ADDR SL1Exec::execC3bitc (SL1Instr* instr) {
	UINT uimm = instr->imm5() & 0x1f;
	WORD dest = reg().getSPEC(instr->sd());
	switch(instr->b_mode()){
		case CLEAR:
		   dest = dest & (~(0x0001<<uimm));
		   break;		    
		case SET:
		   dest = dest | (0x0001<<uimm);
		   break;
		case INVERT:
		   dest = dest ^ (0x0001<<uimm);
		   break;
		case NOP:
		   break;
		default:
		  AppFatal((0), ("c3bitc: invalid b_mode(%d),pc@0x%x", instr->b_mode(), pc()));
	}
	reg().setSPEC(instr->sd(),dest);
	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3bitr (SL1Instr* instr) {
	UINT uimm = instr->imm5() & 0x1f;
	WORD dest = reg().getGPR(instr->rs1());
	switch(instr->b_mode()){
		case CLEAR:
		   dest = dest & (~(0x0001<<uimm));
		   break;		    
		case SET:
		   dest = dest | (0x0001<<uimm);
		   break;
		case INVERT:
		   dest = dest ^ (0x0001<<uimm);
		   break;
		case NOP:
		   break;
		default:
		AppFatal((0), ("c3bitr: invalid b_mode(%d),pc@0x%x", instr->b_mode(), pc()));
	}
	reg().setGPR(instr->rd(),dest);
	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3dadd (SL1Instr* instr) {
	WORD src1 = reg().getGPR(instr->rs1());
	WORD src2 = reg().getGPR(instr->rs2());
	WORD data0 = (src1<<16)>>16;
	WORD data1 = (src2<<16)>>16;
	WORD data2 =  src1>>16;
	WORD data3 =  src2>>16;
	WORD destlo = data0+data1;
	WORD desthi = data2+data3;
	
	destlo = _saturateGPR16(destlo);
	desthi = _saturateGPR16(desthi);
    WORD dest = (destlo & HWORD_DATA_MASK) | (desthi<<16);
	reg().setGPR(instr->rd(),dest);
	return pc()+instr->instrsize(); 
}

ADDR SL1Exec::execC3dmac (SL1Instr* instr) {
   AppFatal((instr->acc()%2 ==0 ), ("c3.dmac: acc's index is not even ,pc@0x%x", pc()));
   WORD src1 = reg().getGPR(instr->rs1());
   WORD src2 = reg().getGPR(instr->rs2());
   
   WORD data0 = (src1<<16)>>16;
   WORD data1 = (src2<<16)>>16;
   WORD data2 =  src1>>16;
   WORD data3 =  src2>>16; 
   DWORD dest = reg().getACC(instr->acc());
   DWORD dest1 = reg().getACC(instr->acc()+1);
   
   if(instr->acm() & SRC_SHF){
   		dest += ((DWORD)data0 * data1)<<1;
   		dest1+= ((DWORD)data2 * data3)<<1;
   }
   else{
     	dest += (DWORD)data0 * data1;
   		dest1+= (DWORD)data2 * data3;
   }
   dest = _calAccResult(dest,instr->acm());
   dest1 = _calAccResult(dest1,instr->acm());
   reg().setACC(instr->acc(),dest);
   reg().setACC(instr->acc()+1,dest1);
   return pc()+instr->instrsize();	
}

ADDR SL1Exec::execC3dmaca (SL1Instr* instr) {
	AppFatal((instr->acc()%2 ==0 ), ("c3.dmac.a: acc's index is not even ,pc@0x%x", pc()))
	AppFatal((instr->as1() != instr->as2()), ("c3.dmac.a: as1's index and as2's index is same ,pc@0x%x", pc()));
	ADDR ad1 = reg().getAR(instr->as1());
	ADDR ad2 = reg().getAR(instr->as2());
	WORD src1 = mmu().readSRAMWord(ad1,1);
	WORD src2 = mmu().readSRAMWord(ad2,2);
    
    WORD data0 = (src1<<16)>>16; //sign extended
    WORD data1 = (src2<<16)>>16; //sign extended
    WORD data2 = src1>>16;
    WORD data3 = src2>>16;
    
	DWORD dest = reg().getACC(instr->acc());
	DWORD dest1 = reg().getACC(instr->acc()+1);
	
	LOG_EXTMETA("ar1", ad1)
	LOG_EXTMETA("ar2", ad2)
	
	if(instr->acm() & SRC_SHF){
   		dest += ((DWORD)data0 * data1)<<1;
   		dest1+= ((DWORD)data2 * data3)<<1;
   	}
   	else{
     	dest += (DWORD)data0 * data1;
   		dest1+= (DWORD)data2 * data3;
   	}
   	dest = _calAccResult(dest,instr->acm());
   	dest1 = _calAccResult(dest1,instr->acm());
	reg().setACC(instr->acc(),dest);
   	reg().setACC(instr->acc()+1,dest1);
	
	_updateSize(instr->as1(),instr->am1(),instr->bsel(),WORDLENGTH,ARONE);
	_updateSize(instr->as2(),instr->am2(),instr->bsel(),WORDLENGTH,ARTWO);
	return pc()+instr->instrsize();	
}

ADDR SL1Exec::execC3dmacn (SL1Instr* instr) {
   AppFatal((instr->acc()%2 ==0 ), ("c3.dmacn: acc's index is not even ,pc@0x%x", pc()))	
   WORD src1 = reg().getGPR(instr->rs1());
   WORD src2 = reg().getGPR(instr->rs2());
   WORD data0 = (src1<<16)>>16;
   WORD data1 = (src2<<16)>>16;
   WORD data2 =  src1>>16;
   WORD data3 =  src2>>16; 
   DWORD dest = reg().getACC(instr->acc());
   DWORD dest1 = reg().getACC(instr->acc()+1);
   if(instr->acm() & SRC_SHF){
   		dest -= ((DWORD)data0 * data1)<<1;
   		dest1-= ((DWORD)data2 * data3)<<1;
   }
   else{
     	dest -= (DWORD)data0 * data1;
   		dest1-= (DWORD)data2 * data3;
   }
   dest = _calAccResult(dest,instr->acm());
   dest1 = _calAccResult(dest1,instr->acm());
   reg().setACC(instr->acc(),dest);
   reg().setACC(instr->acc()+1,dest1);
   return pc()+instr->instrsize();	
}

ADDR SL1Exec::execC3dmacna (SL1Instr* instr) {
	AppFatal((instr->acc()%2 ==0 ), ("c3.dmacn.a: acc's index is not even ,pc@0x%x", pc()))
	AppFatal((instr->as1() != instr->as2()), ("c3.dmacn.a: as1's index and as2's index is same ,pc@0x%x", pc()));
	ADDR ad1 = reg().getAR(instr->as1());
	ADDR ad2 = reg().getAR(instr->as2());
	WORD src1 = mmu().readSRAMWord(ad1,1);
	WORD src2 = mmu().readSRAMWord(ad2,2);
    
    WORD data0 = (src1<<16)>>16; //sign extended
    WORD data1 = (src2<<16)>>16; //sign extended
    WORD data2 = src1>>16;
    WORD data3 = src2>>16;
    
	DWORD dest = reg().getACC(instr->acc());
	DWORD dest1 = reg().getACC(instr->acc()+1);

	LOG_EXTMETA("ar1", ad1)
	LOG_EXTMETA("ar2", ad2)
	
	if(instr->acm() & SRC_SHF){
   		dest -= ((DWORD)data0 * data1)<<1;
   		dest1-= ((DWORD)data2 * data3)<<1;
   	}
   	else{
     	dest -= (DWORD)data0 * data1;
   		dest1-= (DWORD)data2 * data3;
   	}
   	dest = _calAccResult(dest,instr->acm());
   	dest1 = _calAccResult(dest1,instr->acm());
	reg().setACC(instr->acc(),dest);
   	reg().setACC(instr->acc()+1,dest1);
	
	_updateSize(instr->as1(),instr->am1(),instr->bsel(),WORDLENGTH,ARONE);
	_updateSize(instr->as2(),instr->am2(),instr->bsel(),WORDLENGTH,ARTWO);
	return pc()+instr->instrsize();	
}

ADDR SL1Exec::execC3dmula (SL1Instr* instr) {
	AppFatal((instr->acc()%2 ==0 ), ("c3.dmula: acc's index is not even ,pc@0x%x", pc()))
	WORD src1 = reg().getGPR(instr->rs1());
   	WORD src2 = reg().getGPR(instr->rs2());
   	WORD data0 = (src1<<16)>>16;
   	WORD data1 = (src2<<16)>>16;
   	WORD data2 =  src1>>16;
   	WORD data3 =  src2>>16; 
   	DWORD dest,dest1;
   	if(instr->acm() & SRC_SHF){
   		dest = ((DWORD)data0 * data1)<<1;
   		dest1= ((DWORD)data2 * data3)<<1;
   	}
   	else{
     	dest = (DWORD)data0 * data1;
   		dest1= (DWORD)data2 * data3;
   	}
   	dest = _calAccResult(dest,instr->acm());
   	dest1 = _calAccResult(dest1,instr->acm());
	reg().setACC(instr->acc(),dest);
   	reg().setACC(instr->acc()+1,dest1);
	return pc()+instr->instrsize();	 
}

ADDR SL1Exec::execC3dmulaa (SL1Instr* instr) {
	AppFatal((instr->acc()%2 ==0 ), ("c3.dmula.a: acc's index is not even ,pc@0x%x", pc()))
	AppFatal((instr->as1() != instr->as2()), ("c3.dmula.a: as1's index and as2's index is same ,pc@0x%x", pc()));
	ADDR ad1 = reg().getAR(instr->as1());
	ADDR ad2 = reg().getAR(instr->as2());
	WORD src1 = mmu().readSRAMWord(ad1,1);
	WORD src2 = mmu().readSRAMWord(ad2,2);
    
    WORD data0 = (src1<<16)>>16; //sign extended
    WORD data1 = (src2<<16)>>16; //sign extended
    WORD data2 = src1>>16;
    WORD data3 = src2>>16;
    
	DWORD dest = reg().getACC(instr->acc());
	DWORD dest1 = reg().getACC(instr->acc()+1);

	LOG_EXTMETA("ar1", ad1)
	LOG_EXTMETA("ar2", ad2)
	
	if(instr->acm() & SRC_SHF){
   		dest = ((DWORD)data0 * data1)<<1;
   		dest1= ((DWORD)data2 * data3)<<1;
   	}
   	else{
     	dest = (DWORD)data0 * data1;
   		dest1= (DWORD)data2 * data3;
   	}
   	dest = _calAccResult(dest,instr->acm());
   	dest1 = _calAccResult(dest1,instr->acm());
	reg().setACC(instr->acc(),dest);
   	reg().setACC(instr->acc()+1,dest1);
	
	_updateSize(instr->as1(),instr->am1(),instr->bsel(),WORDLENGTH,ARONE);
	_updateSize(instr->as2(),instr->am2(),instr->bsel(),WORDLENGTH,ARTWO);
	return pc()+instr->instrsize();	
}

ADDR SL1Exec::execC3dmulan (SL1Instr* instr) {
	AppFatal((instr->acc()%2 ==0 ), ("c3.dmulan: acc's index is not even ,pc@0x%x", pc()))
	WORD src1 = reg().getGPR(instr->rs1());
   	WORD src2 = reg().getGPR(instr->rs2());
    WORD data0 = (src1<<16)>>16;
  	WORD data1 = (src2<<16)>>16;
   	WORD data2 =  src1>>16;
   	WORD data3 =  src2>>16; 
   	DWORD dest,dest1;
   	if(instr->acm() & SRC_SHF){
   		dest = -((DWORD)data0 * data1)<<1;
   		dest1= -((DWORD)data2 * data3)<<1;
   	}
   	else{
     	dest = -(DWORD)data0 * data1;
   		dest1= -(DWORD)data2 * data3;
   	}
   	dest = _calAccResult(dest,instr->acm());
   	dest1 = _calAccResult(dest1,instr->acm());
	reg().setACC(instr->acc(),dest);
   	reg().setACC(instr->acc()+1,dest1);
	return pc()+instr->instrsize();	 
}

ADDR SL1Exec::execC3dmulana (SL1Instr* instr) {
	AppFatal((instr->acc()%2 ==0 ), ("c3.dmulan.a: acc's index is not even ,pc@0x%x", pc()))
	AppFatal((instr->as1() != instr->as2()), ("c3.dmulan.a: as1's index and as2's index is same ,pc@0x%x", pc()));
	ADDR ad1 = reg().getAR(instr->as1());
	ADDR ad2 = reg().getAR(instr->as2());
	WORD src1 = mmu().readSRAMWord(ad1,1);
	WORD src2 = mmu().readSRAMWord(ad2,2);
    
    WORD data0 = (src1<<16)>>16; //sign extended
    WORD data1 = (src2<<16)>>16; //sign extended
    WORD data2 = src1>>16;
    WORD data3 = src2>>16;
    
	DWORD dest = reg().getACC(instr->acc());
	DWORD dest1 = reg().getACC(instr->acc()+1);

	LOG_EXTMETA("ar1", ad1)
	LOG_EXTMETA("ar2", ad2)
	
	if(instr->acm() & SRC_SHF){
   		dest = -((DWORD)data0 * data1)<<1;
   		dest1= -((DWORD)data2 * data3)<<1;
   	}
   	else{
     	dest = -(DWORD)data0 * data1;
   		dest1= -(DWORD)data2 * data3;
   	}
   	dest = _calAccResult(dest,instr->acm());
   	dest1 = _calAccResult(dest1,instr->acm());
	reg().setACC(instr->acc(),dest);
   	reg().setACC(instr->acc()+1,dest1);
	
	_updateSize(instr->as1(),instr->am1(),instr->bsel(),WORDLENGTH,ARONE);
	_updateSize(instr->as2(),instr->am2(),instr->bsel(),WORDLENGTH,ARTWO);
	return pc()+instr->instrsize();	
}

ADDR SL1Exec::execC3dshlli (SL1Instr* instr) {
	WORD src1 = reg().getGPR(instr->rs1());
	WORD result;
	WORD data0 = src1 & HWORD_DATA_MASK;
	WORD data1 = (src1 & UPPER_HWORD_DATA_MASK)>>INT16_BIT;
	printf("%d,%d\n",data0,data1);
	data0 = (data0 << (instr->imm_lo()&0xf))&HWORD_DATA_MASK;
	data1 = (data1 << (instr->imm_hi()&0xf))&HWORD_DATA_MASK;
	result = (data1<<INT16_BIT) | data0;
	reg().setGPR(instr->rd(),result);
	 return pc()+instr->instrsize();	
}

ADDR SL1Exec::execC3dshrli (SL1Instr* instr) {
	WORD src1 = reg().getGPR(instr->rs1());
	WORD result;
	WORD data0 = src1 & HWORD_DATA_MASK;
	WORD data1 = (src1 & UPPER_HWORD_DATA_MASK)>>INT16_BIT;
	data0 = (data0 >> (instr->imm_lo()&0xf))&HWORD_DATA_MASK;
	data1 = (data1 >> (instr->imm_hi()&0xf))&HWORD_DATA_MASK;
	result = (data1<<INT16_BIT) | data0;
	reg().setGPR(instr->rd(),result);	
	 return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3dsub (SL1Instr* instr) {
	WORD src1 = reg().getGPR(instr->rs1());
	WORD src2 = reg().getGPR(instr->rs2());
	WORD data0 = (src1<<16)>>16;
	WORD data1 = (src2<<16)>>16;
	WORD data2 =  src1>>16;
	WORD data3 =  src2>>16;
	WORD destlo = data0-data1;
	WORD desthi = data2-data3;
    
    destlo = _saturateGPR16(destlo);
	desthi = _saturateGPR16(desthi);
    WORD dest = (destlo & HWORD_DATA_MASK) | (desthi<<16);
	reg().setGPR(instr->rd(),dest);
	return pc()+instr->instrsize();  
}

ADDR SL1Exec::execC3fft (SL1Instr* instr) {
	WORD src1 = reg().getGPR(instr->rs1());
	WORD src2 = reg().getGPR(instr->rs2());
	WORD result = ffe().exec(src1, src2);
	//reg().setGPR(instr->rd(), result);
	reg().setSPEC(instr->sd(),result);
	LOG_FIX((src1&FFTMODEMASK)>>3); //write fft_point and poll_en to meta data
	return pc()+instr->instrsize();  
}

ADDR SL1Exec::execC3viterbi (SL1Instr* instr) {
	WORD src1 = reg().getGPR(instr->rs1());
	WORD src2 = reg().getGPR(instr->rs2());
	WORD result = viterbi().exec(src1,src2);
	//reg().setGPR(instr->rd(), result);
	reg().setSPEC(instr->sd(),result);
	LOG_FIX((src2&VITERBIMODEMASK)>>7); //write poll_en to meta data
	return pc()+instr->instrsize(); 	
}

ADDR SL1Exec::execC3traceback (SL1Instr* instr) {
	WORD src1 = reg().getGPR(instr->rs1());
	WORD src2 = reg().getGPR(instr->rs2());
	WORD result = traceback().exec(src1,src2);
	//reg().setGPR(instr->rd(), result);
	reg().setSPEC(instr->sd(),result);
	LOG_FIX(src2&TRBACKMODEMASK); ////write poll_en to meta data
	return pc()+instr->instrsize(); 	
}

ADDR SL1Exec::execC3ld (SL1Instr* instr) {
	ADDR ad1 = reg().getAR(instr->as1());
	WORD dest;
	INT type;
	switch(instr->dtype()){
		case BYTES:
		   dest = mmu().readByte(ad1);
		   type = 1;
		   break;
		case UBYTES:
		   dest = mmu().readByte(ad1);
		   dest = dest & 0xff;
		   type = 1;
		   break;
		case HALF:
		   dest = mmu().readHword(ad1);
		   type = 2;
		   break;
		case UHALF:
		   dest = mmu().readHword(ad1);
		   dest = dest & 0xffff;
		   type = 2;
		   break;
		case WORDS:
		   dest = mmu().readWord(ad1);
		   type = 4;
		   break;
		default:	
		AppFatal((0), ("c3.ld: invalid dtype(%d),pc@0x%x", instr->dtype(), pc()));	
	}
	reg().setGPR(instr->rd(),dest);
	_updateSize(instr->as1(),instr->am1(),instr->bsel(),type,ARONE);
	return pc()+instr->instrsize();		
}

ADDR SL1Exec::execC3lead (SL1Instr* instr) {
	WORD src1 = reg().getACC(instr->acc());
	WORD temp1=32,temp;
	if(instr->mode()==CNT_ZERO)
	{
		for(UINT i=0;i<32;i++)
		{  
		   temp = src1<<i;
		   if((temp & 0x80000000)!=0)
		   {
		   	 temp1 = i;
		     break;
		   }
		}
	}    
	else if(instr->mode()==CNT_ONE)
	{
		for(UINT i=0;i<32;i++)
		{  
		   temp = src1<<i;
		   if((temp & 0x80000000)==0)
		   {
		   	 temp1 = i;
		     break;
		   }
		}   
		
	}
	else
	    AppFatal((0), ("c3.lead: invalid mode(%d),pc@0x%x", instr->mode(), pc()));
	reg().setGPR(instr->rd(),temp1);
	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3mac (SL1Instr* instr) {
	WORD src1 = reg().getGPR16(instr->rs1());
	WORD src2 = reg().getGPR16(instr->rs2());
	DWORD dest = reg().getACC(instr->acc());
	if(instr->acm() & SRC_SHF)
	   dest += ((DWORD)src1*src2)<<1;
	else	   
	   dest += (DWORD)src1*src2; 
	dest = _calAccResult(dest,instr->acm());
	reg().setACC(instr->acc(),dest);
	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3maca (SL1Instr* instr) {
	AppFatal((instr->as1() != instr->as2()), ("c3.mac.a: as1's index and as2's index is same ,pc@0x%x", pc()));
	ADDR ad1 = reg().getAR(instr->as1());
	ADDR ad2 = reg().getAR(instr->as2());
	WORD src1 = mmu().readSRAMHword(ad1,1);
	WORD src2 = mmu().readSRAMHword(ad2,2);
	DWORD dest = reg().getACC(instr->acc());
	LOG_EXTMETA("ar1", ad1)
	LOG_EXTMETA("ar2", ad2)	
	if(instr->acm() & SRC_SHF)
	   dest += ((DWORD)src1*src2)<<1;
	else
	   dest += ((DWORD)src1*src2);
	dest = _calAccResult(dest,instr->acm());
	reg().setACC(instr->acc(),dest);
	_updateSize(instr->as1(),instr->am1(),instr->bsel(),HALFLENGTH,ARONE);
	_updateSize(instr->as2(),instr->am2(),instr->bsel(),HALFLENGTH,ARTWO);
	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3macar (SL1Instr* instr) {
	ADDR ad1 = reg().getAR(instr->as2());
	WORD src1 = mmu().readSRAMHword(ad1,2);
	WORD src2 = reg().getGPR16(instr->rs1());
	DWORD dest = reg().getACC(instr->acc());
	LOG_EXTMETA("ar2", ad1)
	if(instr->acm() & SRC_SHF)
	   dest += ((DWORD)src1*src2)<<1;
	else
	   dest += ((DWORD)src1*src2);
	dest = _calAccResult(dest,instr->acm());
	reg().setACC(instr->acc(),dest);
	_updateSize(instr->as2(),instr->am2(),instr->bsel(),HALFLENGTH,ARONE);
	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3macci (SL1Instr* instr) {
	WORD src1 = reg().getGPR(instr->rs1());
	WORD src2 = reg().getGPR(instr->rs2());
	
	WORD data0 = (src1<<16)>>16;
	WORD data1 = (src2<<16)>>16;
	WORD data2 =  src1>>16;
	WORD data3 =  src2>>16;
	DWORD dest = reg().getACC(instr->acc()); 
	if(instr->acm() & SRC_SHF)
	   dest += ((data0*data3)<<1)+ ((data2*data1)<<1);
	else
	   dest += data0*data3 + data2*data1;
	dest = _calAccResult(dest,instr->acm());
	reg().setACC(instr->acc(),dest);
	return pc()+instr->instrsize();   
}

ADDR SL1Exec::execC3maccr (SL1Instr* instr) {
	WORD src1 = reg().getGPR(instr->rs1());
	WORD src2 = reg().getGPR(instr->rs2());
	
	WORD data0 = (src1<<16)>>16;
	WORD data1 = (src2<<16)>>16;
	WORD data2 =  src1>>16;
	WORD data3 =  src2>>16;
	
	DWORD dest = reg().getACC(instr->acc()); 
	if(instr->acm() & SRC_SHF)
	   dest += ((data2*data3)<<1) - ((data0*data1)<<1);
	else
	   dest += data2*data3 - data0*data1;
	dest = _calAccResult(dest,instr->acm());
	reg().setACC(instr->acc(),dest);
	//LOG_META(C3_PAIR_REG)
	return pc()+instr->instrsize();   
}

ADDR SL1Exec::execC3macd (SL1Instr* instr) {
	WORD src1 = reg().getGPR(instr->rs1());
	WORD src2 = reg().getGPR(instr->rs2());
	DWORD dest = reg().getACC(instr->acc());
	if(instr->acm() & SRC_SHF)
       dest += ((DWORD)src1*src2)<<1;
    else
       dest += (DWORD)src1*src2;
    dest = _calAccResult(dest,instr->acm() );
	reg().setACC(instr->acc(),dest);
	return pc()+instr->instrsize(); 
}

ADDR SL1Exec::execC3macdn (SL1Instr* instr) {
	WORD src1 = reg().getGPR(instr->rs1());
	WORD src2 = reg().getGPR(instr->rs2());
	DWORD dest = reg().getACC(instr->acc());
	if(instr->acm() & SRC_SHF)
       dest -= ((DWORD)src1*src2)<<1;
    else
       dest -= (DWORD)src1*src2;
    dest = _calAccResult(dest,instr->acm() );
	reg().setACC(instr->acc(),dest);
	return pc()+instr->instrsize(); 
}

ADDR SL1Exec::execC3maci (SL1Instr* instr) {
	WORD src1 = reg().getGPR16(instr->rs1());
	WORD imm10 = instr->imm10();
	DWORD dest = reg().getACC(instr->acc());
	if(instr->acm() & SRC_SHF)
       dest += ((DWORD)src1*imm10)<<1;
    else
       dest += (DWORD)src1*imm10;
    dest = _calAccResult(dest,instr->acm());
	reg().setACC(instr->acc(),dest);
	return pc()+instr->instrsize(); 
}

ADDR SL1Exec::execC3macn (SL1Instr* instr) {
	WORD src1 = reg().getGPR16(instr->rs1());
	WORD src2 = reg().getGPR16(instr->rs2());
	DWORD dest = reg().getACC(instr->acc());
	if(instr->acm() & SRC_SHF)
	   dest -= ((DWORD)src1*src2)<<1;
	else	   
	   dest -= (DWORD)src1*src2;
	dest = _calAccResult(dest,instr->acm());
	reg().setACC(instr->acc(),dest);
	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3macna (SL1Instr* instr) {
	AppFatal((instr->as1() != instr->as2()), ("c3.macn.a: as1's index and as2's index is same ,pc@0x%x", pc()));
	ADDR ad1 = reg().getAR(instr->as1());
	ADDR ad2 = reg().getAR(instr->as2());
	WORD src1 = mmu().readSRAMHword(ad1,1);
	WORD src2 = mmu().readSRAMHword(ad2,2);
	DWORD dest = reg().getACC(instr->acc());
	LOG_EXTMETA("ar1", ad1)
	LOG_EXTMETA("ar2", ad2)	
	if(instr->acm() & SRC_SHF)
	   dest -= ((DWORD)src1*src2)<<1;
	else
	   dest -= (DWORD)src1*src2;
	dest = _calAccResult(dest,instr->acm());
	reg().setACC(instr->acc(),dest);
	_updateSize(instr->as1(),instr->am1(),instr->bsel(),HALFLENGTH,ARONE);
	_updateSize(instr->as2(),instr->am2(),instr->bsel(),HALFLENGTH,ARTWO);
	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3macnar (SL1Instr* instr) {
	ADDR ad1 = reg().getAR(instr->as2());
	WORD src1 = mmu().readSRAMHword(ad1,2);
	WORD src2 = reg().getGPR16(instr->rs1());
	DWORD dest = reg().getACC(instr->acc());
	LOG_EXTMETA("ar2", ad1)
	if(instr->acm() & SRC_SHF)
	   dest -= ((DWORD)src1*src2)<<1;
	else
	   dest -= (DWORD)src1*src2;
	dest = _calAccResult(dest,instr->acm());
	reg().setACC(instr->acc(),dest);
	_updateSize(instr->as2(),instr->am2(),instr->bsel(),HALFLENGTH,ARONE);
	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3macni (SL1Instr* instr) {
	WORD src1 = reg().getGPR16(instr->rs1());
	WORD imm10 = instr->imm10();
	DWORD dest = reg().getACC(instr->acc());
	if(instr->acm() & SRC_SHF)
       dest -= ((DWORD)src1*imm10)<<1;
    else
       dest -= (DWORD)src1*imm10;
    dest = _calAccResult(dest,instr->acm());
	reg().setACC(instr->acc(),dest);
	return pc()+instr->instrsize(); 
}

ADDR SL1Exec::execC3mula (SL1Instr* instr) {
	WORD src1 = reg().getGPR16(instr->rs1());
	WORD src2 = reg().getGPR16(instr->rs2());
	DWORD dest;
	if(instr->acm() & SRC_SHF)
	   dest = ((DWORD)src1*(DWORD)src2)<<1;
	else	   
	   dest = (DWORD)src1*src2;
	dest = _calAccResult(dest,instr->acm());
	reg().setACC(instr->acc(),dest);
	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3mulaa (SL1Instr* instr) {
	AppFatal((instr->as1() != instr->as2()), ("c3.mula.a: as1's index and as2's index is same ,pc@0x%x", pc()));
	ADDR ad1 = reg().getAR(instr->as1());
	ADDR ad2 = reg().getAR(instr->as2());
	WORD src1 = mmu().readSRAMHword(ad1,1);
	WORD src2 = mmu().readSRAMHword(ad2,2);
	DWORD dest;
	LOG_EXTMETA("ar1", ad1)
	LOG_EXTMETA("ar2", ad2)	
	if(instr->acm() & SRC_SHF)
	   dest = ((DWORD)src1*src2)<<1;
	else
	   dest = (src1*src2);
	dest = _calAccResult(dest,instr->acm());
	reg().setACC(instr->acc(),dest);
	_updateSize(instr->as1(),instr->am1(),instr->bsel(),HALFLENGTH,ARONE);
	_updateSize(instr->as2(),instr->am2(),instr->bsel(),HALFLENGTH,ARTWO);
	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3mulaar (SL1Instr* instr) {
	ADDR ad1 = reg().getAR(instr->as2());
	WORD src1 = mmu().readSRAMHword(ad1,2);
	WORD src2 = reg().getGPR16(instr->rs1());
	DWORD dest;
	LOG_EXTMETA("ar2", ad1)
	if(instr->acm() & SRC_SHF)
	   dest = ((DWORD)src1*src2)<<1;
	else
	   dest = (src1*src2);
	dest = _calAccResult(dest,instr->acm());
	reg().setACC(instr->acc(),dest);
	_updateSize(instr->as2(),instr->am2(),instr->bsel(),HALFLENGTH,ARONE);
	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3mulaci (SL1Instr* instr) {
	WORD src1 = reg().getGPR(instr->rs1());
	WORD src2 = reg().getGPR(instr->rs2());
	DWORD dest;
	WORD data0 = (src1<<16)>>16;
	WORD data1 = (src2<<16)>>16;
	WORD data2 =  src1>>16;
	WORD data3 =  src2>>16; 
	if(instr->acm() & SRC_SHF)
	   dest = ((data0*data3)<<1) + ((data1*data2)<<1);
	else
	   dest = data0*data3 + data1*data2;
	dest = _calAccResult(dest,instr->acm());
	reg().setACC(instr->acc(),dest);
	//LOG_META(C3_PAIR_REG)
	return pc()+instr->instrsize();  
}

ADDR SL1Exec::execC3mulacr (SL1Instr* instr) {
	WORD src1 = reg().getGPR(instr->rs1());
	WORD src2 = reg().getGPR(instr->rs2());
	DWORD dest; 
	WORD data0 = (src1<<16)>>16;
	WORD data1 = (src2<<16)>>16;
	WORD data2 =  src1>>16;
	WORD data3 =  src2>>16;
	if(instr->acm() & SRC_SHF)
	   dest = ((data2*data3)<<1)- ((data0*data1)<<1);
	else
	   dest = data2*data3 - data0*data1;
	dest = _calAccResult(dest,instr->acm());
	reg().setACC(instr->acc(),dest);
	//LOG_META(C3_PAIR_REG)
	return pc()+instr->instrsize(); 
}

ADDR SL1Exec::execC3mulad (SL1Instr* instr) {
	WORD src1 = reg().getGPR(instr->rs1());
	WORD src2 = reg().getGPR(instr->rs2());
	DWORD dest;
	UBYTE acm=instr->acm();
	if(instr->acm() & SRC_SHF)
       dest = ((DWORD)src1*src2)<<1;
    else
       dest = (DWORD)src1*src2;
    dest = _calAccResult(dest,acm);
	reg().setACC(instr->acc(),dest);
	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3muladn (SL1Instr* instr) {
	WORD src1 = reg().getGPR(instr->rs1());
	WORD src2 = reg().getGPR(instr->rs2());
	DWORD dest;
	UBYTE acm=instr->acm() & NON_SATURATION_MASK;
	if(instr->acm() & SRC_SHF)
       		dest = -(((DWORD)src1*src2)<<1);
    	else
       		dest = -((DWORD)src1*src2);
    	dest = _calAccResult(dest,acm);
	reg().setACC(instr->acc(), dest);
	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3mulai (SL1Instr* instr) {
    WORD src1 = reg().getGPR16(instr->rs1());
    WORD simm = instr->imm10();
    DWORD dest;
    if(instr->acm() & SRC_SHF)
       dest = ((DWORD)src1*simm)<<1;
    else
       dest = src1*simm;
    dest = _calAccResult(dest,instr->acm());
	reg().setACC(instr->acc(),dest);
	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3mulan (SL1Instr* instr) {
	WORD src1 = reg().getGPR16(instr->rs1());
	WORD src2 = reg().getGPR16(instr->rs2());
	DWORD dest;
	if(instr->acm() & SRC_SHF)
       dest = ((DWORD)src1*src2)<<1;
    else
       dest = src1*src2;
    dest = -dest;
    dest = _calAccResult(dest,instr->acm());
	reg().setACC(instr->acc(),dest);
	return pc()+instr->instrsize();   
}

ADDR SL1Exec::execC3mulha (SL1Instr* instr) {
	AppFatal((instr->as1() != instr->as2()), ("c3.mulha: as1's index and as2's index is same ,pc@0x%x", pc()));
	ADDR ad1 = reg().getAR(instr->as1());
	ADDR ad2 = reg().getAR(instr->as2());
	WORD src1 = mmu().readSRAMHword(ad1,1);
	WORD src2 = mmu().readSRAMHword(ad2,2);
	WORD dest = src1*src2;
	LOG_EXTMETA("ar1", ad1)
	LOG_EXTMETA("ar2", ad2)	
	dest = _saturateGPR16(dest);
	reg().setGPR(instr->rd(),dest);
	return pc()+instr->instrsize();  
}

ADDR SL1Exec::execC3muls (SL1Instr* instr) {
	WORD src1 = reg().getGPR(instr->rs1());
	WORD src2 = reg().getGPR(instr->rs2());
	UWORD imm5 = instr->imm5() & 0x1f;
	DWORD dest = ((DWORD)(src1)*(DWORD)(src2))<<imm5;
	reg().setHI((dest>>32));
	reg().setGPR(instr->rd(),(dest & 0xffffffff));
    return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3mulus (SL1Instr* instr) {
	UWORD src1 = reg().getGPR(instr->rs1());
	UWORD src2 = reg().getGPR(instr->rs2());
	UWORD imm5 = instr->imm5()&0x1f;
	DWORD dest = ((((DWORD)src1)&0xffffffff)*(((DWORD)src2)&0xffffffff))<<imm5;
	reg().setHI((WORD)(dest>>32));
	reg().setGPR(instr->rd(),((WORD)(dest & 0xffffffff)));
    return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3mvfs (SL1Instr* instr) {
	AppFatal((instr->ss1() < ESR_MAX), ("c3.mvfs: invalid control register name(%d),pc@0x%x", instr->cs1(), pc()));
	WORD src1 = reg().getSPEC(instr->ss1());//acc
	UINT uimm = instr->imm5()&0x1f;
	src1 = src1>>uimm;
    reg().setGPR(instr->rd(),src1);   
	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3mvts (SL1Instr* instr) {
	AppFatal((instr->sd() < ESR_MAX), ("c3.mvts: invalid control register name(%d),pc@0x%x", instr->sd(), pc()));
	AppFatal((instr->sd() <= ESR_HI), ("c3.mvts: fobiden control register name(%d),pc@0x%x", instr->sd(), pc()));
	DWORD src1;
	src1 = reg().getGPR(instr->rs1());
	
	UINT uimm = instr->imm5() & 0x1f;
	src1 = src1 << uimm;	
  	reg().setSPEC(instr->sd(),src1);//acc
	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3revb (SL1Instr* instr) {
	WORD src1 = reg().getGPR(instr->rs1());
	UINT uimm = instr->imm4() & 0x1f;
	WORD dest = 0;
	UWORD temp;
	for(UINT i=0;i<=uimm;i++)
	{   
		temp = ((UWORD)src1&(0x1<<i))>>i;
	    dest = (temp<<(uimm-i)) | dest;
	}
	reg().setGPR(instr->rd(),dest);
	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3round (SL1Instr* instr) {
	DWORD src1 = reg().getACC(instr->acc());
	UINT imm5 = instr->imm5()&0x1f;
	src1 = src1<<imm5;
	src1 = src1+0x8000;
	src1 = _calAccResult(src1,SATURATION_MODE);
	switch(instr->mode()){
		case SET_LOW:
		     src1 = src1 | 0xffff;
		     break;
		case CLEAR_LOW:
		     src1 = (src1>>16)<<16;
		     break;
		case NORMAL:
		     break;       
		default:
		     AppFatal((0), ("c3.round: invalid mode(%d),pc@0x%x",instr->mode(), pc()));
	}
	reg().setACC(instr->acc(),src1);
	return pc()+instr->instrsize();	
}

ADDR SL1Exec::execC3saadda (SL1Instr* instr) {
	AppFatal((instr->as1() != instr->as2()), ("c3.saadd.a: as1's index and as2's index is same ,pc@0x%x", pc()));
	ADDR ad1 = reg().getAR(instr->as1());
	ADDR ad2 = reg().getAR(instr->as2());
	WORD src1 = mmu().readSRAMWord(ad1,1);
	WORD src2 = mmu().readSRAMWord(ad2,2);
	DWORD dest = ((DWORD)src1)+src2;
	LOG_EXTMETA("ar1", ad1)
	LOG_EXTMETA("ar2", ad2)	
	dest = _saturateGPR32(dest);
	reg().setGPR(instr->rd(), (WORD)dest);
	_updateSize(instr->as1(),instr->am1(),instr->bsel(),WORDLENGTH,ARONE);
	_updateSize(instr->as2(),instr->am2(),instr->bsel(),WORDLENGTH,ARTWO);
	return pc()+instr->instrsize();  
}

ADDR SL1Exec::execC3saaddha (SL1Instr* instr) {
	AppFatal((instr->as1() != instr->as2()), ("c3.saaddh.a: as1's index and as2's index is same ,pc@0x%x", pc()));
	ADDR ad1 = reg().getAR(instr->as1());
	ADDR ad2 = reg().getAR(instr->as2());
	WORD src1 = mmu().readSRAMHword(ad1,1);
	WORD src2 = mmu().readSRAMHword(ad2,2);
	WORD dest = src1+src2;
	LOG_EXTMETA("ar1", ad1)
	LOG_EXTMETA("ar2", ad2)	
	dest = _saturateGPR16(dest);
	reg().setGPR(instr->rd(),(HWORD)dest);
	_updateSize(instr->as1(),instr->am1(),instr->bsel(),HALFLENGTH,ARONE);
	_updateSize(instr->as2(),instr->am2(),instr->bsel(),HALFLENGTH,ARTWO);
	return pc()+instr->instrsize(); 
}

ADDR SL1Exec::execC3saadds (SL1Instr* instr) {
	WORD src1 = reg().getGPR(instr->rs1());
	WORD src2 = reg().getGPR(instr->rs2());
	UWORD imm5 = instr->imm5() & 0x1f;
	DWORD dest = ((DWORD)(src1)+(DWORD)(src2))<<imm5;
	dest = _saturateGPR32(dest);	
	reg().setGPR(instr->rd(), (WORD)dest);
    	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3saaddsh (SL1Instr* instr) {
	WORD src1 = reg().getGPR16(instr->rs1());
	WORD src2 = reg().getGPR16(instr->rs2());
	UWORD imm5 = instr->imm5() & 0x1f;
	WORD dest = (src1+src2)<<imm5;
	dest = _saturateGPR16(dest);	
	reg().setGPR(instr->rd(), (HWORD)dest);
    	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3saddha (SL1Instr* instr) {
	WORD src1 = reg().getGPR16(instr->rs1());
	UINT uimm = instr->imm4() & 0x0f;
	src1 = src1 << uimm;
	DWORD dest = reg().getACC(instr->acc());	
	if(instr->N())
	   src1 = -src1;
	dest = dest+src1;
	dest = _calAccResult(dest,instr->acm());
	reg().setACC(instr->acc(),dest);
	return pc()+instr->instrsize();	   
}

ADDR SL1Exec::execC3saddhaa (SL1Instr* instr) {
	ADDR ad1 = reg().getAR(instr->as1());
	UINT uimm = instr->imm4() & 0x0f;
	WORD src1 = mmu().readSRAMHword(ad1,1);
	src1 = src1<<uimm;
	DWORD dest = reg().getACC(instr->acc());
	LOG_EXTMETA("ar1", ad1)
	if(instr->N())
	   src1 = -src1;
	dest = dest+src1;
	dest = _calAccResult(dest,instr->acm());
	reg().setACC(instr->acc(),dest);
	_updateSize(instr->as1(),instr->am1(),instr->bsel(),HALFLENGTH,ARONE);
	return pc()+instr->instrsize();	  
}

ADDR SL1Exec::execC3samulha (SL1Instr* instr) {
	AppFatal((instr->as1() != instr->as2()), ("c3.samulh.a: as1's index and as2's index is same ,pc@0x%x", pc()));
	ADDR ad1 = reg().getAR(instr->as1());
	ADDR ad2 = reg().getAR(instr->as2());
	WORD src1 = mmu().readSRAMHword(ad1,1);
	WORD src2 = mmu().readSRAMHword(ad2,2);
	DWORD dest = ((DWORD)src1*src2)<<1;
	LOG_EXTMETA("ar1", ad1)
	LOG_EXTMETA("ar2", ad2)	
	dest = _saturateGPR32(dest) >>16;
	reg().setGPR(instr->rd(),(WORD)dest);
	_updateSize(instr->as1(),instr->am1(),instr->bsel(),HALFLENGTH,ARONE);
	_updateSize(instr->as2(),instr->am2(),instr->bsel(),HALFLENGTH,ARTWO);
	return pc()+instr->instrsize(); 
}

ADDR SL1Exec::execC3samulsh (SL1Instr* instr) {
	WORD src1 = reg().getGPR16(instr->rs1());
	WORD src2 = reg().getGPR16(instr->rs2());
	UWORD imm5 = instr->imm5() & 0x1f;
	DWORD dest = ((DWORD)src1*src2)<<imm5;
	dest = _saturateGPR32(dest)>>16;	
	reg().setGPR(instr->rd(), (WORD)dest);
    	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3sashllh (SL1Instr* instr) {
	WORD src1 = reg().getGPR16(instr->rs1());
	WORD src2 = reg().getGPR16(instr->rs2());
	WORD dest;
	if(src2>15) {
		dest = SATURATION_MAX16;	
	}
	else {
		dest = src1 << src2;
		dest = _saturateGPR16(dest);
	}
	reg().setGPR(instr->rd(), (HWORD)dest);
    	return pc()+instr->instrsize();
}

ADDR SL1Exec::execC3sasuba (SL1Instr* instr) {
	AppFatal((instr->as1() != instr->as2()), ("c3.sasub.a: as1's index and as2's index is same ,pc@0x%x", pc()));
	ADDR ad1 = reg().getAR(instr->as1());
	ADDR ad2 = reg().getAR(instr->as2());
	WORD src1 = mmu().readSRAMWord(ad1,1);
	WORD src2 = mmu().readSRAMWord(ad2,2);
	DWORD dest = ((DWORD)src1)-src2;
	LOG_EXTMETA("ar1", ad1)
	LOG_EXTMETA("ar2", ad2)	
	dest = _saturateGPR32(dest);
	reg().setGPR(instr->rd(), (WORD)dest);
	_updateSize(instr->as1(),instr->am1(),instr->bsel(),WORDLENGTH,ARONE);
	_updateSize(instr->as2(),instr->am2(),instr->bsel(),WORDLENGTH,ARTWO);
	return pc()+instr->instrsize();  

}

ADDR SL1Exec::execC3sasubha (SL1Instr* instr) {
	AppFatal((instr->as1() != instr->as2()), ("c3.sasubh.a: as1's index and as2's index is same ,pc@0x%x", pc()));
	ADDR ad1 = reg().getAR(instr->as1());
	ADDR ad2 = reg().getAR(instr->as2());
	WORD src1 = mmu().readSRAMHword(ad1,1);
	WORD src2 = mmu().readSRAMHword(ad2,2);
	WORD dest = src1-src2;
	LOG_EXTMETA("ar1", ad1)
	LOG_EXTMETA("ar2", ad2)	
	dest = _saturateGPR16(dest);
	reg().setGPR(instr->rd(),(HWORD)dest);
	_updateSize(instr->as1(),instr->am1(),instr->bsel(),HALFLENGTH,ARONE);
	_updateSize(instr->as2(),instr->am2(),instr->bsel(),HALFLENGTH,ARTWO);
	return pc()+instr->instrsize(); 

}

ADDR SL1Exec::execC3sasubs (SL1Instr* instr) {
	WORD src1 = reg().getGPR(instr->rs1());
	WORD src2 = reg().getGPR(instr->rs2());
	UWORD imm5 = instr->imm5() & 0x1f;
	DWORD dest = ((DWORD)(src1)-(DWORD)(src2))<<imm5;
	dest = _saturateGPR32(dest);	
	reg().setGPR(instr->rd(), (WORD)dest);
    	return pc()+instr->instrsize();

}

ADDR SL1Exec::execC3sasubsh (SL1Instr* instr) {
	WORD src1 = reg().getGPR16(instr->rs1());
	WORD src2 = reg().getGPR16(instr->rs2());
	UWORD imm5 = instr->imm5() & 0x1f;
	WORD dest = (src1-src2)<<imm5;
	dest = _saturateGPR16(dest);	
	reg().setGPR(instr->rd(), (HWORD)dest);
    	return pc()+instr->instrsize();

}

ADDR SL1Exec::execC3st (SL1Instr* instr) {
	ADDR ad1 = reg().getAR(instr->as1());
	WORD src1 = reg().getGPR(instr->rs0());
	UINT type;
	LOG_EXTMETA("ar1", ad1)
	switch(instr->dtype()){
		case BYTES:		   
		   mmu().writeByte(ad1,src1);
		   type = 1; 
		   break;	   
		case HALF:		   	   
		   mmu().writeHword(ad1,src1);
		   type = 2;
		   break;
		case WORDS:
		   mmu().writeWord(ad1,src1);
		   type = 4;
		   break;
		default:
		AppFatal((0), ("c3.st: invalid dtype(%d),pc@0x%x", instr->dtype(), pc()));
	}
	_updateSize(instr->as1(),instr->am1(),instr->bsel(),type,ARONE);
	return pc()+instr->instrsize();		
}

