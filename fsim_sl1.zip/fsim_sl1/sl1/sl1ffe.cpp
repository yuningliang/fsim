#include "sl1mmu.h"
#include "sl1ffe.h"

#ifndef _SKIP_FFE
#define _SKIP_FFE 0
#endif

#if _SKIP_FFE

#define seq_cal(i) 0
#define data_convert(data_in, bit_width) 0 
#define bit_convert(data, bit_width, point_pos) 0 
#define fft(points, ifft, real_in, img_in) 0
char symbol_hex[512];

#else

#ifdef __cplusplus
extern "C" {
#endif

extern int seq_cal(int i);
extern float data_convert (int data_in, int bit_width);
extern double bit_convert (double data, int bit_width, int point_pos);
extern int fft (int points, int ifft, double* real_in, double* img_in);
extern char symbol_hex[];

#ifdef __cplusplus
}
#endif

#endif

SL1FFE::SL1FFE(SL1MMU& m) : _mmu(m) {
	_delayWriteEnable = FALSE;
	_writeLogSize = 0;
	_writeLogAddr = NULL;
	_writeLogData = NULL;
	_orgData = NULL;
}

WORD SL1FFE::exec(WORD rs1, WORD rs2) {
	INT32 point;
	WORD ret = 0;
	
	union {
		WORD data;
		struct {
			unsigned offset : 9;
			unsigned dontcare : 4;
			unsigned bank : 3;
			unsigned base : 16;
		} deData;			
	} rs1Data;	
	
	union {
		WORD data;
		struct {
			/*
			unsigned ffe_op : 3;
			unsigned na2 : 3;
			unsigned point : 10;
			unsigned b0 : 3;
			unsigned b1 : 3;
			unsigned b2 : 3;
			unsigned b3 : 3;
			unsigned na1 : 4;
			*/
			unsigned ffe_op : 3;
			unsigned mode: 3;
			unsigned pre_en: 1;
			unsigned post_en: 1;
			unsigned na2:8;
			unsigned b0 : 3;
			unsigned b1 : 3;
			unsigned b2 : 3;
			unsigned b3 : 3;
			unsigned na1: 4;
			
		} deData;			
	} rs2Data;	
	
	rs1Data.data = rs1;
	rs2Data.data = rs2;
	
	/*** To do: decode the ffe opcode ***/
	switch(rs2Data.deData.mode){
		case 0: point = 8192;break;
		case 1: point = 4096;break;
		case 2: point = 2048;break;
		case 3: point = 1024;break;
		case 4: point = 512;break;
		case 5: point = 256;break;
		case 6: point = 128;break;
		default:
		AppFatal((0), ("wrong mode in ffe\n"))
	}	
	
	 double* real_in = new double[point];
	 double* img_in = new double[point];
	 
	 if(_delayWriteEnable==TRUE) {
	 	IsTrue((_writeLogSize==0), ("FFE have been used twice!"));
	 	_writeLogSize = point;
		if(_writeLogAddr!=NULL) {
			delete _writeLogAddr;
		}
		if(_writeLogData!=NULL) {
			delete _writeLogData;
		}
		if(_orgData!=NULL) {
			delete _orgData;
		}		 	
	 	_writeLogAddr = new ADDR[point];
	 	_writeLogData = new WORD[point];
	 	_orgData = new WORD[point];
	 }
	 _readFFTData(
		//rs1Data.deData.point,
		point,
		real_in,
		img_in,
		rs1Data.data,
		rs2Data.deData.b0,
		rs2Data.deData.b1,
		rs2Data.deData.b2,
		rs2Data.deData.b3,
		rs2Data.deData.pre_en
	);
	
	//ret = fft(point, rs1Data.deData.ffe_op, real_in, img_in);
	ret = fft(point,rs2Data.deData.ffe_op,real_in,img_in);

	_writeFFTData(
		//rs1Data.deData.point,
		point,
		ret,
		real_in,
		img_in,
		rs1Data.data,
		rs2Data.deData.b0,
		rs2Data.deData.b1,
		rs2Data.deData.b2,
		rs2Data.deData.b3,
		rs2Data.deData.post_en
	);
	return ret;	
}

ADDR SL1FFE::addrCovert(ADDR base, INT bank, INT offset) {
	ADDR addr = (base & FFE_ADDR_BASE_MASK);
	bank = (bank & FFE_ADDR_BANK_MASK);
	if(bank<4)
	  bank = bank<<FFE_ADDR_BANK_START;
	else
	  bank = (1<<FFE_HIGH_32_BANK_START) | ((bank & FFE_ADDR_BANK_LOW_MASK)<<FFE_ADDR_BANK_START);
	offset = (offset & FFE_ADDR_OFFSET_MASK)<<FFE_ADDR_OFFSET_START;
	
	return (addr | bank | offset);
}

void SL1FFE::_readFFTData(INT point_no, double* real_in, double* img_in
			, ADDR fft_base, INT bank0, INT bank1, INT bank2, INT bank3,INT pre_flag) {
	ADDR addr;
	INT i;
//	INT j;
	INT pos;
	INT result;
	INT bank;

	INT pos0 = 0;
	INT pos1 = 0;
	INT pos2 = 0;
	INT pos3 = 0;
	for(i=0; i<point_no ;i++)
	{	
		if(pre_flag==0){
		//calculate bank addr
			if(seq_cal(i) == 0)
			{
				bank=bank0;
				pos0 = pos0 + 1;	
			}
			else if(seq_cal(i) == 1)
			{
				bank=bank1;
				pos1 = pos1 + 1;		
			}
			else if(seq_cal(i) == 2)
			{	
				bank=bank2;
				pos2 = pos2 + 1;
			}
			else if(seq_cal(i) == 3)
			{
				bank=bank3;
				pos3 = pos3 + 1;
			}
		//real part 16 bit
		}
		else
		{
			switch(i%FFE_BANK_NUM){
				case 0:
					bank=bank0; pos0 = pos0 + 1; break;
				case 1:
				    bank=bank1; pos1 = pos1 + 1; break;
				case 2:
					bank=bank2; pos2 = pos2 + 1; break;
				case 3:
				    bank=bank3; pos3 = pos3 + 1; break;
			}
		}
	    if(bank==bank0)
			pos=(pos0-1)*4;
		else if(bank==bank1)
			pos=(pos1-1)*4;
		else if(bank==bank2)
			pos=(pos2-1)*4;
		else if(bank==bank3)
			pos=(pos3-1)*4;
		
		/*************************************/
		addr = addrCovert(fft_base,bank , pos);
		result = mmu().getWord(addr);
		/*************************************/
		
		real_in[i] = (double) data_convert (result, 16);

       /*
	   if(bank==bank0)
			pos=(pos0-1)*4;
		else if(bank==bank1)
			pos=(pos1-1)*4;
		else if(bank==bank2)
			pos=(pos2-1)*4;
		else if(bank==bank3)
			pos=(pos3-1)*4;
	  */


		/*************************************/
		//addr = addrCovert(fft_base,bank, pos)+2;
		result = mmu().getWord(addr+2);
		/*************************************/
					
		img_in[i] = (double) data_convert (result, 16);
			
	}
}

void SL1FFE::_writeFFTData(INT point_no, INT bit_shift, double* real_in, double* img_in
		, ADDR fft_base, INT bank0, INT bank1, INT bank2, INT bank3, INT post_flag) {
	ADDR addr;
	INT i,j;
	INT pos;
	INT result,result_temp;
	INT bank;

	INT pos0 = 0;
	INT pos1 = 0;
	INT pos2 = 0;
	INT pos3 = 0;
	
	
	for(i=0; i<point_no ;i++)
	{	
		if(post_flag==0)
		{
		//calculate bank addr
			if(seq_cal(i) == 0)
        	{
				bank=bank0;
            	pos0 = pos0 + 1;         
        	}
        	else if(seq_cal(i) == 1)
        	{
            	bank=bank1;
            	pos1 = pos1 + 1;
        	}
        	else if(seq_cal(i) == 2)
        	{
        		bank=bank2;
            	pos2 = pos2 + 1;
        	}             
        	else if(seq_cal(i) == 3)
       		{
    		                    
            	bank=bank3;
            	pos3 = pos3 + 1;
       		}
		}
       	else
       	{
       		switch(i%FFE_BANK_NUM){
				case 0:
					bank=bank0; pos0 = pos0 + 1; break;
				case 1:
				    bank=bank1; pos1 = pos1 + 1; break;
				case 2:
					bank=bank2; pos2 = pos2 + 1; break;
				case 3:
				    bank=bank3; pos3 = pos3 + 1; break;
			}
       	}
               
		//real part 16 bit
	      bit_convert (real_in[i],16,bit_shift);
	      result=0;
	      for (j = 0; j < 4; j++)
	      {	
		      result_temp = 0;
		      switch (symbol_hex[j]){
			      case '0':result_temp = 0;break;
			      case '1':result_temp = 1;break;
			      case '2':result_temp = 2;break;
			      case '3':result_temp = 3;break;
			      case '4':result_temp = 4;break;
			      case '5':result_temp = 5;break;
			      case '6':result_temp = 6;break;
			      case '7':result_temp = 7;break;
			      case '8':result_temp = 8;break;
			      case '9':result_temp = 9;break;
			      case 'a':result_temp = 10;break;
			      case 'b':result_temp = 11;break;
			      case 'c':result_temp = 12;break;
			      case 'd':result_temp = 13;break;
			      case 'e':result_temp = 14;break;
			      case 'f':result_temp = 15;break;
			      default:result_temp=0; break;
		      }
		      result = result + (result_temp<<(4*(3-j)));
	      }
	   if(bank==bank0)
			pos=(pos0-1)*4;
		else if(bank==bank1)
			pos=(pos1-1)*4;
		else if(bank==bank2)
			pos=(pos2-1)*4;
		else if(bank==bank3)
			pos=(pos3-1)*4;
		
		/*************************************/
		addr = addrCovert(fft_base,bank,pos);
		if(_delayWriteEnable==FALSE) {
			mmu().setWord(addr, result);
		}
		else{
			_writeLogAddr[i] = addr;
			_orgData[i] = mmu().getWord(addr);
			_writeLogData[i] = result;
		}		
		/*************************************/
		//image part 16 bit
	      bit_convert (img_in[i],16,bit_shift);
	      result=0;
	      for (j = 0; j < 4; j++)
	      {	
		      result_temp = 0;
		      switch (symbol_hex[j]){
			      case '0':result_temp = 0;break;
			      case '1':result_temp = 1;break;
			      case '2':result_temp = 2;break;
			      case '3':result_temp = 3;break;
			      case '4':result_temp = 4;break;
			      case '5':result_temp = 5;break;
			      case '6':result_temp = 6;break;
			      case '7':result_temp = 7;break;
			      case '8':result_temp = 8;break;
			      case '9':result_temp = 9;break;
			      case 'a':result_temp = 10;break;
			      case 'b':result_temp = 11;break;
			      case 'c':result_temp = 12;break;
			      case 'd':result_temp = 13;break;
			      case 'e':result_temp = 14;break;
			      case 'f':result_temp = 15;break;
			      default:result_temp=0; break;
		      }
		      result = result + (result_temp<<(4*(3-j)));
	      }
	      /*	if(bank==bank0)
			pos=(pos0-1)*4;
		else if(bank==bank1)
			pos=(pos1-1)*4;
		else if(bank==bank2)
			pos=(pos2-1)*4;
		else if(bank==bank3)
			pos=(pos3-1)*4;*/
			
		/*************************************/
		//addr = addrCovert(fft_base,bank,pos)+2;
		addr += 2;
		if(_delayWriteEnable==FALSE) {
			mmu().setWord(addr, result);
		}
		else{
			_writeLogAddr[i] = addr;
			_orgData[i] = mmu().getWord(addr);
			_writeLogData[i] = result;
		}			
		/*************************************/
	}
}

void SL1FFE::resultWriteBack() {
	if(_delayWriteEnable==TRUE) {
		IsTrue((_writeLogSize>0), ("SL1FFE: FFE data write log is empty."));
		IsTrue((_writeLogAddr!=NULL), ("SL1FFE: FFE addr log is NULL."));
		IsTrue((_writeLogData!=NULL), ("SL1FFE: FFE data log is NULL."));
		IsTrue((_orgData!=NULL), ("SL1FFE: FFE original data log is NULL."));
		for(INT i = 0; i<_writeLogSize; i++) {
			WORD org_data = mmu().getWord(_writeLogAddr[i]);
			IsTrue((_orgData[i]!=org_data), ("SL1FFE: The data @0x%x has been changed during the FFE execution.", _writeLogAddr[i]));
			mmu().setWord(_writeLogAddr[i], _writeLogData[i]);
		}
		_writeLogSize = 0; //indicate all data has handled
	}
}

