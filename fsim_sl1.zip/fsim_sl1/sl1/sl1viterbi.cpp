#include "sl1mmu.h"
#include "sl1viterbi.h"

#ifndef _SKIP_VITERBI
#define _SKIP_VITERBI 0
#endif

#ifdef __cplusplus
extern "C" {
#endif

#if _SKIP_VITERBI
#define viterbi_PLI(scaling_value, cons_len_sub_one, scaling_en, minormax, diff_flag, unsigned_metric_upper, unsigned_accum_err_metric, unsigned_new_accum_err_metric, shifter_out, diff) 0
#else
extern unsigned short int viterbi_PLI( unsigned short int scaling_value, int cons_len_sub_one, int scaling_en, int minormax, int diff_flag,
				 unsigned int *unsigned_metric_upper, unsigned int *unsigned_accum_err_metric,
				 unsigned int *unsigned_new_accum_err_metric, unsigned int *shifter_out, unsigned short int *diff);
#endif
#ifdef __cplusplus
}
#endif

SL1VITERBI::SL1VITERBI(SL1MMU& m) : _mmu(m) {
	_delayWriteEnable = FALSE;
	_scalingValue = 0;
	
	_writeLogSize = 0;
	_writeLogAddr = NULL;
	_writeLogData = NULL;
	_orgData = NULL;
}

void SL1VITERBI::resultWriteBack(void)
{
	if(_delayWriteEnable==TRUE) {
		AppFatal((_writeLogSize>0), ("SL1VITERBI: VITERBI data write log is empty."));
		AppFatal((_writeLogAddr!=NULL), ("SL1VITERBI: VITERBI addr log is NULL."));
		AppFatal((_writeLogData!=NULL), ("SL1VITERBI: VITERBI data log is NULL."));
		AppFatal((_orgData!=NULL), ("SL1VITERBI: VITERBI original data log is NULL."));
		for(INT i = 0; i<_writeLogSize; i++) {
			WORD org_data = mmu().getWord(_writeLogAddr[i]);
			AppFatal((_orgData[i]!=org_data), ("SL1VITERBI: The data @0x%x has been changed during the VITERBI execution.", _writeLogAddr[i]));
			mmu().setWord(_writeLogAddr[i], _writeLogData[i]);
		}
		_writeLogSize = 0; //indicate all data has handled
	}
}		
	


void SL1VITERBI::_readInputData(UINT *dest,ADDR res,UINT len)
{
	INT i;
	for(i=0;i<len;i++)
		dest[i] = mmu().getWord(res+i*WORD_BYTE);
}

/*
void SL1VITERBI::_writeOutputData(ADDR dest, UINT* res,UINT len)
{
	INT i;
	if(_delayWriteEnable==FALSE)
	{
		for(i=0;i<len;i++)
			mmu().setWord(dest+i*WORD_BYTE,res[i]);
	}
	else
	{
		_writeAccSize = len;
		_writeAccAddr = new ADDR[len];
		_writeAccData = new WORD[len];
		_orgAccData = new WORD[len];
		for(i=0;i<len;i++)
		{
			_writeAccAddr[i] = dest+i*WORD_BYTE;
			_writeAccData[i] = res[i];
			_orgAccData[i] = mmu().getWord(dest+i*WORD_BYTE);
		}
	}
}
*/
UINT SL1VITERBI::_writeOutputShift(UINT* dest,UINT* res,UINT cons_len_sub_one)
{
	INT i,size;
	if (cons_len_sub_one == 4)
    {
		dest[0]=res[0]+(res[4]<<8);
		size = 1;
		//mmu().setWord(dest,last_shifter_out);		                
    }
	else if (cons_len_sub_one == 5)
    {
    	dest[0]=res[0]+(res[4]<<16);
    	size = 1;
 		//mmu().setWord(dest,last_shifter_out);
	}
    else if (cons_len_sub_one == 6)
    {
    	dest[0] = res[0];
    	dest[1] = res[4];
    	size = 2;
		//mmu().setWord(dest,res[0]);
        //mmu().setWord(dest+WORD_BYTE,res[4]);
    }
    else if (cons_len_sub_one == 7)
    {
    	//mmu().setWord(dest,res[0]);
        //mmu().setWord(dest+WORD_BYTE,res[1]);
        //mmu().setWord(dest+WORD_BYTE*2,res[4]);
        //mmu().setWord(dest+WORD_BYTE*3,res[5]);
        dest[0] = res[0];
        dest[1] = res[1];
        dest[2] = res[4];
        dest[3] = res[5];
        size = 4;  
    }
	else //if (cons_len_sub_one == 8)
    {
    	AppFatal((cons_len_sub_one==8), ("invalid cons_len_sub_one(%d),instr c3.viterbi failed\n", cons_len_sub_one));
     	for (i=0;i<8;i++)
        {
        	dest[i] = res[i];
        	//mmu().setWord(dest+i*WORD_BYTE,res[i]);	          
        }
        size = 8;               
    }
    return size;		
}

WORD SL1VITERBI::exec(ADDR rs1, WORD rs2) {
	
	union{
		WORD rs;
		struct{
			unsigned diff: 1;
			unsigned minmax: 1;
			unsigned scaling_en: 1;
			unsigned const_len_1: 4;
			unsigned non_use:25;
		}bits;
	}rsgpr;
	
	if(_delayWriteEnable==TRUE) {
	 	AppFatal((_writeLogSize==0), ("VITERBI have been used twice!"));
		if(_writeLogAddr!=NULL) {
			delete _writeLogAddr;
		}
		if(_writeLogData!=NULL) {
			delete _writeLogData;
		}
		if(_orgData!=NULL) {
			delete _orgData;
		}		 	
	 }
	 
	rsgpr.rs = rs2;
	INT diff_flag = rsgpr.bits.diff;
	INT minormax = rsgpr.bits.minmax;
	INT scale_flag = rsgpr.bits.scaling_en;
	UINT cons_len_sub_one = rsgpr.bits.const_len_1;
	ADDR input_data = mmu().getWord(rs1);
	ADDR buf0 = mmu().getWord(rs1+WORD_BYTE);
	ADDR buf1 = mmu().getWord(rs1+WORD_BYTE*2);
	ADDR shift_outaddr = mmu().getWord(rs1+WORD_BYTE*3);
	ADDR diff_output = mmu().getWord(rs1+WORD_BYTE*4);
	
	UINT len = 1<<cons_len_sub_one;
	UINT input_len = len>>1;
	UINT *metric_upper,*accum_err_metric,*new_accum_err_metric;
	UINT shifter_out[MAX_SHIFT_SIZE];
	UINT16 diff;
	UINT shift_size;
	UINT last_shifter_out[8];
	INT i;
	metric_upper = new UINT[input_len];
	accum_err_metric = new UINT[input_len];
	new_accum_err_metric = new UINT[input_len];
	
	
	
	_readInputData(metric_upper,input_data,input_len);
	_readInputData(accum_err_metric,buf0,input_len);
	_scalingValue = viterbi_PLI(_scalingValue,cons_len_sub_one,scale_flag,
									minormax,diff_flag, metric_upper,accum_err_metric,
				 					new_accum_err_metric, shifter_out,&diff);
    shift_size = _writeOutputShift(&last_shifter_out[0],shifter_out,cons_len_sub_one);	
	//_writeOutputData(buf1,new_accum_err_metric,input_len,shift_size);
	if(_delayWriteEnable==FALSE)
	{
		for(i=0;i<input_len;i++)
			mmu().setWord(buf1+i*WORD_BYTE,new_accum_err_metric[i]);
		for(i=0;i<shift_size;i++)
		    mmu().setWord(shift_outaddr+i*WORD_BYTE,last_shifter_out[i]);
	}
	else
	{
		_writeLogSize = input_len+shift_size;
		_writeLogAddr = new ADDR[_writeLogSize+1];
		_writeLogData = new WORD[_writeLogSize+1];
		_orgData = new WORD[_writeLogSize+1];
		for(i=0;i<input_len;i++)
		{
			_writeLogAddr[i] = buf1+i*WORD_BYTE;
			_writeLogData[i] = new_accum_err_metric[i];
			_orgData[i] = mmu().getWord(buf1+i*WORD_BYTE);
		}
		for(i=input_len;i<_writeLogSize;i++)
		{
			_writeLogAddr[i] = shift_outaddr+i*WORD_BYTE;
			_writeLogData[i] = last_shifter_out[i];
			_orgData[i] = mmu().getWord(shift_outaddr+i*WORD_BYTE);
		}
	}
	
	if(diff_flag)
	{
		if(_delayWriteEnable==FALSE)
		{
			mmu().setHword(diff_output,diff);
		}
		else
		{
			_orgData[_writeLogSize] = mmu().getHword(diff_output);
			_writeLogAddr[_writeLogSize] = diff_output;
			_writeLogData[_writeLogSize] = diff;
			_writeLogSize++;
		}
	}

	delete metric_upper;
	delete accum_err_metric;
	delete new_accum_err_metric;
	if(_delayWriteEnable==FALSE)
    	return VITERBI_FINISHED;
    else
    	return VITERBI_USED;
}

