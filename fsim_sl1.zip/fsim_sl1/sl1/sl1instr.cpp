#include "sl1instr.h"

//construct the reg list for psim
void SL1Instr::getRegList(RegList* destList, RegList* srcList) {
	
	//dest list
	if((_ctrl1.status&ERS_WRITE)>0) {
		destList->push_back(_ctrl1.index+_ctrl1.regbase);
	}
	if((_ctrl2.status&ERS_WRITE)>0) {
		destList->push_back(_ctrl2.index+_ctrl2.regbase);
	}	
	if((_sreg0.status&ERS_WRITE)>0) {
		destList->push_back(_sreg0.index+_sreg0.regbase);
		if((_sreg0p.status&ERS_WRITE)>0) {
			destList->push_back(_sreg0p.index+_sreg0p.regbase);
		}		
	}	
	if((_sreg0.status&ERS_WRITE)>0) {
		destList->push_back(_sreg0.index+_sreg0.regbase);
	}	
	if((_sreg1.status&ERS_WRITE)>0) {
		destList->push_back(_sreg1.index+_sreg1.regbase);
	}
	if((_sreg2.status&ERS_WRITE)>0) {
		destList->push_back(_sreg2.index+_sreg2.regbase);
	}			
	if((_reg0.status&ERS_WRITE)>0) {
		destList->push_back(_reg0.index+_reg0.regbase);
	}
	if((_reg1.status&ERS_WRITE)>0) {
		destList->push_back(_reg1.index+_reg1.regbase);
	}
	if((_reg2.status&ERS_WRITE)>0) {
		destList->push_back(_reg2.index+_reg2.regbase);
	}

	//src list
	if((_ctrl1.status&ERS_READ)>0) {
		srcList->push_back(_ctrl1.index+_ctrl1.regbase);
	}
	if((_ctrl2.status&ERS_READ)>0) {
		srcList->push_back(_ctrl2.index+_ctrl2.regbase);
	}		
	if((_reg0.status&ERS_READ)>0) {
		srcList->push_back(_reg0.index+_reg0.regbase);
	}
	if((_reg1.status&ERS_READ)>0) {
		srcList->push_back(_reg1.index+_reg1.regbase);
	}
	if((_reg2.status&ERS_READ)>0) {
		srcList->push_back(_reg2.index+_reg2.regbase);
	}
	if((_sreg0.status&ERS_READ)>0) {
		srcList->push_back(_sreg0.index+_sreg0.regbase);
		if((_sreg0p.status&ERS_READ)>0) {
			srcList->push_back(_sreg0p.index+_sreg0p.regbase);
		}		
	}	
	if((_sreg0.status&ERS_READ)>0) {
		srcList->push_back(_sreg0.index+_sreg0.regbase);
	}
	if((_sreg1.status&ERS_READ)>0) {
		srcList->push_back(_sreg1.index+_sreg1.regbase);
	}
	if((_sreg2.status&ERS_READ)>0) {
		srcList->push_back(_sreg2.index+_sreg2.regbase);
	}

}

pair<INT, INT> SL1Instr::gprRegPort() {
	INT readReg = 0;
	INT writeReg = 0;
	pair<INT, INT> result;
	if((_reg0.status&ERS_WRITE)>0) {
		writeReg++;
	}
	if((_reg1.status&ERS_WRITE)>0) {
		writeReg++;
	}
	if((_reg2.status&ERS_WRITE)>0) {
		writeReg++;
	}
	if((_reg0.status&ERS_READ)>0) {
		readReg++;
	}
	if((_reg1.status&ERS_READ)>0) {
		readReg++;
	}
	if((_reg2.status&ERS_READ)>0) {
		readReg++;
	}
	result.first = 	readReg;
	result.second = writeReg;	
	return result;
}

pair<INT, INT> SL1Instr::ctrlRegPort() {
	INT readReg = 0;
	INT writeReg = 0;
	pair<INT, INT> result;
	if((_ctrl1.status&ERS_WRITE)>0) {
		if(_ctrl1.regbase==EBASE_CTRL) {
			writeReg++;
		}
	}
	if((_ctrl2.status&ERS_WRITE)>0) {
		if(_ctrl2.regbase==EBASE_CTRL) {
			writeReg++;
		}
	}
	if((_ctrl1.status&ERS_READ)>0) {
		if(_ctrl1.regbase==EBASE_CTRL) {
			readReg++;
		}
	}
	if((_ctrl2.status&ERS_READ)>0) {
		if(_ctrl2.regbase==EBASE_CTRL) {
			readReg++;
		}
	}
	result.first = 	readReg;
	result.second = writeReg;	
	return result;
}

pair<INT, INT> SL1Instr::addrRegPort() {
	INT readReg = 0;
	INT writeReg = 0;
	pair<INT, INT> result;
	if((_sreg0.status&ERS_WRITE)>0) {
		if(_sreg0.regbase==EBASE_AR&&_sreg0.index<REG_AR_SIZE) {
			writeReg++;
		}
	}	
	if((_sreg1.status&ERS_WRITE)>0) {
		if(_sreg1.regbase==EBASE_AR&&_sreg1.index<REG_AR_SIZE) {
			writeReg++;
		}
	}
	if((_sreg2.status&ERS_WRITE)>0) {
		if(_sreg2.regbase==EBASE_AR&&_sreg2.index<REG_AR_SIZE) {
			writeReg++;
		}
	}
	if((_sreg0.status&ERS_READ)>0) {
		if(_sreg0.regbase==EBASE_AR&&_sreg0.index<REG_AR_SIZE) {
			readReg++;
		}
	}	
	if((_sreg1.status&ERS_READ)>0) {
		if(_sreg1.regbase==EBASE_AR&&_sreg1.index<REG_AR_SIZE) {
			readReg++;
		}
	}
	if((_sreg2.status&ERS_READ)>0) {
		if(_sreg2.regbase==EBASE_AR&&_sreg2.index<REG_AR_SIZE) {
			readReg++;
		}
	}
	result.first = 	readReg;
	result.second = writeReg;	
	return result;
}

pair<INT, INT> SL1Instr::addrUpdateRegPort() {
	INT readReg = 0;
	INT writeReg = 0;
	pair<INT, INT> result;
	if((_sreg0.status&ERS_WRITE)>0) {
		if(_sreg0.regbase==EBASE_AR&&_sreg0.index>=REG_AR_CUR_SIZE&&_sreg0.index<REG_AR_ALL_SIZE) {
			writeReg++;
		}
	}	
	if((_sreg1.status&ERS_WRITE)>0) {
		if(_sreg1.regbase==EBASE_AR&&_sreg1.index>=REG_AR_CUR_SIZE&&_sreg1.index<REG_AR_ALL_SIZE) {
			writeReg++;
		}
	}
	if((_sreg2.status&ERS_WRITE)>0) {
		if(_sreg2.regbase==EBASE_AR&&_sreg2.index>=REG_AR_CUR_SIZE&&_sreg2.index<REG_AR_ALL_SIZE) {
			writeReg++;
		}
	}
	if((_sreg0.status&ERS_READ)>0) {
		if(_sreg0.regbase==EBASE_AR&&_sreg0.index>=REG_AR_CUR_SIZE&&_sreg0.index<REG_AR_ALL_SIZE) {
			readReg++;
		}
	}	
	if((_sreg1.status&ERS_READ)>0) {
		if(_sreg1.regbase==EBASE_AR&&_sreg1.index>=REG_AR_CUR_SIZE&&_sreg1.index<REG_AR_ALL_SIZE) {
			readReg++;
		}
	}
	if((_sreg2.status&ERS_READ)>0) {
		if(_sreg2.regbase==EBASE_AR&&_sreg2.index>=REG_AR_CUR_SIZE&&_sreg2.index<REG_AR_ALL_SIZE) {
			readReg++;
		}
	}
	result.first = 	readReg;
	result.second = writeReg;	
	return result;
}

pair<INT, INT> SL1Instr::accPort() {
	INT readReg = 0;
	INT writeReg = 0;
	pair<INT, INT> result;
	if((_reg0.status&ERS_WRITE)>0) {
		if((_sreg0.regbase==EBASE_ACC&&_sreg0.index<REG_ACC_SIZE) || 
			(_sreg0.regbase==EBASE_AR&&_sreg0.index>=REG_AR_ALL_SIZE)){
			writeReg++;
			if((_sreg0p.status&ERS_WRITE)>0) {
				if((_sreg0p.regbase==EBASE_ACC&&_sreg0p.index<REG_ACC_SIZE)|| 
					(_sreg0p.regbase==EBASE_AR&&_sreg0p.index>=REG_AR_ALL_SIZE)) {
					writeReg++;
				}
			}
		}	
	}
	if((_reg0.status&ERS_READ)>0) {
		if((_sreg0.regbase==EBASE_ACC&&_sreg0.index<REG_ACC_SIZE) || 
					(_sreg0.regbase==EBASE_AR&&_sreg0.index>=REG_AR_ALL_SIZE)) {
			readReg++;
			if((_sreg0p.status&ERS_READ)>0) {
				if((_sreg0p.regbase==EBASE_ACC&&_sreg0p.index<REG_ACC_SIZE)|| 
					(_sreg0p.regbase==EBASE_AR&&_sreg0p.index>=REG_AR_ALL_SIZE)) {
					readReg++;
				}
			}			
		}
	}
	if((_sreg1.status&ERS_READ)>0) {
		if(_sreg1.regbase==EBASE_ACC&&_sreg1.index<REG_ACC_SIZE){
			readReg++;
		}
	}	
	result.first = 	readReg;
	result.second = writeReg;	
	return result;
}
