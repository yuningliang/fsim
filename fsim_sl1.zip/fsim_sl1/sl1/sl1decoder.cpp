#include "sl1decoder.h"
#include "sl1instr.h"
#include "sl1reg.h"
#include "sl1mmu.h"
#include "sl1instrtable.h"

SL1Decoder::SL1Decoder() : CoreDecoder<SL1Instr>(TRUE) { 
	setMode(SL1_INSTR_MODE); 
}

SL1Decoder::SL1Decoder(BOOL b) : CoreDecoder<SL1Instr>(b) { 
	setMode(SL1_INSTR_MODE); 
}

UINT32 SL1Decoder::decode(SL1Instr* instr,  ADDR pc, WORD raw) {
	SL1InstrTableEntry* entry;
	DEBUG_DECODE("Entering CoreDecoder::decode\n");
	UINT size = 0;
	UBYTE gr = EGROUP_INVALID;
	union {
		WORD rawbits;
		struct {
			unsigned lv2 : 6;
			unsigned na : 10;
			unsigned lv2s : 5;
			unsigned lv2g1 : 5;
			unsigned top :6;
		} bits;
		struct {
			unsigned na : 23;
			unsigned lv2 : 6;
			unsigned top : 3;
		} c2bits;			
	} rb;	
	rb.rawbits = raw;
	gr = getGroupID(rb.bits.top);
	
	if(IS_CORE_INSTR16(gr)) {
		if((pc&WORD_ALIGN_MASK)==0) {
			raw <<= INT16_BIT;
			rb.rawbits = raw;
			gr = getGroupID(rb.bits.top);
			AppFatal((IS_CORE_INSTR16(gr)), ("Decoder: Invalid 16 bits instruction (pc=%08x, raw=%08x)", pc, raw));
		}
		else {
			raw &= UPPER_HWORD_DATA_MASK;
		}
	}

	switch (gr) {
		case EGROUP_TOP:
		case EGROUP_TOP_16:
			entry = &Top_Table[rb.bits.top];
			break;
		case EGROUP_G0:
			entry = &G0_Table[rb.bits.lv2];
			break;
		case EGROUP_G1:
			entry = &G1_Table[rb.bits.lv2g1];
			break;		
		case EGROUP_G2:
			entry = &G2_Table[rb.bits.lv2s];
			break;	
		case EGROUP_C2:
			entry = &C2_Table[rb.c2bits.lv2];
			break;					
		case EGROUP_C3:
			entry = &C3_Table[rb.bits.lv2];
			break;		
		default:
			if(assertInvalidInstr()==TRUE) {
				AppFatal((0), ("Decoder: Invalid instruction group (pc=%08x, raw=%08x, gr=%d)", pc, raw, gr));
			}
			else {
				return INT32_BYTE;	
			}
			break;
	}
	
	if(entry->enable(mode())) {
		instr->init(entry, raw);
		size = (this->*(entry->decode()))(instr, 0);
		instr->instrsize(size);
		instr->pc(pc);
	}
	else{
		if(assertInvalidInstr()==TRUE) {
			AppFatal((0), ("Decoder: Invalid instruction group (pc=%08x, raw=%08x, gr=%d)", pc, raw, gr));
		}
		else {
			return INT32_BYTE;	
		}
	}
	return size;
}

UINT32 SL1Decoder::decode(SL1Instr* instr,  ADDR pc, WORD raw, UINT meta) {
	SL1InstrTableEntry* entry;
	DEBUG_DECODE("Entering CoreDecoder::decode\n");
	UINT size = 0;
	UBYTE gr = EGROUP_INVALID;
	union {
		WORD rawbits;
		struct {
			unsigned lv2 : 6;
			unsigned na : 10;
			unsigned lv2s : 5;
			unsigned lv2g1 : 5;
			unsigned top :6;
		} bits;
		struct {
			unsigned na : 23;
			unsigned lv2 : 6;
			unsigned top : 3;
		} c2bits;			
	} rb;	
	rb.rawbits = raw;
	gr = getGroupID(rb.bits.top);
	
	switch (gr) {
		case EGROUP_TOP:
		case EGROUP_TOP_16:
			entry = &Top_Table[rb.bits.top];
			break;
		case EGROUP_G0:
			entry = &G0_Table[rb.bits.lv2];
			break;
		case EGROUP_G1:
			entry = &G1_Table[rb.bits.lv2g1];
			break;		
		case EGROUP_G2:
			entry = &G2_Table[rb.bits.lv2s];
			break;	
		case EGROUP_C2:
			entry = &C2_Table[rb.c2bits.lv2];
			break;					
		case EGROUP_C3:
			entry = &C3_Table[rb.bits.lv2];
			break;		
		default:
			if(assertInvalidInstr()==TRUE) {
				AppFatal((0), ("Decoder: Invalid instruction group (pc=%08x, raw=%08x, gr=%d)", pc, raw, gr));
			}
			else {
				return INT32_BYTE;	
			}
			break;
	}
	
	if(entry->enable(mode())) {
		instr->init(entry, raw);
		size = (this->*(entry->decode()))(instr, meta);
		instr->instrsize(size);
		instr->pc(pc);
	}
	else{
		if(assertInvalidInstr()==TRUE) {
			AppFatal((0), ("Decoder: Invalid instruction (pc=%08x, raw=%08x)", pc, raw));
		}
		else {
			return INT32_BYTE;	
		}
	}
	return size;
}


//, c3.sashllh
ADDR SL1Decoder::decodeBb_01 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned na5 : 5;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd : 5;
			unsigned top :6;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
	instr->rs1(rb.bits.rs1);
	instr->rs2(rb.bits.rs2);
	instr->rd(rb.bits.rd);
	return INT32_BYTE;	
}

//, c3.dshll.i, c3.dshrl.i
ADDR SL1Decoder::decodeBb_02 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned imm_lo : 5;
			unsigned imm_hi : 5;
			unsigned rs1 : 5;
			unsigned rd : 5;
			unsigned top :6;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
	instr->rd(rb.bits.rd);
	instr->rs1(rb.bits.rs1);
	instr->imm_lo(rb.bits.imm_lo);	
	instr->imm_hi(rb.bits.imm_hi);	
	
	return INT32_BYTE;	
}

//, c3.bitc
ADDR SL1Decoder::decodeBb_03 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned b_mode : 4;
			unsigned na2 : 1;
			unsigned imm5 : 5;
			unsigned na1 : 5;
			unsigned sd : 5;
			unsigned top :6;
		} bits;
	}rb;
	UINT uimm;
	rb.rawbits = instr->rawbits();
	instr->sd(rb.bits.sd);
	uimm = rb.bits.imm5;
	instr->imm5(uimm);
	instr->b_mode(rb.bits.b_mode);	
	return INT32_BYTE;	
}

//, c3.bitr
ADDR SL1Decoder::decodeBb_04 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned b_mode : 4;
			unsigned na2 : 1;
			unsigned imm5 : 5;
			unsigned rs1 : 5;
			unsigned rd : 5;
			unsigned top :6;
		} bits;
	}rb;
	UINT uimm;
	rb.rawbits = instr->rawbits();
	instr->rd(rb.bits.rd);
	instr->rs1(rb.bits.rs1);
	uimm = rb.bits.imm5;
	instr->imm5(uimm);
	instr->b_mode(rb.bits.b_mode);	
	return INT32_BYTE;	
}

//, c3.mulh.a, c3.saadd.a, c3.saaddh.a, c3.samulh.a, c3.sasub.a, c3.sasubh.a
ADDR SL1Decoder::decodeBb_06 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned bsel : 2;
			unsigned na : 1;
			unsigned am2 : 3;
			unsigned as2 : 3;
			unsigned am1 : 3;
			unsigned as1 : 3;
			unsigned rd : 5;
			unsigned top :6;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
	instr->rd(rb.bits.rd);
	instr->as1(rb.bits.as1);
	instr->am1(rb.bits.am1);
	instr->as2(rb.bits.as2);
	instr->am2(rb.bits.am2);
	instr->bsel(rb.bits.bsel);	
	return INT32_BYTE;	
}

//, c3.ld
ADDR SL1Decoder::decodeBb_07 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned bsel : 2;
			unsigned na2 : 1;
			unsigned dtype : 3;
			unsigned na1 : 3;
			unsigned am1 : 3;
			unsigned as1 : 3;
			unsigned rd : 5;
			unsigned top :6;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
	instr->dtype(rb.bits.dtype);
    instr->rd(rb.bits.rd);
	instr->as1(rb.bits.as1);
	instr->am1(rb.bits.am1);
	
	instr->bsel(rb.bits.bsel);	
	return INT32_BYTE;
}

//, c3.mac, c3.macci, c3.maccr, c3.macd, c3.macdn, c3.macn, c3.mula, c3.mulaci, c3.mulacr, c3.mulad, c3.muladn, c3.mulan
ADDR SL1Decoder::decodeBb_09 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned na : 5;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned acm : 3;
			unsigned acc : 2;
			unsigned top :6;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
	instr->acc(rb.bits.acc);
	instr->acm(rb.bits.acm);
	instr->rs1(rb.bits.rs1);
	instr->rs2(rb.bits.rs2);
	return INT32_BYTE;
}

//, c3.mac.a, c3.macn.a, c3.mula.a
ADDR SL1Decoder::decodeBb_10 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned bsel : 2;
			unsigned na : 1;
			unsigned am2 : 3;
			unsigned as2 : 3;
			unsigned am1 : 3;
			unsigned as1 : 3;
			unsigned acm : 3;
			unsigned acc : 2;
			unsigned top :6;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
	instr->acc(rb.bits.acc);
	instr->acm(rb.bits.acm);
	instr->as1(rb.bits.as1);
	instr->am1(rb.bits.am1);
	instr->as2(rb.bits.as2);
	instr->am2(rb.bits.am2);
	instr->bsel(rb.bits.bsel);
	return INT32_BYTE;
}

//, c3.mac.ar, c3.macn.ar, c3.mula.ar
ADDR SL1Decoder::decodeBb_11 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned bsel : 2;
			unsigned na2 : 1;
			unsigned am2 : 3;
			unsigned as2 : 3;
			unsigned na1 : 1;
			unsigned rs1 : 5;
			unsigned acm : 3;
			unsigned acc : 2;
			unsigned top :6;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
	instr->acc(rb.bits.acc);
	instr->acm(rb.bits.acm);
	instr->rs1(rb.bits.rs1);
	instr->as2(rb.bits.as2);
	instr->am2(rb.bits.am2);
	instr->bsel(rb.bits.bsel);
	return INT32_BYTE;
}

//, c3.mac.i, c3.macn.i, c3.mula.i
ADDR SL1Decoder::decodeBb_12 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			signed imm10 : 10;
			unsigned rs1 : 5;
			unsigned acm : 3;
			unsigned acc : 2;
			unsigned top :6;
		} bits;
	}rb;
	INT simm;
	rb.rawbits = instr->rawbits();
	instr->acc(rb.bits.acc);
	instr->acm(rb.bits.acm);
	instr->rs1(rb.bits.rs1);
	simm = rb.bits.imm10;
	instr->imm10(simm);
	return INT32_BYTE;
}

//, c3.mvfs
ADDR SL1Decoder::decodeBb_13 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned imm5 : 5;
			unsigned na : 5;
			unsigned ss1 : 5;
			unsigned rd : 5;
			unsigned top :6;
		} bits;
	}rb;
	UINT uimm;
	rb.rawbits = instr->rawbits();
	instr->rd(rb.bits.rd);
	instr->ss1(rb.bits.ss1);
	uimm = rb.bits.imm5;
	instr->imm5(uimm);
	return INT32_BYTE;
}

//, c3.mvts
ADDR SL1Decoder::decodeBb_14 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned imm5 : 5;
			unsigned na : 5;
			unsigned rs1 : 5;
			unsigned sd : 5;
			unsigned top :6;
		} bits;
	}rb;
	UINT uimm;
	rb.rawbits = instr->rawbits();
	instr->sd(rb.bits.sd);
	instr->rs1(rb.bits.rs1);
	uimm = rb.bits.imm5;
	instr->imm5(uimm);
	return INT32_BYTE;
}

//, c3.lead
ADDR SL1Decoder::decodeBb_15 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned mode : 2;
			unsigned na : 11;
			unsigned acc : 2;
			unsigned rd : 5;
			unsigned top :6;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
	instr->rd(rb.bits.rd);
	instr->acc(rb.bits.acc);
	instr->mode(rb.bits.mode);
	return INT32_BYTE;
}

//, c3.revb
ADDR SL1Decoder::decodeBb_17 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned mode : 2;
			unsigned na2 : 3;
			unsigned imm5 : 5;
			unsigned rs1 : 5;
			unsigned rd : 5;
			unsigned top :6;
		} bits;
	}rb;
	UINT uimm;
	rb.rawbits = instr->rawbits();
	instr->rd(rb.bits.rd);
	instr->rs1(rb.bits.rs1);
	uimm = rb.bits.imm5;
	instr->imm5(uimm);
	return INT32_BYTE;
}

//, c3.st
ADDR SL1Decoder::decodeBb_19 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned bsel : 2;
			unsigned na2 : 1;
			unsigned dtype : 3;
			unsigned na1 : 3;
			unsigned am1 : 3;
			unsigned as1 : 3;
			unsigned rs0 : 5;
			unsigned top :6;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
   	instr->rs0(rb.bits.rs0);
	instr->as1(rb.bits.as1);
	instr->am1(rb.bits.am1);
	instr->dtype(rb.bits.dtype);
	instr->bsel(rb.bits.bsel);
	return INT32_BYTE;
}

//, c3.muls, c3.mulus
ADDR SL1Decoder::decodeBb_20 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned imm5 : 5;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd : 5;
			unsigned top :6;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
	instr->imm5(rb.bits.imm5);
	instr->sd(ESR_HI);
	instr->rd(rb.bits.rd);
	instr->rs2(rb.bits.rs2);
	instr->rs1(rb.bits.rs1);
	return INT32_BYTE;
}

//, c3.saadds, c3.saaddsh, c3.samulsh, c3.sasubs, c3.sasubsh
ADDR SL1Decoder::decodeBb_21 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned imm5 : 5;
			unsigned rs2 : 5;
			unsigned rs1: 5;
			unsigned rd : 5;
			unsigned top :6;
		} bits;
	}rb;
	UINT uimm;
	rb.rawbits = instr->rawbits();
	uimm = rb.bits.imm5;
	instr->imm5(uimm);
    	instr->rs1(rb.bits.rs1);
	instr->rs2(rb.bits.rs2);
	instr->rd(rb.bits.rd);
	return INT32_BYTE;
}

//, c3.round
ADDR SL1Decoder::decodeBb_22 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned mode : 2;
			unsigned na : 3;
			unsigned imm5: 5;
			unsigned na1 : 8;
			unsigned acc : 2;
			unsigned top :6;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
	instr->acc(rb.bits.acc);
	instr->imm5(rb.bits.imm5);
	instr->mode(rb.bits.mode);
	return INT32_BYTE;
}

//, c3.saddha
ADDR SL1Decoder::decodeBb_23 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned na1 : 2;
			unsigned N : 1;
			unsigned na2 : 2;
			unsigned imm5 : 5;
			unsigned rs1 : 5;
			unsigned acm : 3;
			unsigned acc : 2;
			unsigned top :6;
		} bits;
	}rb;
	UINT uimm;
	rb.rawbits = instr->rawbits();
	instr->acc(rb.bits.acc);
	instr->acm(rb.bits.acm);
	instr->rs1(rb.bits.rs1);
	uimm = rb.bits.imm5;
	instr->imm5(uimm);	
	instr->N(rb.bits.N);
	return INT32_BYTE;
}

//, c3.saddha.a
ADDR SL1Decoder::decodeBb_24 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned bsel : 2;
			unsigned N : 1;
			unsigned na1 : 2;
			unsigned imm4 : 4;
			unsigned am1 : 3;
			unsigned as1 : 3;
			unsigned acm : 3;
			unsigned acc : 2;
			unsigned top :6;
		} bits;
	}rb;
	UINT uimm;
	rb.rawbits = instr->rawbits();
	instr->acc(rb.bits.acc);
	instr->acm(rb.bits.acm);
	instr->as1(rb.bits.as1);
	instr->am1(rb.bits.am1);
	uimm = rb.bits.imm4;
	instr->imm4(uimm);	
	instr->N(rb.bits.N);
	instr->bsel(rb.bits.bsel);
	return INT32_BYTE;
}

//, c3.dadda, c3.dmac, c3.dmacn, c3.dmula, c3.dmulan, c3.dsuba
ADDR SL1Decoder::decodeBb_25 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned na : 5;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned acm : 3;
			unsigned acc : 2;			
			unsigned top :6;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
	instr->rs1(rb.bits.rs1);
	instr->rs2(rb.bits.rs2);
	instr->acm(rb.bits.acm);
	instr->acc_pair(rb.bits.acc);
	return INT32_BYTE;
}

//, c3.dmac.a, c3.dmacn.a, c3.dmula.a, c3.dmulan.a
ADDR SL1Decoder::decodeBb_26 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned bsel : 2;
			unsigned na : 1;
			unsigned am2 : 3;
			unsigned as2 : 3;
			unsigned am1 : 3;
			unsigned as1 : 3;
			unsigned acm : 3;
			unsigned acc : 2;
			unsigned top :6;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
	instr->bsel(rb.bits.bsel);
	instr->am2(rb.bits.am2);
	instr->am1(rb.bits.am1);
	instr->as2(rb.bits.as2);
	instr->as1(rb.bits.as1);
	instr->acm(rb.bits.acm);
	instr->acc_pair(rb.bits.acc);
	return INT32_BYTE;	
}

//c3.ffe
UINT32 SL1Decoder::decodeBb_27 (SL1Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned na : 5;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned na1 : 5;
			unsigned top :6;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
	switch(rb.bits.op){
		case FFT_OPCODE:
			instr->sd(ESR_FFT);
			break;
		case VITERBI_OPCODE:
			instr->sd(ESR_VITERBI);
			break;
		case TRBACK_OPCODE:
			instr->sd(ESR_TRBACK);
			break;
		default:
			AppFatal((0),("invalid opcode for fixed func engine.\n"));
	}
	instr->rs1(rb.bits.rs1);
	instr->rs2(rb.bits.rs2);
	return INT32_BYTE;		
}
