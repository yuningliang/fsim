#ifndef SL1INSTRTABLE_H_
#define SL1INSTRTABLE_H_

#include "defs.h"
#include "cdefs.h"

class SL1Instr;
class SL1Exec;
class SL1Decoder;
class SL1Disasm;

typedef ADDR (SL1Exec::*SL1ExecPtr) (SL1Instr*);
typedef UINT32 (SL1Decoder::*SL1DecodePtr) (SL1Instr*, UINT);
typedef STRING (SL1Disasm::*SL1DisasmPtr) (ADDR, SL1Instr*, UINT);

enum SL1EINSTR_GR {
	EIG_gr = GROUP_ID_EIG_GR, //0
	EIG_alu = GROUP_ID_EIG_ALU, //1
	EIG_alu16 = GROUP_ID_EIG_ALU16, //2
	EIG_ls = GROUP_ID_EIG_LS, //3
	EIG_ls16 = GROUP_ID_EIG_LS16, //4
	EIG_br = GROUP_ID_EIG_BR, //5
	EIG_br16 = GROUP_ID_EIG_BR16, //6
	EIG_j = GROUP_ID_EIG_J, //7
	EIG_j16 = GROUP_ID_EIG_J16,	 //8
	EIG_c3_mac = 9,
	EIG_c3_ffe = 10,
	EIG_c3_viterbi=11,
	EIG_c3_traceback = 12,
	EIG_misc = 13,
	EIG_max = 14,
	EIG_invalid = 0xff,
};

class SL1InstrTableEntry 
{
	public:
	STRING _mn;
	UINT16 _id;
	UINT16 _enable;
	SL1EINSTR_GR _group;
	SL1DecodePtr _decode;
	SL1ExecPtr _exec;
	SL1DisasmPtr _print;
	
	public:
	char *mn(void) 			{ return _mn; }
	UINT16 id(void)			{ return _id; }
	BOOL enable(UINT16 mode) { return mode&_enable; }
	SL1EINSTR_GR group(void) { return _group; }
	SL1DecodePtr decode(void) { return _decode;}
	SL1ExecPtr exec(void) { return _exec;}
	SL1DisasmPtr print(void) { return _print;}
};

extern class SL1InstrTableEntry Top_Table[];
extern class SL1InstrTableEntry G0_Table[];
extern class SL1InstrTableEntry G1_Table[];
extern class SL1InstrTableEntry G2_Table[];
extern class SL1InstrTableEntry C2_Table[];
extern class SL1InstrTableEntry C3_Table[];

#endif /*INSTRTABLE_H_*/
