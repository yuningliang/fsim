#ifndef SL1DISASM_H_
#define SL1DISASM_H_

#include "cdisasm.h"
#include "sl1instr.h"

class SymTable;
class SL1MMU;
class SL1Register;
class Decoder;

class SL1Disasm : public CoreDisasm<SL1MMU, SL1Register, SL1Instr> {
	public:	
	SL1Disasm(SL1MMU& mmu, SL1Register& reg, UINT th_id);

	STRING disasm(ADDR addr, SL1Instr* instr, UINT meta) {
		return (this->*(instr->print()))(addr, instr, meta);;
	}
	
//SL1Instruction disassembler function
	STRING disasmBb_01 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.sashllh
	STRING disasmBb_02 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.dshll.i, c3.dshrl.i
	STRING disasmBb_03 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.bitc
	STRING disasmBb_04 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.bitr
	STRING disasmBb_06 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.mulh.a, c3.saadd.a, c3.saaddh.a, c3.samulh.a, c3.sasub.a, c3.sasubh.a
	STRING disasmBb_07 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.ld
	STRING disasmBb_09 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.mac, c3.macci, c3.maccr, c3.macd, c3.macdn, c3.macn, c3.mula, c3.mulaci, c3.mulacr, c3.mulad, c3.muladn, c3.mulan
	STRING disasmBb_10 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.mac.a, c3.macn.a, c3.mula.a
	STRING disasmBb_11 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.mac.ar, c3.macn.ar, c3.mula.ar
	STRING disasmBb_12 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.mac.i, c3.macn.i, c3.mula.i
	STRING disasmBb_13 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.mvfs
	STRING disasmBb_14 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.mvts
	STRING disasmBb_15 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.lead
	STRING disasmBb_17 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.revb
	STRING disasmBb_19 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.st
	STRING disasmBb_20 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.muls, c3.mulus
	STRING disasmBb_21 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.saadds, c3.saaddsh, c3.samulsh, c3.sasubs, c3.sasubsh
	STRING disasmBb_22 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.round
	STRING disasmBb_23 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.saddha
	STRING disasmBb_24 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.saddha.a
	STRING disasmBb_25 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.dadda, c3.dmac, c3.dmacn, c3.dmula, c3.dmulan, c3.dsuba
	STRING disasmBb_26 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.dmac.a, c3.dmacn.a, c3.dmula.a, c3.dmulan.a
	STRING disasmBb_27 (ADDR pc, SL1Instr* instr, UINT meta); //, c3.ffe
};

const STRING ar_register_mode[8] = {
	"nc","+1", "+2", "+4", "$as", "-1","-2","-4"
	};
const STRING c3_ldst_type[5] = {
	"byte","ubyte","hword","uhword","word"
};	
const STRING c3_mem_mode[2] = {
	"MEM","CBU"
};	
const STRING c3_bit_mode[5] = {
	"nop","clear","set","invert"
};

#endif /*SL1DISASM_H_*/
