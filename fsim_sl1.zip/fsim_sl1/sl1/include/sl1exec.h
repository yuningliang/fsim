#ifndef SL1EXEC_H_
#define SL1EXEC_H_

#include "cexec.h"
#include "sl1reg.h"
#include "sl1mmu.h"
#include "sl1defs.h"
#include "sl1ffe.h"
#include "sl1instr.h"
#include "sl1viterbi.h"
#include "sl1traceback.h"

//mode define moved to sl1defs.h


class SL1Exec : public CoreExec<SL1MMU, SL1Register, SL1Instr> {
	private:
	SL1FFE& _ffe;
	SL1VITERBI& _viterbi;
	SL1TRACEBACK& _traceback;
	
	private:
	void _updateSize(UINT index, BYTE am, BYTE bsel,UINT dtype,UINT ar_order)
	{
		ADDR ad = reg().getAR(index);
		pair<ADDR, ADDR> cbuf;
		if(CBUFFER(bsel) && ar_order==ARONE) {
			cbuf = mmu().getCbufAddr(CBUFFER_ID(bsel));
			if(ad<cbuf.first || ad>cbuf.second)	
			   DevWarn("Exec: invalid circular buffer address");
			//AppFatal(((ad>=cbuf.first)&&(ad<=cbuf.second)), ("Exec: invalid circular buffer address (0x%x).", ad));
		}
		switch(am){
			case ADD_1:
				ad += dtype;
				break;
			case ADD_2:
				ad += dtype*2;
				break;
			case ADD_4:
				ad += dtype*4;
				break;
			case SUB_1:
				ad -= dtype;
				break;
			case SUB_2:
				ad -= dtype*2;
				break;
			case SUB_4:
				ad -= dtype*4;
				break;
			case SIZE_REGISTER:
				ad += reg().getAR_USIZE(index);
				break;
			case NORMAL_MODE:
			    break;
			default:
				AppFatal((0), ("Exec: invalid ar mode (%d).", am));
				break;
		}
		if(CBUFFER(bsel) && ar_order==ARONE) {
			if(ad<cbuf.first) {
				ad = cbuf.second;
			}			
			if(ad>cbuf.second) {
				ad = cbuf.first;
			}
		}		
		reg().setAR(index,ad);
	}

	DWORD _calAccResult(DWORD dest,UBYTE acm){
		if(acm & ROUND_MODE)
		   dest = ((dest +0x8000) >>16)<<16;   
		if(acm & SATURATION_MODE) 
		{						
			if(dest>SATURATION_MAX)
			   dest = SATURATION_MAX;
			 else if(dest<SATURATION_MIN)  
			    dest = SATURATION_MIN; 
			
		}
		return dest;
	}
	
	DWORD _saturateGPR32(DWORD dest)
	{
		if(dest>SATURATION_MAX)
			dest = SATURATION_MAX;
	    else if(dest<SATURATION_MIN)  
		 	dest = SATURATION_MIN;
		return dest; 	 
	}
	
	WORD _saturateGPR16(WORD dest)
	{
		if(dest>SATURATION_MAX16)
			dest = SATURATION_MAX16;
	    else if(dest<SATURATION_MIN16)  
		 	dest = SATURATION_MIN16;
		return dest; 	 
	}
	public:	
	SL1Exec(SL1MMU& mmu, SL1Register& reg, ProcessStatus<SL1Instr>& status);
	SL1FFE& ffe(void) { return _ffe; }
	SL1VITERBI& viterbi(void) { return _viterbi;}
	SL1TRACEBACK& traceback(void) { return _traceback;}

	ADDR execute(ADDR addr, SL1Instr* instr) {
		ADDR ret_addr;
		pc(addr);
		ret_addr = (this->*(instr->exec()))(instr);
		status().logExec(addr, ret_addr, instr);
		return loopMode(addr, ret_addr);
	}	

	ADDR execC3bitc (SL1Instr* instr);
	ADDR execC3bitr (SL1Instr* instr);
	ADDR execC3dadd (SL1Instr* instr);
	ADDR execC3dmac (SL1Instr* instr);
	ADDR execC3dmaca (SL1Instr* instr);
	ADDR execC3dmacn (SL1Instr* instr);
	ADDR execC3dmacna (SL1Instr* instr);
	ADDR execC3dmula (SL1Instr* instr);
	ADDR execC3dmulaa (SL1Instr* instr);
	ADDR execC3dmulan (SL1Instr* instr);
	ADDR execC3dmulana (SL1Instr* instr);
	ADDR execC3dshlli (SL1Instr* instr);
	ADDR execC3dshrli (SL1Instr* instr);
	ADDR execC3dsub (SL1Instr* instr);
	ADDR execC3fft (SL1Instr* instr);
	ADDR execC3ld (SL1Instr* instr);
	ADDR execC3lead (SL1Instr* instr);
	ADDR execC3mac (SL1Instr* instr);
	ADDR execC3maca (SL1Instr* instr);
	ADDR execC3macar (SL1Instr* instr);
	ADDR execC3macci (SL1Instr* instr);
	ADDR execC3maccr (SL1Instr* instr);
	ADDR execC3macd (SL1Instr* instr);
	ADDR execC3macdn (SL1Instr* instr);
	ADDR execC3maci (SL1Instr* instr);
	ADDR execC3macn (SL1Instr* instr);
	ADDR execC3macna (SL1Instr* instr);
	ADDR execC3macnar (SL1Instr* instr);
	ADDR execC3macni (SL1Instr* instr);
	ADDR execC3mula (SL1Instr* instr);
	ADDR execC3mulaa (SL1Instr* instr);
	ADDR execC3mulaar (SL1Instr* instr);
	ADDR execC3mulaci (SL1Instr* instr);
	ADDR execC3mulacr (SL1Instr* instr);
	ADDR execC3mulad (SL1Instr* instr);
	ADDR execC3muladn (SL1Instr* instr);
	ADDR execC3mulai (SL1Instr* instr);
	ADDR execC3mulan (SL1Instr* instr);
	ADDR execC3mulha (SL1Instr* instr);
	ADDR execC3muls (SL1Instr* instr);
	ADDR execC3mulus (SL1Instr* instr);
	ADDR execC3mvfs (SL1Instr* instr);
	ADDR execC3mvts (SL1Instr* instr);
	ADDR execC3revb (SL1Instr* instr);
	ADDR execC3round (SL1Instr* instr);
	ADDR execC3saadda (SL1Instr* instr);
	ADDR execC3saaddha (SL1Instr* instr);
	ADDR execC3saadds (SL1Instr* instr);
	ADDR execC3saaddsh (SL1Instr* instr);
	ADDR execC3saddha (SL1Instr* instr);
	ADDR execC3saddhaa (SL1Instr* instr);
	ADDR execC3samulha (SL1Instr* instr);
	ADDR execC3samulsh (SL1Instr* instr);
	ADDR execC3sashllh (SL1Instr* instr);
	ADDR execC3sasuba (SL1Instr* instr);
	ADDR execC3sasubha (SL1Instr* instr);
	ADDR execC3sasubs (SL1Instr* instr);
	ADDR execC3sasubsh (SL1Instr* instr);
	ADDR execC3st (SL1Instr* instr);
	ADDR execC3viterbi(SL1Instr* instr);
	ADDR execC3traceback(SL1Instr* instr);
};
#endif /*EXEC_H_*/
