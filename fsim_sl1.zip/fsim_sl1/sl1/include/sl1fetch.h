#ifndef SL1FETCH_H_
#define SL1FETCH_H_

#include "fetch.h"
#include "sl1decoder.h"

class SL1MMU;
//class SL1Decoder;
class SL1Instr;

class SL1Fetch : public Fetch<SL1MMU, SL1Decoder, SL1Instr> {
	public:
	SL1Fetch(SL1MMU& mmu, Address& addr, ProcessStatus<SL1Instr>& status) 
		: Fetch<SL1MMU, SL1Decoder, SL1Instr>(mmu, addr, status) {
		}
};

#endif /*SL1FETCH_H_*/
