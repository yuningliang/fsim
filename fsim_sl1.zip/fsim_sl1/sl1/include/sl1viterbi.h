#ifndef SL1VITERBI_H_
#define SL1VITERBI_H_

#include "sl1defs.h"

#define MAX_SHIFT_SIZE 8
#define VITERBI_FINISHED 1
#define VITERBI_USED 0
#define UNDEF_ADDR 0xffffffff
class SL1MMU;

class SL1VITERBI{
	
	private:
	SL1MMU& _mmu;
	UINT16 _scalingValue;
	BOOL _delayWriteEnable;
	INT _writeLogSize;
	ADDR* _writeLogAddr;
	WORD* _writeLogData;
	WORD* _orgData; //the orignal data
		
	private:
	void _readInputData(UINT *dest,ADDR res,UINT len);
	//void _writeOutputData(ADDR dest, UINT* res,UINT len);
	UINT _writeOutputShift(UINT *dest,UINT* res,UINT cons_len_sub_one);
	public:
	SL1VITERBI(SL1MMU& m);
	WORD exec(ADDR rs1,WORD rs2);
	SL1MMU& mmu(void) { return _mmu; }
	void setScalingValue(INT a) {_scalingValue=a;}
	INT getScalingValue(void) { return _scalingValue;}
	void resultWriteBack(void);
	BOOL delayWriteEnable(void) { return _delayWriteEnable; }
	void delayWriteEnable(BOOL t) { _delayWriteEnable = t; }
		
	INT writeLogSize(void) { return _writeLogSize; }
	ADDR* writeLogAddr(void) { return _writeLogAddr; }
	WORD* writeLogData(void) { return _writeLogData; }
};

#endif /*SL1VITERBI_H_*/
