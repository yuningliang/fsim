#ifndef SL1FFE_H_
#define SL1FFE_H_

#include "sl1defs.h"

class SL1MMU;

#define FFE_ADDR_BASE_MASK (0xffff0000)
#define FFE_ADDR_BANK_START (2)
#define FFE_ADDR_BANK_MASK (0x7)
#define FFE_ADDR_BANK_LOW_MASK (0x3)
#define FFE_HIGH_32_BANK_START (15)
#define FFE_ADDR_OFFSET_START (2)
#define FFE_ADDR_OFFSET_MASK (0x7ffc)
#define FFE_BANK_NUM 4


class SL1FFE {
	private:
	SL1MMU& _mmu;
	BOOL _delayWriteEnable;
	INT _writeLogSize;
	ADDR* _writeLogAddr;
	WORD* _writeLogData;
	WORD* _orgData; //the orignal data
	
	private:
	void _readFFTData(INT point, double* real_in, double* img_in
			, ADDR fft_base, INT bank0, INT bank1, INT bank2, INT bank3,INT pre_flag);
	void _writeFFTData(INT point, INT bit_shift, double* real_in, double* img_in
			, ADDR fft_base, INT bank0, INT bank1, INT bank2, INT bank3,INT post_flag);		
	
	public:
	SL1FFE(SL1MMU& m);
	SL1MMU& mmu(void) { return _mmu; }
	BOOL delayWriteEnable(void) { return _delayWriteEnable; }
	void delayWriteEnable(BOOL t) { _delayWriteEnable = t; }

	void resultWriteBack(void);
	INT writeLogSize(void) { return _writeLogSize; }
	ADDR* writeLogAddr(void) { return _writeLogAddr; }
	WORD* writeLogData(void) { return _writeLogData; }
	WORD exec(WORD rs1, WORD rs2);
	ADDR addrCovert(ADDR base, INT bank, INT offset);
};

#endif /*SL1FFT_H_*/
