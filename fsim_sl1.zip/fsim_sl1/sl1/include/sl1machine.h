#ifndef SL1MACHINE_H_
#define SL1MACHINE_H_

#include "sl1defs.h"
#include "machine.h"

class SL1MMU;
class SL1Fetch;
class SL1Exec;
class SL1Instr;
class SL1Disasm;
class SL1Register;

#define SL1_INTERRUPT_LIST_INI SL1MMU, SL1Exec, SL1Instr

class SL1Machine : public Machine<SL1MMU, SL1Register, SL1Fetch, SL1Exec, SL1Instr, SL1Disasm, SL1Machine> {
	public:
	SL1Machine(SL1MMU& mmu, SL1Fetch& fetch, ProcessStatus<SL1Instr>& status) : 
	Machine<SL1MMU, SL1Register, SL1Fetch, SL1Exec, SL1Instr, SL1Disasm, SL1Machine>(mmu, fetch, status) {
		_eHandler = new EventHandler<SL1MMU, SL1Register, SL1Machine>(*(&mmu), this);
	}
};

#endif /*SL1MACHINE_H_*/
