#ifndef SL1INSTRPAGE_H_
#define SL1INSTRPAGE_H_

#include "instrpage.h"

class SL1Instr;

class SL1InstrPage : InstrPage<SL1Instr> {
}

#endif /*SL1INSTRPAGE_H_*/
