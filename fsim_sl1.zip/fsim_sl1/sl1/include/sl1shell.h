#ifndef SL1SHELL_H_
#define SL1SHELL_H_

#include "sl1defs.h"
#include "memory.h"
#include "sl1address.h"
#include "sl1instr.h"
#include "status.h"
#include "sl1mmu.h"
#include "sl1reg.h"
#include "sl1exec.h"
#include "sl1fetch.h"
#include "sl1decoder.h"
#include "sl1disasm.h"
#include "sl1machine.h"
#include "shell.h"

class SL1Shell : public Shell<SL1_CLASS_LIST>{
	public:
	SL1Shell(void);
};

#endif /*SL1SHELL_H_*/
