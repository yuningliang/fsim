#ifndef SL1INSTRID_H_
#define SL1INSTRID_H_

#include "cinstrid.h"
//Instruction ID
#define c3saadds_id 0x300
#define c3saadda_id 0x301
#define c3bitc_id 0x302
#define c3bitr_id 0x303
#define c3saddha_id 0x304
#define c3saddhaa_id 0x305
#define c3ld_id 0x306
#define c3sashllh_id 0x307
#define c3mac_id 0x308
#define c3maca_id 0x309
#define c3macar_id 0x30a
#define c3maci_id 0x30b
#define c3samulsh_id 0x30c
#define c3samulha_id 0x30d
#define c3sasubha_id 0x30e
#define c3saaddha_id 0x30e
#define c3mulha_id 0x30e
#define c3macci_id 0x30f
#define c3maccr_id 0x310
#define c3macd_id 0x311
#define c3macn_id 0x312
#define c3macna_id 0x313
#define c3macnar_id 0x314
#define c3macni_id 0x315
#define c3mula_id 0x316
#define c3mulaa_id 0x317
#define c3mulaar_id 0x318
#define c3mulai_id 0x319
#define c3mulaci_id 0x31a
#define c3mulacr_id 0x31b
#define c3mulad_id 0x31c
#define c3macdn_id 0x31d
#define c3mulan_id 0x31e
#define c3muladn_id 0x31f
#define c3lead_id 0x320
#define c3mvfs_id 0x321
#define c3mvts_id 0x322
#define c3dmac_id 0x323
#define c3dmacn_id 0x324
#define c3dmaca_id 0x325
#define c3dmacna_id 0x326
#define c3dadd_id 0x327
#define c3dsub_id 0x328
#define c3revb_id 0x329
#define c3round_id 0x32a
#define c3dmula_id 0x32b
#define c3dmulan_id 0x32c
#define c3dmulaa_id 0x32d
#define c3dmulana_id 0x32e
#define c3dshlli_id 0x333
#define c3dshrli_id 0x334
#define c3st_id 0x335
#define c3sasubsh_id 0x336
#define c3sasuba_id 0x337
#define c3muls_id 0x338
#define c3mulus_id 0x339
#define c3saaddsh_id 0x33a
#define c3sasubs_id 0x33b
#define c3fft_id 0x33c
#define c3viterbi_id 0x33d
#define c3traceback_id 0x33e
#endif
