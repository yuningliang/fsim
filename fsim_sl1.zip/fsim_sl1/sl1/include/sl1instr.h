#ifndef SL1INSTR_H_
#define SL1INSTR_H_

#include "defs.h"
#include "sl1instrtable.h"
#include "sl1regdefs.h"
#include "cinstr.h"


class SL1Instr : public CoreInstr {
	private:
	//instruction info from instr table
	SL1ExecPtr _exec;
	SL1DisasmPtr _print;
	SL1EINSTR_GR _group;
	
	//bit field
	struct Reg _sreg0;
	struct Reg _sreg0p;//pair acc
	struct Reg _sreg1;
	struct Reg _sreg2;

	UBYTE _modf9_6;  // b_mode
	UBYTE _modf23_21;	//acm 
	UBYTE _modf17_15;  // am1
	UBYTE _modf11_9;  // am2, dtype
	UBYTE _modf7_6;  // bsel, alu_mode
	UBYTE _modf8_8;  // N
	UBYTE _modf22_22; //c_flag
		
	public:	
	void getRegList(RegList* destList, RegList* srcList);
	SL1Instr() : CoreInstr(){
		init();
	}
	void init(SL1InstrTableEntry* entry, WORD raw) {
		_mn = entry->mn();
		_id = entry->id();
		_group = entry->group();
		_exec = entry->exec();
		_print =  entry->print();
		_rawbits = raw;
	}
	void init() {
		CoreInstr::init();
#if _INCLUDE_REG_DETAIL
		_sreg0.status = ERS_UNDEF;
		_sreg0p.status = ERS_UNDEF;
		_sreg1.status = ERS_UNDEF;
		_sreg2.status = ERS_UNDEF;
#endif
		
	}
	
	SL1ExecPtr exec(void) { return _exec; }
	SL1DisasmPtr print(void) { return _print; }
	SL1EINSTR_GR group(void) { return _group; }	

	UINT32 acc(void) { return _sreg0.index; }
	void acc(UINT32 r) {  //read acc only
		REG_DETAIL(_sreg0, ERS_WRITE, EBASE_ACC)
		_sreg0.index = r; 
	}
	UINT32 acc_pair(void) { return _sreg0.index; }
	void acc_pair(UINT32 r) {  //read acc only
		REG_DETAIL(_sreg0, ERS_WRITE, EBASE_ACC)
		_sreg0.index = r; 
		REG_DETAIL(_sreg0p, ERS_WRITE, EBASE_ACC)
		_sreg0p.index = r+1; 		
	}	
	//rd, sd, ad
	UINT32 sd(void) { return _sreg0.index; }
	void sd(UINT32 r) { 
		REG_DETAIL(_sreg0, ERS_WRITE, EBASE_AR)
		_sreg0.index = r; 
	}


	//rs1, as1, cs1, ss1
	UINT32 as1(void) { return _sreg1.index; }
	void as1(UINT32 r)  { 
		REG_DETAIL(_sreg1, ERS_NO_HAZARD, EBASE_AR)
		_sreg1.index = r; 
	}
	
	UINT32 ss1(void) { return _sreg1.index; }
	void ss1(UINT32 r) { 
		REG_DETAIL(_sreg1, ERS_READ, EBASE_AR)
		_sreg1.index = r; 
	}
	
	//rs2, as2

	UINT32 as2(void) { return _sreg2.index; }
	void as2(UINT32 r)  { 
		REG_DETAIL(_sreg2, ERS_NO_HAZARD, EBASE_AR)
		_sreg2.index = r; 
	}

	//_modf7_6
	UBYTE mode(void) { return _modf7_6; }
	void mode(UBYTE m) { _modf7_6 = m; }	
	UBYTE bsel(void) { return _modf7_6; }
	void bsel(UBYTE b) { _modf7_6 = b; }
	
	//_modf23_21
	UBYTE acm(void) { return _modf23_21; }
	void acm(UBYTE a) { _modf23_21 = a; }
	
	//_modf22_22
	UBYTE c_flag(void) { return _modf22_22; }
	void c_flag(UBYTE c) { _modf22_22 = c; }
	
	//_modf17_15
	UBYTE am1(void) { return _modf17_15; }
	void am1(UBYTE a) { _modf17_15 = a; }

	//_modf11_9
	UBYTE am2(void) { return _modf11_9; }
	void am2(UBYTE a) { _modf11_9 = a; }
	UBYTE dtype(void) { return _modf11_9; }
	void dtype(UBYTE d) { _modf11_9 = d; }
	
	//modf9
	UBYTE N(void) { return _modf8_8; }
	void N(UBYTE n) { _modf8_8 = n; }
	
	//modf9_6
	INT imm_hi(void) { return _modf15_11; }
	void imm_hi(INT m) { _modf15_11 = m; }		

	//modf9_6
	INT imm_lo(void) { return _modf10_6; }
	void imm_lo(INT m) { _modf10_6 = m; }	
	
	//modf9_6
	UBYTE b_mode(void) { return _modf9_6; }
	void b_mode(UBYTE m) { _modf9_6 = m; }		
	
	pair<INT, INT> gprRegPort();
	pair<INT, INT> ctrlRegPort();
	pair<INT, INT> addrRegPort();
	pair<INT, INT> addrUpdateRegPort();
	pair<INT, INT> accPort();
	
};

#endif /*SL1INSTR_H_*/
