#ifndef REGISTER_H_
#define REGISTER_H_

#include "defs.h"
#include "creg.h"
#include "sl1regdefs.h"
#include "status.h"

class SL1Instr;

class SL1Register : public CoreRegister<SL1Instr> {
	private:
	WORD _ar[REG_AR_CUR_SIZE];
	WORD _ar_usize[REG_AR_CUR_SIZE];
	DWORD _acc[REG_ACC_CUR_SIZE];
	WORD _hi;
	WORD _ffe_fft;
	WORD _ffe_viterbi;
	WORD _ffe_trback;
	WORD _statusReg;
	
	private:
	
	public:
	SL1Register(ProcessStatus<SL1Instr>& status, UINT thid);
	INT createNameMap(RegMap& regmap);	// create register name map and return map size

	//register checking interface switch
	void enableRegChecker(BOOL t) {
	}
	
	void clear();
	
	WORD getStatusReg(void) { return _statusReg; }
	void setStatusReg(WORD s) { _statusReg = s; }
	
	WORD getGPR16(UINT32 index) { 
		AppFatal((index<REG_GPR_SIZE), ("Register: invalid gpr index (%d) @0x%08x.", index, status().pre_pc()));
		INT16 tmp = _gpr[index];
		return ((WORD)tmp);
	}
	void setGPR16(UINT32 index, WORD data) {
		if(index==0){
			REG0_WRITE_WARN
		 	data = 0;
		}
		AppFatal((index<REG_GPR_SIZE), ("Register: invalid gpr index (%d) @0x%08x.", index, status().pre_pc()));
		data &= HWORD_DATA_MASK;
		LOG_REG_WRITE(index, EBASE_GPR, data)
		_gpr[index] = data;
	}

	//BB ctrl regs
	WORD getHI(void) { 
		return _hi;
	}	
	void setHI(WORD data) { 
		LOG_REG_WRITE(ESR_HI, EBASE_HI, data)
		_hi = data;
	}
		
	DWORD getACC(UINT32 index) { 
		AppFatal((index<REG_ACC_CUR_SIZE), ("Register: invalid acc index (%d) @0x%08x.", index, status().pre_pc()));
		return _acc[index];
	}
	void setACC(UINT32 index, DWORD data) { 
		AppFatal((index<REG_ACC_CUR_SIZE), ("Register: invalid acc index (%d) @0x%08x.", index, status().pre_pc()));
		LOG_REG_WRITE(index, EBASE_ACC, data)
		_acc[index] = data;
	}	
	UWORD getAR(UINT32 index) {
		AppFatal((index<REG_AR_CUR_SIZE), ("Register: invalid ar index (%d) @0x%08x.", index, status().pre_pc())); 
		return (_ar[index]);
	}
	void setAR(UINT32 index, UWORD data) { 
		AppFatal((index<REG_AR_CUR_SIZE), ("Register: invalid ar index (%d) @0x%08x.", index, status().pre_pc())); 
		LOG_REG_WRITE(index, EBASE_AR, data)
		_ar[index] = data;
	}	
	UWORD getAR_USIZE(UINT32 index) {
		AppFatal((index<REG_AR_CUR_SIZE), ("Register: invalid ar_usize index (%d) @0x%08x.", index, status().pre_pc())); 
		return (_ar_usize[index]);
	}
	void setAR_USIZE(UINT32 index, UWORD data) { 
		AppFatal((index<REG_AR_CUR_SIZE), ("Register: invalid ar_usize index (%d) @0x%08x.", index, status().pre_pc())); 
		LOG_REG_WRITE(index, EBASE_AR_USIZE, data)
		_ar_usize[index] = data;
	}
	void setFFE_FFT(WORD data){ _ffe_fft = data; }
	WORD getFFE_FFT(void) { return _ffe_fft; }
	
	void setFFE_VITERBI(WORD data){ _ffe_viterbi = data; }
	WORD getFFE_VITERBI(void) { return _ffe_viterbi; }
	
	void setFFE_TRBACK(WORD data){ _ffe_trback = data; }
	WORD getFFE_TRBACK(void) { return _ffe_trback; }
	
	void setSPEC(UINT32 index, DWORD data) { 
		AppFatal((index<REG_ALL_C3_SPEC_SIZE), ("Register: invalid spec reg index (%d) @0x%08x.", index, status().pre_pc())); 
		if(index==ESR_HI) {
			setHI(data);
		}
		else if(index>=ESR_AR && index<(ESR_AR+REG_AR_CUR_SIZE)) {
			_ar[index] = (WORD)data;
		}
		else if(index>=ESR_AR_USIZE &&index<(ESR_AR_USIZE+REG_AR_CUR_SIZE)) {
			_ar_usize[index-ESR_AR_USIZE] = (WORD)data;
		}		
		else if(index>=ESR_ACC &&index<ESR_HI) {
			_acc[index-ESR_ACC] = data;
		}
		else if(index==ESR_FFT) {
			_ffe_fft = data;
		}
		else if(index==ESR_VITERBI) {
			_ffe_viterbi = data;
		}
		else if(index==ESR_TRBACK){
			_ffe_trback = data;
		}
		else if(index==ESR_STATUS){
			AppFatal((0), ("Register: status spec reg is read only", status().pre_pc())); 
		}		
		else {
			AppFatal((0), ("Register: invalid spec reg index (%d) @0x%08x.", index, status().pre_pc())); 
		}
	}		
	WORD getSPEC(UINT32 index) { 
		AppFatal((index<REG_ALL_C3_SPEC_SIZE), ("Register: invalid spec reg index (%d) @0x%08x.", index, status().pre_pc())); 
		if(index==ESR_HI) {
			return getHI();
		}
		else if(index>=ESR_AR && index<(ESR_AR+REG_AR_CUR_SIZE)) {
			return _ar[index];
		}
		else if(index>=ESR_AR_USIZE &&index<(ESR_AR_USIZE+REG_AR_CUR_SIZE)) {
			return _ar_usize[index-ESR_AR_USIZE];
		}		
		else if(index>=ESR_ACC &&index<ESR_HI) {
			return _acc[index-ESR_ACC];
		}
		else if(index==ESR_FFT) {
			return _ffe_fft;
		}
		else if(index==ESR_VITERBI) {
			return _ffe_viterbi;
		}
		else if(index==ESR_TRBACK) {
			return _ffe_trback;
		}
		else if(index==ESR_STATUS){
			return _statusReg;
		}			
		else {
			AppFatal((0), ("Register: invalid spec reg index (%d) @0x%08x.", index, status().pre_pc())); 
			return ESR_UNDEF;
		}
	}
	EREG_SPEC getSPECIndex(UINT32 index) { 
		AppFatal((index<REG_ALL_C3_SPEC_SIZE), ("Register: invalid spec reg index (%d) @0x%08x.", index, status().pre_pc())); 
		if(index>=ESR_AR &&index<(ESR_AR+REG_AR_CUR_SIZE)) {
			return ESR_AR;
		}
		if(index>=ESR_AR_USIZE &&index<(ESR_AR_USIZE+REG_AR_CUR_SIZE)) {
			return ESR_AR_USIZE;
		}		
		else if(index>=ESR_ACC &&index<ESR_MAX) {
			return ESR_ACC;
		}
		else if(index==ESR_HI) {
			return ESR_HI;
		}
		else {
			AppFatal((0), ("Register: invalid spec reg index (%d) @0x%08x.", index, status().pre_pc())); 
			return ESR_UNDEF;
		}
	}
	INT getRegIndexByName(const STRING regName);
	INT setRegByName(const STRING regName, const DWORD value);
	INT getRegisterNames(char *buf, int len);
	bool isValidRegName(const STRING regName);
	void dumpRegs(FILE* out, const char* regSetName);	
	void dumpRegs2File(FILE* out, const char* regSetName);	
	INT initRegs(FILE *in, const char* regSetName);
};
const STRING reg_name_c3_spec[REG_ALL_C3_SPEC_SIZE] = {
	"ar0", "ar1", "ar2", "ar3",
	"ar4", "ar5", "ar6", "ar7",
	"ar_usize0", "ar_usize1", "ar_usize2", "ar_usize3",
	"ar_usize4", "ar_usize5", "ar_usize6", "ar_usize7",
	"acc0", "acc1", "acc2", "acc3", "hi","ffe_fft","ffe_viterbi","ffe_trback",
};

#endif /*REGISTER_H_*/
