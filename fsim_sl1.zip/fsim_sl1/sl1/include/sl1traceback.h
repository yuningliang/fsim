#ifndef SL1TRACEBACK_H_
#define SL1TRACEBACK_H_

#define TRACEBACK_FINISHED 1
#define TRACEBACK_USED 0
#define MEM_BANK_WIDTH 32
class SL1MMU;


class SL1TRACEBACK{
	private:
	SL1MMU& _mmu;
	BOOL _delayWriteEnable;
	INT _writeLogSize;
	ADDR* _writeLogAddr;
	WORD* _writeLogData;
	WORD* _orgData; //the orignal data

	private:
	void _readInputData(UINT *dest,ADDR res,UINT memPerState,UINT iter_count);
	void _writeOutputData(ADDR dest, UINT* res,UINT len);
	
	public:
	SL1TRACEBACK(SL1MMU& m);
	SL1MMU& mmu(void) { return _mmu; }
	WORD exec(ADDR rs1,WORD rs2);
	BOOL delayWriteEnable(void) { return _delayWriteEnable; }
	void delayWriteEnable(BOOL t) { _delayWriteEnable = t; }
	void resultWriteBack(void);
	INT writeLogSize(void) { return _writeLogSize; }
	ADDR* writeLogAddr(void) { return _writeLogAddr; }
	WORD* writeLogData(void) { return _writeLogData; }

};

#endif
