#ifndef SL1DECODER_H_
#define SL1DECODER_H_

#include "cdecoder.h"
#include "sl1defs.h"

class SL1Instr;

class SL1Decoder : public CoreDecoder<SL1Instr>{
	
	public:
	SL1Decoder(void); 
	SL1Decoder(BOOL b);
	UINT32 decode (SL1Instr* instr,  ADDR pc, WORD raw);
	UINT32 decode (SL1Instr* instr,  ADDR pc, WORD raw, UINT meta); //psim uses
	class SL1InstrTableEntry* choose_entry(WORD raw);

	//autogen

//Instruction decoding function

	UINT32 decodeBb_01 (SL1Instr* instr, UINT meta); //, c3.sashllh
	UINT32 decodeBb_02 (SL1Instr* instr, UINT meta); //, c3.dshll.i, c3.dshrl.i
	UINT32 decodeBb_03 (SL1Instr* instr, UINT meta); //, c3.bitc
	UINT32 decodeBb_04 (SL1Instr* instr, UINT meta); //, c3.bitr
	UINT32 decodeBb_06 (SL1Instr* instr, UINT meta); //, c3.mulh.a, c3.saadd.a, c3.saaddh.a, c3.samulh.a, c3.sasub.a, c3.sasubh.a
	UINT32 decodeBb_07 (SL1Instr* instr, UINT meta); //, c3.ld
	UINT32 decodeBb_09 (SL1Instr* instr, UINT meta); //, c3.mac, c3.macci, c3.maccr, c3.macd, c3.macdn, c3.macn, c3.mula, c3.mulaci, c3.mulacr, c3.mulad, c3.muladn, c3.mulan
	UINT32 decodeBb_10 (SL1Instr* instr, UINT meta); //, c3.mac.a, c3.macn.a, c3.mula.a
	UINT32 decodeBb_11 (SL1Instr* instr, UINT meta); //, c3.mac.ar, c3.macn.ar, c3.mula.ar
	UINT32 decodeBb_12 (SL1Instr* instr, UINT meta); //, c3.mac.i, c3.macn.i, c3.mula.i
	UINT32 decodeBb_13 (SL1Instr* instr, UINT meta); //, c3.mvfs
	UINT32 decodeBb_14 (SL1Instr* instr, UINT meta); //, c3.mvts
	UINT32 decodeBb_15 (SL1Instr* instr, UINT meta); //, c3.lead
	UINT32 decodeBb_17 (SL1Instr* instr, UINT meta); //, c3.revb
	UINT32 decodeBb_19 (SL1Instr* instr, UINT meta); //, c3.st
	UINT32 decodeBb_20 (SL1Instr* instr, UINT meta); //, c3.muls, c3.mulus
	UINT32 decodeBb_21 (SL1Instr* instr, UINT meta); //, c3.saadds, c3.saaddsh, c3.samulsh, c3.sasubs, c3.sasubsh
	UINT32 decodeBb_22 (SL1Instr* instr, UINT meta); //, c3.round
	UINT32 decodeBb_23 (SL1Instr* instr, UINT meta); //, c3.saddha
	UINT32 decodeBb_24 (SL1Instr* instr, UINT meta); //, c3.saddha.a
	UINT32 decodeBb_25 (SL1Instr* instr, UINT meta); //, c3.dadda, c3.dmac, c3.dmacn, c3.dmula, c3.dmulan, c3.dsuba
	UINT32 decodeBb_26 (SL1Instr* instr, UINT meta); //, c3.dmac.a, c3.dmacn.a, c3.dmula.a, c3.dmulan.a
	UINT32 decodeBb_27 (SL1Instr* instr, UINT meta); //, c3.ffe
};



#endif /*DECODER_H_*/
