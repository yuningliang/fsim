#include "sl1reg.h"
#include "status.h"
#include "messg.h"

SL1Register::SL1Register(ProcessStatus<SL1Instr>& status, UINT thid) 
								: CoreRegister<SL1Instr>(status) {
	clear();
	setStatusReg(thid&REG_STATUS_THREADID_MASK);
}

/*
 * We don't check register name length. So we have to make sure register name length must be < REG_NAME_SIZE.
 * Register table layout:
 * 		gpr 0.31
 * 		hi 32
 * 		lo 33
 * 		ja 34
 * 		ra 35
 * 		loop_cnt 36..43
 * 		loop_offset 44..51
 * 		loop_cur	52..59
 * 		acc			60..63
 * 		ar			68..71
 */
//move it to sl1reg.h 
/*const STRING reg_name_c3_spec[REG_ALL_C3_SPEC_SIZE] = {
	"acc0", "acc1", "acc2", "acc3", 
	"ar0", "ar1", "ar2", "ar3",
	"ar4", "ar5", "ar6", "ar7",
};*/

INT SL1Register::createNameMap(RegMap& regmap)
{
	INT i;
	CoreRegister<SL1Instr>::createNameMap(regmap);

	// ar
	for (i=0; i<REG_AR_CUR_SIZE; i++) {
		regmap[reg_name_c3_spec[i]] = new RegMapItem(reg_name_c3_spec[i], WORD_BYTE, (BYTE*) &_ar[i]);
		regmap[reg_name_c3_spec[i+REG_AR_CUR_SIZE]] = new RegMapItem(reg_name_c3_spec[i+REG_AR_CUR_SIZE], WORD_BYTE, (BYTE*) &_ar_usize[i]);
	}
	for (i=0; i<REG_ACC_CUR_SIZE; i++) {
		regmap[reg_name_c3_spec[i+(2*REG_AR_CUR_SIZE)]] = new RegMapItem(reg_name_c3_spec[i+(2*REG_AR_CUR_SIZE)], DWORD_BYTE, (BYTE*) &_acc[i]);
	}
	regmap[reg_name_c3_spec[ESR_HI]] = new RegMapItem(reg_name_c3_spec[ESR_HI], WORD_BYTE, (BYTE*) &_hi);
	regmap[reg_name_c3_spec[ESR_FFT]] = new RegMapItem(reg_name_c3_spec[ESR_FFT], WORD_BYTE, (BYTE*) &_ffe_fft);
	regmap[reg_name_c3_spec[ESR_VITERBI]] = new RegMapItem(reg_name_c3_spec[ESR_VITERBI],WORD_BYTE,(BYTE*) &_ffe_viterbi);
	regmap[reg_name_c3_spec[ESR_TRBACK]] = new RegMapItem(reg_name_c3_spec[ESR_TRBACK],WORD_BYTE,(BYTE*) &_ffe_trback);
	return regmap.size();
}

void SL1Register::clear() {
	INT i;
	CoreRegister<SL1Instr>::clear();	
	for(i = 0; i<REG_ACC_CUR_SIZE; i++) {
		 _acc[i] = 0;
	}
	for(i = 0; i<REG_AR_CUR_SIZE; i++) {
		 _ar[i] = 0;
	}
	for(i = 0; i<REG_AR_CUR_SIZE; i++) {
		 _ar_usize[i] = 0;
	}	
	_hi = 0;
	_ffe_fft = 0;
	_ffe_viterbi = 0;
	_ffe_trback = 0;
	_statusReg = 0;
}


INT SL1Register::initRegs(FILE* in,  const char* regSetName) {

	INT line = CoreRegister<SL1Instr>::initRegs(in, regSetName);

	if(line>=0) {
		if(strcasecmp(regSetName, "all")==0||strcasecmp(regSetName, "bb")) {
			INT i;
			WORD data = 0;
			char str[50];	
			// ar
			for (i=0; i<REG_AR_CUR_SIZE; i++) {
				line++;
				if(fscanf(in, "%x%[^\n]", &data, str)!=EOF) {
					setAR(i, data);
				}
				else {
					return (-line);
				}					
			}
			// ar_usize
			for (i=0; i<REG_AR_CUR_SIZE; i++) {
				line++;
				if(fscanf(in, "%x%[^\n]", &data, str)!=EOF) {
					setAR_USIZE(i, data);
				}
				else {
					return (-line);
				}					
			}			
			// acc
			for (i=0; i<REG_ACC_CUR_SIZE; i++) {
				line++;
				if(fscanf(in, "%x%[^\n]", &data, str)!=EOF) {
					setACC(i, data);
				}
				else {
					return (-line);
				}				
			}
			line++;
			if(fscanf(in, "%x%[^\n]", &data, str)!=EOF) {
				setHI(data);
			}
			line++;
			if(fscanf(in, "%x%[^\n]", &data, str)!=EOF) {
				setFFE_FFT(data);
			}
			line++;
			if(fscanf(in, "%x%[^\n]", &data, str)!=EOF) {
				setFFE_VITERBI(data);
			}
			line++;
			if(fscanf(in, "%x%[^\n]", &data, str)!=EOF) {
				setFFE_TRBACK(data);
			}
			else {
				return (-line);
			}			
		}
	}
	return line;
}

void SL1Register::dumpRegs2File(FILE* out, const char* regSetName) {
	CoreRegister<SL1Instr>::dumpRegs2File(out, regSetName);
	if(strcasecmp(regSetName, "all")==0||strcasecmp(regSetName, "bb")) {
		INT i;
		// ar
		for (i=0; i<REG_AR_CUR_SIZE; i++) {
			fprintf(out, "%08x \\\\ %s\n", (UWORD)getAR(i), reg_name_c3_spec[i]);
		}
		// ar_usize
		for (i=0; i<REG_AR_CUR_SIZE; i++) {
			fprintf(out, "%08x \\\\ %s\n", (UWORD)getAR_USIZE(i), reg_name_c3_spec[i+REG_AR_CUR_SIZE]);
		}
		// acc
		for (i=0; i<REG_ACC_CUR_SIZE; i++) {
			fprintf(out, "%08x \\\\ %s\n", (WORD)getACC(i), reg_name_c3_spec[i+(2*REG_AR_CUR_SIZE)]);
		}
		fprintf(out, "%0*x \\\\ %s\n", 8/*getRegWidth()*/, getHI(), reg_name_c3_spec[ESR_HI]);
		fprintf(out, "%0*x \\\\ %s\n", 8/*getRegWidth()*/, getFFE_FFT(), reg_name_c3_spec[ESR_FFT]);
		fprintf(out, "%0*x \\\\ %s\n", 8/*getRegWidth()*/, getFFE_VITERBI(), reg_name_c3_spec[ESR_VITERBI]);
		fprintf(out, "%0*x \\\\ %s\n", 8/*getRegWidth()*/, getFFE_TRBACK(), reg_name_c3_spec[ESR_TRBACK]);
	}
}	


void SL1Register::dumpRegs(FILE* out, const char* regSetName) {
	CoreRegister<SL1Instr>::dumpRegs(out, regSetName);
	if(strcasecmp(regSetName, "all")==0||strcasecmp(regSetName, "bb")==0) {
		INT i;
		fprintf(out, "C3 reg:\n");
		// ar
		for (i=0; i<REG_AR_CUR_SIZE; i++) {
			fprintf(out, "%5s=%08x ", reg_name_c3_spec[i], getAR(i));
			if (i%REG_PRINT_PER_LINE == (REG_PRINT_PER_LINE-1))
				fprintf(out, "\n");
		}
		if (i<REG_AR_CUR_SIZE)
			fprintf(out, "\n");
		// ar_usize
		for (i=0; i<REG_AR_CUR_SIZE; i++) {
			fprintf(out, "%5s=%08x ", reg_name_c3_spec[i+REG_AR_CUR_SIZE], getAR_USIZE(i));
			if (i%REG_PRINT_PER_LINE == (REG_PRINT_PER_LINE-1))
				fprintf(out, "\n");
		}
		if (i<REG_AR_CUR_SIZE)
			fprintf(out, "\n");
		for (i=0; i<REG_ACC_CUR_SIZE; i++) {
			fprintf(out, "%5s=%08x ", reg_name_c3_spec[i+(2*REG_AR_CUR_SIZE)], (WORD)getACC(i));
		}
		fprintf(out, "\n");	
		// register hi
		fprintf(out, "%5s=%0*x ", reg_name_c3_spec[ESR_HI], 8, getHI());
		fprintf(out, "%s=%0*x ", reg_name_c3_spec[ESR_FFT], 8, getFFE_FFT());
		fprintf(out, "%s=%0*x ", reg_name_c3_spec[ESR_VITERBI], 8, getFFE_VITERBI());
		fprintf(out, "%s=%0*x ", reg_name_c3_spec[ESR_TRBACK], 8, getFFE_TRBACK());		
		fprintf(out, "\n");			
	}
}	

INT SL1Register::setRegByName(const STRING regName, const DWORD value) {
	INT i;
	
	// Check if the register belongs to parent
	if (CoreRegister<SL1Instr>::setRegByName(regName, value) == 0)
		return 0;
	// ar
	for (i=0; i<REG_AR_CUR_SIZE; i++) {
		if (strcmp(reg_name_c3_spec[i], regName) == 0) {
			setAR(i, value);
			return 0;
		}
	}
	// ar_usize
	for (i=0; i<REG_AR_CUR_SIZE; i++) {
		if (strcmp(reg_name_c3_spec[i+REG_AR_CUR_SIZE], regName) == 0) {
			setAR_USIZE(i, value);
			return 0;
		}
	}
	// acc
	for (i=0; i<REG_ACC_CUR_SIZE; i++) {
		if (strcmp(reg_name_c3_spec[i+(2*REG_AR_CUR_SIZE)], regName) == 0) {
			setACC(i, value);
			return 0;
		}
	}
	if(strcmp(reg_name_c3_spec[ESR_HI],regName)==0){
		setHI(value);
		return 0;
	}
	if(strcmp(reg_name_c3_spec[ESR_FFT],regName)==0){
		setFFE_FFT(value);
		return 0;
	}
	if(strcmp(reg_name_c3_spec[ESR_VITERBI],regName)==0){
		setFFE_VITERBI(value);
		return 0;
	}
	if(strcmp(reg_name_c3_spec[ESR_TRBACK],regName)==0){
		setFFE_TRBACK(value);
		return 0;
	}
	return -1;
}	

bool SL1Register::isValidRegName(const STRING regName) {
	INT i;
	
	// Check if the register belongs to parent
	if (CoreRegister<SL1Instr>::isValidRegName(regName))
		return true;
	for (i=0; i<REG_ALL_C3_SPEC_SIZE; i++) {
		if (strcmp(reg_name_c3_spec[i], regName) == 0) {
			return true;
		}
	}
	return false;
}	

INT SL1Register::getRegIndexByName(const STRING regName)
{
	INT i;
	i = CoreRegister<SL1Instr>::getRegIndexByName(regName);
//	if(i<0) {
//		for (i=0; i<REG_ALL_C3_SPEC_SIZE; i++) {
//			if (strcmp(reg_name_c3_spec[i], regName)==0)
//				return i;
//		}			
//	}
	//acc, ar
	return i;	// not found
}

INT SL1Register::getRegisterNames(char *buf, int len) {
	INT i;
	
	if (CoreRegister<SL1Instr>::getRegisterNames(buf, len) != 0)
		return -1;
	int cc = strlen(buf);
	for (i=0; i<REG_ALL_C3_SPEC_SIZE; i++) {
		cc += sprintf(buf+cc, "%s ", reg_name_c3_spec[i]);
		if (i%4 == 3)
			cc += sprintf(buf+cc, "\n");
	}
	if (cc >= len)
		return -1;
	buf[cc] = '\0';
	return 0;
}
