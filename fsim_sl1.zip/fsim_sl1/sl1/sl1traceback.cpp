#include "sl1mmu.h"
#include "sl1traceback.h"

#ifndef _SKIP_TRACEBACK
#define _SKIP_TRACEBACK 0
#endif

#ifdef __cplusplus
extern "C" {
#endif

#if _SKIP_TRACEBACK
#define traceback_PLI(iter_counter, current_state, constraint_sub_one, shifter_memory, decoder_memory) 0
#else
extern void traceback_PLI(int iter_counter, int current_state, int constraint_sub_one,
                                   unsigned int *shifter_memory, unsigned int *decoder_memory);
#endif
#ifdef __cplusplus
}
#endif

SL1TRACEBACK::SL1TRACEBACK(SL1MMU& m) : _mmu(m){
	_delayWriteEnable = FALSE;
	_writeLogSize = 0;
	_writeLogAddr = NULL;
	_writeLogData = NULL;
	_orgData = NULL;
}

void SL1TRACEBACK::resultWriteBack(void)
{
	if(_delayWriteEnable==TRUE) {
		AppFatal((_writeLogSize>0), ("SL1TRACEBACK: TRACEBACK data write log is empty."));
		AppFatal((_writeLogAddr!=NULL), ("SL1TRACEBACK: TRACEBACK addr log is NULL."));
		AppFatal((_writeLogData!=NULL), ("SL1TRACEBACK: TRACEBACK data log is NULL."));
		AppFatal((_orgData!=NULL), ("SL1TRACEBACK: TRACEBACK original data log is NULL."));
		for(INT i = 0; i<_writeLogSize; i++) {
			WORD org_data = mmu().getWord(_writeLogAddr[i]);
			AppFatal((_orgData[i]!=org_data), ("SL1TRACEBACK: The data @0x%x has been changed during the TRACEBACK execution.", _writeLogAddr[i]));
			mmu().setWord(_writeLogAddr[i], _writeLogData[i]);
		}
		_writeLogSize = 0; //indicate all data has handled
	}
}

void SL1TRACEBACK::_readInputData(UINT *dest,ADDR res,UINT mem_per_state,UINT iter_count)
{
	INT i,iter;
	for(i=0;i<mem_per_state;i++)
		dest[mem_per_state*iter_count-1-i] = mmu().getWord(res+(mem_per_state-1-i)*WORD_BYTE);
	iter = iter_count-1;
	for(i=0;i<mem_per_state*iter;i++)
		dest[mem_per_state*iter-1-i] = mmu().getWord(res-WORD_BYTE*(i+1));
}

void SL1TRACEBACK::_writeOutputData(ADDR dest, UINT* res,UINT len)
{
	INT i;
	if(_delayWriteEnable==FALSE)
	{
		for(i=0;i<len;i++)
			mmu().setWord(dest-i*WORD_BYTE,res[len-1-i]);
	}
	else
	{
		_writeLogAddr = new ADDR[len];
		_writeLogData = new WORD[len];
		_orgData = new WORD[len];
		_writeLogSize = len;
		for(i=0;i<len;i++)
		{
			_writeLogAddr[i] = dest-i*WORD_BYTE;
			_writeLogData[i] = res[len-1-i];
			_orgData[i] = mmu().getWord(dest-i*WORD_BYTE);
		}
					
	}
}

WORD SL1TRACEBACK::exec(ADDR rs1, WORD rs2) {
	union{
		WORD rs;
		struct{
			unsigned non_use: 4;
			unsigned k_1: 4;
			unsigned current_state: 8;
			unsigned iter_counter: 16;
		}bits;
	}rsgpr;
	if(_delayWriteEnable==TRUE) {
	 	AppFatal((_writeLogSize==0), ("TRACEBACK have been used twice!"));
		if(_writeLogAddr!=NULL) {
			delete _writeLogAddr;
		}
		if(_writeLogData!=NULL) {
			delete _writeLogData;
		}
		if(_orgData!=NULL) {
			delete _orgData;
		}		 	
	}
	rsgpr.rs = rs2;
	UINT iter_counter = rsgpr.bits.iter_counter;
	UINT current_state = rsgpr.bits.current_state;
	UINT constraint_sub_one = rsgpr.bits.k_1;
	
	ADDR input_shifter_ptr = mmu().getWord(rs1);
	ADDR output_ptr = mmu().getWord(rs1+WORD_BYTE);
	UINT decoder_memory_number = (iter_counter/MEM_BANK_WIDTH) + ((iter_counter%MEM_BANK_WIDTH) != 0);
	UINT state_number = 1<<constraint_sub_one;
	UINT memory_per_stage = (constraint_sub_one == 4) ? 1 :  (state_number/MEM_BANK_WIDTH);
	
	UINT *shifter_memory,*decoder_memory;
	shifter_memory = new UINT[iter_counter*memory_per_stage];
	decoder_memory = new UINT[decoder_memory_number];
	
	_readInputData(shifter_memory,input_shifter_ptr,memory_per_stage,iter_counter);
	traceback_PLI(iter_counter, current_state, constraint_sub_one, shifter_memory, decoder_memory);
	_writeOutputData(output_ptr, decoder_memory,decoder_memory_number);
	
	delete shifter_memory;
	delete decoder_memory;
	
	if(_delayWriteEnable==FALSE)
		return TRACEBACK_FINISHED;
	else 
	 	return TRACEBACK_USED;
}
