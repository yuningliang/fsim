#include "sl1mmu.h"
#include "sl1reg.h"
#include "sl1instr.h"
#include "sl1disasm.h"
#include "sl1defs.h"

SL1Disasm::SL1Disasm(SL1MMU& mmu, SL1Register& reg, UINT th_id) 
	: CoreDisasm<SL1MMU, SL1Register, SL1Instr>(mmu, reg, th_id) {
}

//, c3.sashllh
STRING SL1Disasm::disasmBb_01 (ADDR pc, SL1Instr* instr, UINT meta) {
      sprintf(strbuf(),"0x%08x: 0x%08x  %-5s  r%d,r%d,r%d <0x%x,0x%x,0x%x >\n", 
             pc,
             instr->rawbits(),
             instr->mn(),
             instr->rd(),
             instr->rs1(),
             instr->rs2(),
             reg().getGPR(instr->rd()) ,
             reg().getGPR(instr->rs1()) ,
             reg().getGPR(instr->rs2()) );
	return RET_STRBUF(pc);
}

//, c3.dshll.i, c3.dshrl.i
STRING SL1Disasm::disasmBb_02 (ADDR pc, SL1Instr* instr, UINT meta) {
	sprintf(strbuf(),"0x%08x: 0x%08x  %-5s  r%d, r%d, %d, %d   < 0x%x,0x%x >\n", 
             	pc,
             	instr->rawbits(),
             	instr->mn(),
             	instr->rd(),
             	instr->rs1(),
		instr->imm_hi(),
		instr->imm_lo(),
		reg().getGPR(instr->rd()) ,
		reg().getGPR(instr->rs1()));
	return RET_STRBUF(pc);  
}

//, c3.bitc
STRING SL1Disasm::disasmBb_03 (ADDR pc, SL1Instr* instr, UINT meta) {
	UINT b_mode = instr->b_mode();
	AppFatal((b_mode>=NOP && b_mode<BIT_MAX), ("invalid b_mode(%d),pc@0x%x", b_mode, pc));
	sprintf(strbuf(),"0x%08x: 0x%08x  %-5s  %s,%d,%s <0x%08x >\n", 
             pc,
             instr->rawbits(),
             instr->mn(),
             reg_name_c3_spec[instr->sd()],
             instr->imm4(),
             c3_bit_mode[b_mode],
             reg().getSPEC(instr->sd()));
	return RET_STRBUF(pc);
}

//, c3.bitr
STRING SL1Disasm::disasmBb_04 (ADDR pc, SL1Instr* instr, UINT meta) {
	UINT b_mode = instr->b_mode();
	AppFatal((b_mode>=NOP && b_mode<BIT_MAX), ("invalid b_mode(%d),pc@0x%x", b_mode, pc));
	sprintf(strbuf(),"0x%08x: 0x%08x  %-5s r%d,r%d,%d,%s <0x%x,0x%x>  \n", 
             pc,
             instr->rawbits(),
             instr->mn(),
             instr->rd(),
             instr->rs1(),
             instr->imm4(),
             c3_bit_mode[b_mode],
             reg().getGPR(instr->rd()) ,
             reg().getGPR(instr->rs1()) );
	return RET_STRBUF(pc);
}

//, c3.mulh.a, c3.saadd.a, c3.saaddh.a, c3.samulh.a, c3.sasub.a, c3.sasubh.a
STRING SL1Disasm::disasmBb_06 (ADDR pc, SL1Instr* instr, UINT meta) {
	UINT bsel = instr->bsel();   
	sprintf(strbuf(),"0x%08x: 0x%08x  %-5s r%d,ar%d,%s,ar%d,%s,%s <0x%x,0x%08x,0x%08x >\n",
	       pc,
           instr->rawbits(),
           instr->mn(),
           instr->rd(),
           instr->as1(),
           ar_register_mode[instr->am1()],
           instr->as2(),
           ar_register_mode[instr->am2()],
           c3_mem_mode[bsel],
           reg().getGPR(instr->rd()) ,
           reg().getAR(instr->as1()),
           reg().getAR(instr->as2()));
    return RET_STRBUF(pc);   
}

//, c3.ld
STRING SL1Disasm::disasmBb_07 (ADDR pc, SL1Instr* instr, UINT meta) {
	UINT type = instr->dtype();
	AppFatal((type<=WORDS && type>=BYTES), ("invalid dtype(%d),pc@0x%x", type, pc));
	UINT bsel = instr->bsel();   
	sprintf(strbuf(),"0x%08x: 0x%08x  %-5s r%d,ar%d,%s,%s,%s <0x%x,0x%08x>\n",
	       pc,
           instr->rawbits(),
           instr->mn(),
           instr->rd(),
           instr->as1(),
           ar_register_mode[instr->am1()],
           c3_ldst_type[type],
           c3_mem_mode[bsel],
           reg().getGPR(instr->rd()) ,
           reg().getAR(instr->as1()));
	     
	 return RET_STRBUF(pc);  
}

//, c3.mac, c3.macci, c3.maccr, c3.macd, c3.macdn, c3.macn, c3.mula, c3.mulaci, c3.mulacr, c3.mulad, c3.muladn, c3.mulan
STRING SL1Disasm::disasmBb_09 (ADDR pc, SL1Instr* instr, UINT meta) {
	sprintf(strbuf(),"0x%08x: 0x%08x  %-5s acc%d,%d,r%d,r%d <0x%08x,0x%x,0x%x>\n",
	       pc,
           instr->rawbits(),
           instr->mn(),
           instr->acc(),
           instr->acm(),
           instr->rs1(),
           instr->rs2(),
           (INT)reg().getACC(instr->acc()),
           reg().getGPR(instr->rs1()) ,
           reg().getGPR(instr->rs2()) );
	return RET_STRBUF(pc);
}

//, c3.mac.a, c3.macn.a, c3.mula.a
STRING SL1Disasm::disasmBb_10 (ADDR pc, SL1Instr* instr, UINT meta) {
	UINT bsel = instr->bsel();   
	sprintf(strbuf(),"0x%08x: 0x%08x  %-5s acc%d, %d,ar%d,%s,ar%d,%s,%s <0x%08x,0x%08x,0x%08x>\n",
	       pc,
           instr->rawbits(),
           instr->mn(),
           instr->acc(), 
           instr->acm(),
           instr->as1(),
           ar_register_mode[instr->am1()],
           instr->as2(),
           ar_register_mode[instr->am2()],
           c3_mem_mode[bsel],
           (INT)reg().getACC(instr->acc()),
           reg().getAR(instr->as1()),
           reg().getAR(instr->as2()));
	return RET_STRBUF(pc);	  
}

//, c3.mac.ar, c3.macn.ar, c3.mula.ar
STRING SL1Disasm::disasmBb_11 (ADDR pc, SL1Instr* instr, UINT meta) {
	UINT bsel = instr->bsel();   
	sprintf(strbuf(),"0x%08x: 0x%08x  %-5s acc%d,%d,r%d,ar%d,%s,%s <0x%08x,0x%x,0x%08x>\n",
	       pc,
           instr->rawbits(),
           instr->mn(),
           instr->acc(), 
           instr->acm(),
           instr->rs1(),
           instr->as2(),
           ar_register_mode[instr->am2()],
           c3_mem_mode[bsel],
           (INT)reg().getACC(instr->acc()),
           reg().getGPR(instr->rs1()) ,
           reg().getAR(instr->as2()));
	return RET_STRBUF(pc);	 
}

//, c3.mac.i, c3.macn.i, c3.mula.i
STRING SL1Disasm::disasmBb_12 (ADDR pc, SL1Instr* instr, UINT meta) {
	sprintf(strbuf(),"0x%08x: 0x%08x  %-5s acc%d,%d,r%d,%d <0x%08x,0x%x>\n",
	       pc,
           instr->rawbits(),
           instr->mn(),
           instr->acc(), 
           instr->acm(),
           instr->rs1(),
           instr->imm10(),
           (INT)reg().getACC(instr->acc()),
           reg().getGPR(instr->rs1()));
	return RET_STRBUF(pc);	
}

//, c3.mvfs
STRING SL1Disasm::disasmBb_13 (ADDR pc, SL1Instr* instr, UINT meta) {
    AppFatal((instr->ss1() < ESR_MAX), ("invalid control register name(%d),pc@0x%x", instr->ss1(), pc));
    UWORD cs = reg().getSPEC(instr->ss1());
    /*
    if(instr->ss1()<ESR_AR_USIZE) { //is ar 
	  	cs = reg().getAR(instr->ss1());//acc
	}
	else if(instr->ss1()<ESR_ACC){ //is ar_update
		// ar address = gpr - SRAM base address
	    cs = reg().getAR_USIZE(instr->ss1()-REG_AR_SIZE);
	}
	else
	{
		cs = reg().getACC(instr->ss1()-2*REG_AR_SIZE);
	}  
	*/
    sprintf(strbuf(),"0x%08x: 0x%08x  %-5s r%d,%s,%d <0x%x,0x%08x>\n",
            pc,
            instr->rawbits(),
            instr->mn(),
            instr->rd(),
            reg_name_c3_spec[instr->ss1()],
            instr->imm5(),
            reg().getGPR(instr->rd()) ,
            cs);		
	return RET_STRBUF(pc);
}

//, c3.mvts
STRING SL1Disasm::disasmBb_14 (ADDR pc, SL1Instr* instr, UINT meta) {
    AppFatal((instr->sd() < ESR_MAX), ("invalid control register name(%d),pc@0x%x", instr->cd(), pc));
    UWORD cs = reg().getSPEC(instr->ss1());
    /*
//    printf("sd:%d\n",instr->sd());
    if(instr->sd()<ESR_AR_USIZE) { //is ar 
	  	cs = reg().getAR(instr->sd());//acc
	}
	else if(instr->sd()<ESR_ACC){ //is ar_update
		// ar address = gpr - SRAM base address
	    cs = reg().getAR_USIZE(instr->sd()-REG_AR_SIZE);
	}
	else
	{
		cs = reg().getACC(instr->sd()-2*REG_AR_SIZE);
	}
	*/
    sprintf(strbuf(),"0x%08x: 0x%08x  %-5s %s,r%d,%d <0x%08x,0x%x>\n",
            pc,
            instr->rawbits(),
            instr->mn(),
            reg_name_c3_spec[instr->sd()],
            instr->rs1(),
            instr->imm5(),
            cs,
            reg().getGPR(instr->rs1()));
	       return RET_STRBUF(pc);
}

//, c3.lead
STRING SL1Disasm::disasmBb_15 (ADDR pc, SL1Instr* instr, UINT meta) {
	UINT mode = instr->mode();
    AppFatal(((mode==CNT_ZERO || mode==CNT_ONE)), ("invalid mode(%d),pc@0x%x", mode, pc));
	sprintf(strbuf(),"0x%08x: 0x%08x  %-5s r%d,acc%d,%d <0x%x,0x%08x>\n",
	       pc,
           instr->rawbits(),
           instr->mn(), 
           instr->rd(),
           instr->acc(),
           mode,
           reg().getGPR(instr->rd()) ,
           (INT)reg().getACC(instr->acc()));
	return RET_STRBUF(pc);
}

//, c3.revb
STRING SL1Disasm::disasmBb_17 (ADDR pc, SL1Instr* instr, UINT meta) {
	sprintf(strbuf(),"0x%08x: 0x%08x  %-5s r%d,r%d,%d <0x%x,0x%x>\n",
	       pc,
           instr->rawbits(),
           instr->mn(),
           instr->rd(),
           instr->rs1(),
           instr->imm4(),
           reg().getGPR(instr->rd()) ,
           reg().getGPR(instr->rs1()) );
	return RET_STRBUF(pc);
}

//, c3.st
STRING SL1Disasm::disasmBb_19 (ADDR pc, SL1Instr* instr, UINT meta) {
	UINT type = instr->dtype();
	AppFatal((type==WORDS || type==BYTES || type==HALF), ("invalid dtype(%d),pc@0x%x", type, pc));
	UINT bsel = instr->bsel();   
	sprintf(strbuf(),"0x%08x: 0x%08x  %-5s r%d,%s,ar%d,%s,%s <0x%x,0x%08x>\n",
	       pc,
           instr->rawbits(),
           instr->mn(),
           instr->rs0(),
           c3_ldst_type[type],
           instr->as1(),
           ar_register_mode[instr->am1()],
           c3_mem_mode[bsel],
           reg().getGPR(instr->rd()) ,
           reg().getAR(instr->as1()));
	     
	 return RET_STRBUF(pc); 
}

//, c3.muls, c3.mulus
STRING SL1Disasm::disasmBb_20 (ADDR pc, SL1Instr* instr, UINT meta) {
	sprintf(strbuf(),"0x%08x: 0x%08x  %-5s r%d,r%d,r%d,%d <0x%x,0x%x,0x%x>\n",
	       pc,
           instr->rawbits(),
           instr->mn(),
           instr->rd(),
           instr->rs1(),
           instr->rs2(),
           instr->imm5(),
           reg().getGPR(instr->rd()),
           reg().getGPR(instr->rs1()) ,
           reg().getGPR(instr->rs2()) );
           return RET_STRBUF(pc);
}

//, c3.saadds, c3.saaddsh, c3.samulsh, c3.sasubs, c3.sasubsh
STRING SL1Disasm::disasmBb_21 (ADDR pc, SL1Instr* instr, UINT meta) {
	sprintf(strbuf(),"0x%08x: 0x%08x  %-5s r%d,r%d,r%d,%d <0x%x,0x%x,0x%x>\n",
	       pc,
           instr->rawbits(),
           instr->mn(),
           instr->rd(),
           instr->rs1(),
           instr->rs2(),
           instr->imm5(),
           reg().getGPR(instr->rd()),
           reg().getGPR(instr->rs1()) ,
           reg().getGPR(instr->rs2()) );
           return RET_STRBUF(pc);
}

//, c3.round
STRING SL1Disasm::disasmBb_22 (ADDR pc, SL1Instr* instr, UINT meta) {
	UINT mode = instr->mode();
	AppFatal(((mode== NORMAL || mode==SET_LOW || mode==CLEAR_LOW)), ("invalid mode(%d),pc@0x%x", mode, pc));
	sprintf(strbuf(),"0x%08x: 0x%08x  %-5s acc%d,%d,%d <0x%08x>\n",
	       pc,
	       instr->rawbits(),
	       instr->mn(),
	       instr->acc(),
	       instr->imm5()&0x1f,
	       mode,
	       (INT)reg().getACC(instr->acc()));
	return RET_STRBUF(pc);
}

//, c3.saddha
STRING SL1Disasm::disasmBb_23 (ADDR pc, SL1Instr* instr, UINT meta) {
	sprintf(strbuf(),"0x%08x: 0x%08x  %-5s acc%d,%d,r%d,%d,%d < 0x%08x, 0x%x >\n",
	       pc,
	       instr->rawbits(),
	       instr->mn(),
	       instr->acc(),
	       instr->acm(),
	       instr->rs1(),
	       instr->imm5(),
	       instr->N(),
	       (INT)reg().getACC(instr->acc()),
	       reg().getGPR(instr->rs1()) );
	return RET_STRBUF(pc);	
}

//, c3.saddha.a
STRING SL1Disasm::disasmBb_24 (ADDR pc, SL1Instr* instr, UINT meta) {
	UINT bsel = instr->bsel();   
	sprintf(strbuf(),"0x%08x: 0x%08x  %-5s acc%d,%d,ar%d,%s,%d,%d,%s <0x%08x,0x%08x>\n",
	       pc,
	       instr->rawbits(),
	       instr->mn(),
	       instr->acc(),
	       instr->acm(),
	       instr->as1(),
	       ar_register_mode[instr->am1()],
	       instr->imm4(),
	       instr->N(),
	       c3_mem_mode[bsel],
	       (INT)reg().getACC(instr->acc()),
	       reg().getAR(instr->as1()));
	return RET_STRBUF(pc);	
}

//, c3.dadda, c3.dmac, c3.dmacn, c3.dmula, c3.dmulan, c3.dsuba
STRING SL1Disasm::disasmBb_25 (ADDR pc, SL1Instr* instr, UINT meta) {
	sprintf(strbuf(),"0x%08x: 0x%08x  %-5s acc%d,%d,r%d,r%d <0x%08x,0x%x,0x%x>\n",
	       pc,
           instr->rawbits(),
           instr->mn(),
           instr->acc(),
           instr->acm(),
           instr->rs1(),
           instr->rs2(),
           (INT)reg().getACC(instr->acc()),
           reg().getGPR(instr->rs1()) ,
           reg().getGPR(instr->rs2()) );
	return RET_STRBUF(pc);
}

//, c3.dmac.a, c3.dmacn.a, c3.dmula.a, c3.dmulan.a
STRING SL1Disasm::disasmBb_26 (ADDR pc, SL1Instr* instr, UINT meta) {
	UINT bsel = instr->bsel();   
	sprintf(strbuf(),"0x%08x: 0x%08x  %-5s acc%d, %d,ar%d,%s,ar%d,%s,%s <0x%08x,0x%08x,0x%08x>\n",
	       pc,
           instr->rawbits(),
           instr->mn(),
           instr->acc(), 
           instr->acm(),
           instr->as1(),
           ar_register_mode[instr->am1()],
           instr->as2(),
           ar_register_mode[instr->am2()],
           c3_mem_mode[bsel],
           (INT)reg().getACC(instr->acc()),
           reg().getAR(instr->as1()),
           reg().getAR(instr->as2()));
	return RET_STRBUF(pc);	
}

//, c3.ffe
STRING SL1Disasm::disasmBb_27 (ADDR pc, SL1Instr* instr, UINT meta) {
	sprintf(strbuf(),"0x%08x: 0x%08x  %-5s r%d,r%d <0x%x,0x%x,0x%x>\n",
	       pc,
           instr->rawbits(),
           instr->mn(),
           instr->rs1(),
           instr->rs2(),
           reg().getGPR(instr->rd()),
           reg().getGPR(instr->rs1()) ,
           reg().getGPR(instr->rs2()) );
           return RET_STRBUF(pc);
}
