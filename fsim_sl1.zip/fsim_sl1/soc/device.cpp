#include "device.h"


Device::Device(System* const sys, ADDR base) :
	InterfaceHandler::InterfaceHandler(sys->mmu().memory(), base),
	_system(sys)
{
}

System* const Device::system()
{
	return _system;
}

ADDR Device::baddr()
{
	return _start;
}
