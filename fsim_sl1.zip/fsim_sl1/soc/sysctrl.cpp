#include "sysctrl.h"
#include "cmmu.h"
#include "defs.h"
#include "system.h"


SysCtrl::SysCtrl(System* const sys, ADDR base) : 
	Device(sys, base) {
	
}

inline void SysCtrl::syncReg(SYSCTRL_REGS reg, dev_u32 val) 
{
	system()->mmu().setWord(baddr()+reg, val);
}

inline dev_u32 SysCtrl::regreset()
{
	syncReg(SYSCTRL_RSTC, _RESET);
	return _RESET;
}

inline dev_u32 SysCtrl::regconfig()
{
	syncReg(SYSCTRL_CFIG, _CONFIG);
	return _CONFIG;	
}

inline void SysCtrl::regreset(dev_u32 val)
{
	_RESET = val;
	regreset();
}

inline void SysCtrl::regconfig(dev_u32 val)
{
	_CONFIG = val;
	regconfig();
}


void SysCtrl::reset()
{
	_RESET = 0;
	_CONFIG = 0;
}

void SysCtrl::tick()
{
}

void SysCtrl::readHook(ADDR addr) {
	dev_u32 ret;
	SYSCTRL_REGS offset = (SYSCTRL_REGS)(addr - baddr());
	switch (offset) {
	case SYSCTRL_CFIG:
		regconfig();
		break;
	case SYSCTRL_RSTC:
		regreset();
		break;
	}
}

void SysCtrl::writeHook(ADDR addr) {
	dev_u32 val = system()->mmu().getWord(addr);
	SYSCTRL_REGS offset = (SYSCTRL_REGS)(addr - baddr());
//	printf("%x\n", system()->mmu().getWord(0x73c));
	switch (offset) {
	case SYSCTRL_CFIG:
		regconfig(val);
		break;
	case SYSCTRL_RSTC:
		regreset(val);
		if ((_CONFIG & CFIG_CPU_ACTIVE_MASK) > 0 && 
		  (_RESET & RSTC_CPU_MASK) > 0) {
			system()->setReset(THREAD_ID_0, System::RESET_ENABLE);
//			system()->trap(THREAD_ID_0, System::TRAP_RESET);
		} else if ((_CONFIG & CFIG_CPU_ACTIVE_MASK) == 0 && 
		  (_RESET & RSTC_CPU_MASK) > 0) {
			system()->setReset(THREAD_ID_0, System::RESET_DISABLE);
//			system()->trap(THREAD_ID_0, System::TRAP_RESET);
		}			
			
		if ((_CONFIG & CFIG_DSP_ACTIVE_MASK) > 0 && 
		  (_RESET & RSTC_DSP_MASK) > 0) {
			system()->setReset(THREAD_ID_1, System::RESET_ENABLE);
//			system()->trap(THREAD_ID_1, System::TRAP_RESET);
		} else if ((_CONFIG & CFIG_DSP_ACTIVE_MASK) == 0 && 
			  (_RESET & RSTC_DSP_MASK) > 0) {
			system()->setReset(THREAD_ID_1, System::RESET_DISABLE);
//			system()->trap(THREAD_ID_1, System::TRAP_RESET);
		}			
		break;
	}
}
