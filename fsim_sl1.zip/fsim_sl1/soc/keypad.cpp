#include "keypad.h"

Keypad::Keypad(System* const sys, ADDR base) : Device(sys, base)
{
}

inline void Keypad::syncReg(KEYPAD_REGS reg, dev_u32 val) {
	system()->mmu().setWord(baddr()+reg, val);
}

void Keypad::reset()
{
	syncReg(KEYP_CTRL, 0x8040);
	syncReg(KEYP_CONF, 0x400002);
	syncReg(KEYP_STAT, 0);
	syncReg(KEYP_ICR, 0);
	syncReg(KEYP_FLGR, 0);
}

void Keypad::readHook(ADDR addr)
{
	ADDR offset = addr - baddr();
	switch (offset) {
	case KEYP_CTRL:
		break;
	case KEYP_CONF:
		break;
	case KEYP_STAT:
		break;
	case KEYP_KCODE:
		break;
	case KEYP_ICR:
		break;
	case KEYP_FLGR:
		break;
	}
}

void Keypad::writeHook(ADDR addr)
{
	ADDR offset = addr - baddr();
	switch (offset) {
	case KEYP_CTRL:
		break;
	case KEYP_CONF:
		break;
	case KEYP_ICR:
		break;
	case KEYP_FLGR:
		break;
	default:
		printf("write operation don't support\n");
	}
}

void Keypad::tick()
{
}
