#include "timer.h"

Timer::Timer(System* const sys, ADDR base) : Device(sys, base)
{
}

inline void Timer::syncReg(TIMER_REGS reg, dev_u32 val) {
	system()->mmu().setWord(baddr()+reg, val);
}

inline dev_u32 Timer::regcompare()
{
	syncReg(TIMER_TLC, _TLC);
	return _TLC;
}

inline dev_u32 Timer::regcount()
{
	syncReg(TIMER_TCV, _TCV);
	return _TCV;
}

inline dev_u32 Timer::regcontrol()
{
	syncReg(TIMER_TCR, _TCR.value);
	return _TCR.value;
}

inline dev_u32 Timer::regclear()
{
	syncReg(TIMER_TIC, _TIS);
	if (_TCR.bit.TES && !_TCR.bit.TAC) {
		_cycle_start = system()->getCycles();
		if (_TCR.bit.TMS)
			system()->addSchedule(this, regcompare());
		else
			system()->addSchedule(this, 0xffffffff);
	}
	return _TIS;
}

inline dev_u32 Timer::regstatus()
{
	syncReg(TIMER_TIS, _TIS);
	return _TIS;
}

inline void Timer::regcompare(dev_u32 val)
{
	_TLC = val;
	regcompare();
}

inline void Timer::regcount(dev_u32 val)
{
	_TCV = val;
	regcount();
}

inline void Timer::regcontrol(dev_u32 val)
{
	int active = _TCR.bit.TES;
	_TCR.value = val;
	// Users disabled timer
	if (active && (!_TCR.bit.TES)) {
		regcount(regcompare() - (system()->getCycles() - _cycle_start));
	}
	if (_TCR.bit.TES) {
		_cycle_start = system()->getCycles();
		system()->removeSchedule(this);
		if (_TCR.bit.TMS)
			system()->addSchedule(this, regcompare());
		else
			system()->addSchedule(this, 0xffffffff);
	}
	regcontrol();
}

inline void Timer::regstatus(dev_u32 val)
{
	_TIS = val;
	regstatus();
}


void Timer::reset()
{
	regcompare(0xffffffff);
	regcount(0xffffffff);
	regcontrol(0);
	regstatus(0);
}

void Timer::readHook(ADDR addr)
{
	ADDR offset = addr - baddr();
	switch (offset) {
	case TIMER_TLC:
		regcompare();
		break;
	case TIMER_TCV:
		if (_TCR.bit.TES)
			regcount(regcompare() - (system()->getCycles() - _cycle_start));
		break;
	case TIMER_TCR:
		regcontrol();
		break;
	case TIMER_TIC:
		regstatus(0);
		regclear();
		break;
	case TIMER_TIS:
		regstatus();
		break;
	}
}

void Timer::writeHook(ADDR addr)
{
	dev_u32 val = system()->mmu().getWord(addr);
	ADDR offset = addr - baddr();
	switch (offset) {
	case TIMER_TLC:
		regcompare(val);
		break;
	case TIMER_TCV:
		regcount();
		break;
	case TIMER_TCR:
		regcontrol(val & 0xf);
		break;
	case TIMER_TIC:
		regclear();
		break;
	case TIMER_TIS:
		regstatus();
		break;
	}
}

void Timer::tick()
{
	if (_TCR.bit.TAC) {
		_cycle_start = system()->getCycles();
		if (_TCR.bit.TMS)
			system()->addSchedule(this, regcompare());
		else
			system()->addSchedule(this, 0xffffffff);
	}
	if (!_TCR.bit.TIM) {
		switch(baddr()) {
		case SimConfig::TIMER0_BASE_ADDR:
			system()->trap(System::TRAP_INT_TIMER0);
			break;
		case SimConfig::TIMER1_BASE_ADDR:
			system()->trap(System::TRAP_INT_TIMER1);
			break;
		case SimConfig::TIMER2_BASE_ADDR:
			system()->trap(System::TRAP_INT_TIMER2);
			break;
		case SimConfig::TIMER3_BASE_ADDR:
			system()->trap(System::TRAP_INT_TIMER3);
			break;
		}
	}
	// reset CNT
	regcount(0);
}
