#ifndef _KEYPAD_H_
#define _KEYPAD_H_

#include "device.h"

class Keypad : public Device {

	/* Friend class for cmodel */
	friend class SL1SocCmodel;

public:
	Keypad(System* const sys, ADDR base);
	~Keypad();

	virtual void reset();
	virtual void readHook(ADDR addr);
	virtual void writeHook(ADDR addr);
	virtual void tick();

private:
	enum KEYPAD_REGS {
		KEYP_CTRL	= 0,
		KEYP_CONF	= 4,
		KEYP_STAT	= 8,
		KEYP_KCODE	= 12,
		KEYP_ICR	= 16,
		KEYP_FLGR	= 20,
	};

	void syncReg(KEYPAD_REGS reg, dev_u32 val);

};

#endif /* _KEYPAD_H_ */
