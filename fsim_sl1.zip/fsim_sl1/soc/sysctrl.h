#ifndef SYSCTRL_H_
#define SYSCTRL_H_

#include "device.h"
#include "regdefs.h"
#include "status.h"


class SL1Instr;
class System;

class SysCtrl : public Device {
	/* Friend class for cmodel */
	friend class SL1SocCmodel;

	/* Constant variables */
	enum {
		RSTC_CPU_MASK = 0x1,
		RSTC_DSP_MASK = 0x2,
		CFIG_CPU_ACTIVE_MASK = 0x80,
		CFIG_DSP_ACTIVE_MASK = 0x100,
	};

	/*
	 * Addresses of visible registers
	 */
	enum SYSCTRL_REGS {
		SYSCTRL_CFIG = 0,
		SYSCTRL_STAT = 4,
		SYSCTRL_PWRC = 8,
		SYSCTRL_LPMC = 12,
		SYSCTRL_RSTC = 16,
	};

	void syncReg(SYSCTRL_REGS reg, dev_u32 val);
	dev_u32 regreset();
	dev_u32 regconfig();
	void regreset(dev_u32 val);
	void regconfig(dev_u32 val);

private:


	dev_u32 _RESET;
	dev_u32 _CONFIG;

public:
	SysCtrl(System* const sys, ADDR base);

	virtual void readHook(ADDR addr);
	virtual void writeHook(ADDR addr);
	virtual void reset();
	virtual void tick();
};

#endif /*SYSCTRL_H_*/
