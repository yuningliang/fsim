/* 
 * Programmable timer
 */

#ifndef TIMER_H_
#define TIMER_H_

#include "device.h"

class Timer : public Device
{
private:
	/*
	 * Addresses of visible registers
	 */
	enum TIMER_REGS {
		TIMER_TLC = 0,
		TIMER_TCV = 4,
		TIMER_TCR = 8,
		TIMER_TIC = 12,
		TIMER_TIS = 16,
	};

	union ControlRegister {
		struct {
			dev_u8 TES	: 1;
			dev_u8 TAC	: 1;
			dev_u8 TMS	: 1;
			dev_u8 TIM	: 1;
		} bit;
		dev_u8 value;
	} _TCR;

	/* Record when is the timer start counting */
	unsigned long long _cycle_start;

	dev_u32 counter;
	dev_u32 _TLC;
	dev_u32 _TCV;
	dev_u32 _TIS;

	void syncReg(TIMER_REGS reg, dev_u32 val);

	dev_u32 regcompare();
	dev_u32 regcount();
	dev_u32 regcontrol();
	dev_u32 regclear();
	dev_u32 regstatus();
	void regcompare(dev_u32 val);
	void regcount(dev_u32 val);
	void regcontrol(dev_u32 val);
	void regstatus(dev_u32 val);

public:
	Timer(System* const sys, ADDR base);

	virtual void reset();
	virtual void readHook(ADDR addr);
	virtual void writeHook(ADDR addr);
	virtual void tick();
	
};


#endif /* TIMER_H_ */
