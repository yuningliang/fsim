#ifndef SL1_SOCSHELL_H_
#define SL1_SOCSHELL_H_

#include "singleton.h"

#include "defs.h"
#include "tclapi.h"
#include "memory.h"
#include "sl1address.h"
#include "sl1mmu.h"
#include "sl1instr.h"
#include "sl1reg.h"
#include "sl1exec.h"
#include "sl1fetch.h"
#include "sl1decoder.h"
#include "sl1disasm.h"
#include "status.h"
#include "sl1machine.h"
#include "shell.h"
#include "longjmp.h"
#include "properties.h"

#include <string>

#include "simconfig.h"
#include "system.h"
#include "gdbserver.h"

class SL1SoCShell : public Shell<SL1_CLASS_LIST>
{
private:
	void backward_init(); // TODO: remove this in later version

private:
	SimConfig _config;
	GDBServer<SL1MMU, SL1Machine>* _gdbServer;
	System* _system;

	void showVersion();
	void showUsage();

public:
	enum BREAK_TYPES
	{
		BREAK_RD,
		BREAK_WR,
		BREAK_RDWR,
		BREAK_INSTR
	};


	void init(int argc, char* argv[]);

	/* Retrieve instance function */
	SimConfig& config();

	/* Start and exit handler */
	void start();
	void end();

	/* Master reset */
	void resetAll();

	/* Elf related interface */
	int loadElf(string elf);

	/* Execute interface */
	void run();
	void step();
	int getExecStatus();

	/* Program counter control interface */
	ADDR getPC();
	void setPC(ADDR pc);

	/* Register interface */	
	void resetRegs();
	DWORD getReg(string& name);
	void setReg(string& name, DWORD data);

	
	/* Debugging interface */
	void setBreak(ADDR addr, BREAK_TYPES type);
	void clearBreak();		/* Clear all breaks */
	void clearBreak(ADDR addr, BREAK_TYPES type);
	void clearBreak(int brknum);

	/* Memory interface */
	void resetMem();		/* Delete all existing pages */
	BYTE readByte(ADDR addr);
	HWORD readHWord(ADDR addr);
	WORD readWord(ADDR addr);
	void writeByte(ADDR addr, BYTE data);
	void writeHWord(ADDR addr, HWORD data);
	void writeWord(ADDR addr, WORD data);

	/* Thread control interface */
	void setThread(int threadid);
	int getThread();

	/* Output interface */
	int show(const char *format, ...);
};

typedef Singleton<SL1SoCShell> MainShell;

#endif /* SL1_SOCSHELL_H_ */
