#ifndef SOCSHELL_H_
#define SOCSHELL_H_

#include <string>

#include "defs.h"
#include "simconfig.h"

class SoCShell
{
private:
	SimConfig _config;

	void showVersion();

public:
	enum BREAK_TYPES
	{
		BREAK_RD,
		BREAK_WR,
		BREAK_RDWR,
		BREAK_INSTR
	};

	SoCShell();
	~SoCShell();

	/* Initialize configuration */
	void init(int argc, char *argv[]);

	/* Retrieve instance function */
	SimConfig& config();

	/* Main start */
	void start();

	/* Master reset */
	void resetAll();

	/* Execute status interface */
	int getExecStatus();

	/* Program counter control interface */
	ADDR getPC();
	void setPC(ADDR pc);

	/* Register interface */	
	void resetRegs();
	DWORD getReg(string name);
	void setReg(string name, DWORD data);

	
	/* Debugging interface */
	void setBreak(ADDR addr, BREAK_TYPES type);
	void clearBreak();		/* Clear all breaks */
	void clearBreak(ADDR addr, BREAK_TYPES type);
	void clearBreak(int brknum);

	/* Memory interface */
	void resetMem();		/* Delete all existing pages */
	BYTE readByte(ADDR addr);
	HWORD readHWord(ADDR addr);
	WORD readWord(ADDR addr);
	void writeByte(ADDR addr, BYTE data);
	void writeHWord(ADDR addr, HWORD data);
	void writeWord(ADDR addr, WORD data);

	/* Thread control interface */
	void setThread(int threadid);
	int getThread();

	/* Output interface */
	int show(const char *format, ...);
};

#endif /* SOCSHELL_H_ */
