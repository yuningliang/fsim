#include "sl1_socshell.h"

int main(int argc, char *argv[])
{
	SL1SoCShell& shell = MainShell::getInstance();
	tcl_shell_ptr = &shell;
	shell.init(argc, argv);
	shell.run();
	shell.end();
}
