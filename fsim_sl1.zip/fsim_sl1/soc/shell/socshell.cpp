#include "socshell.h"

/* Retrieve instance function */
inline SimConfig& SoCShell::config()
{
	return _config;
}

void SoCShell::init(int argc, char *argv[])
{
	config().parseArgs(argc, argv);
}


void SocShell::show(const char *format, ...)
{
	fprintf(format);
}

void SoCShell::showVersion()
{
	show("-------------------------------------------------------------------\n");
	show("SimpLight system simulator built at %s %s\n", __DATE__, __TIME__);
	show("Copyright(C) 2007 Beijing SimpLight Nanoelectronics, Ltd.\n");
	show("-------------------------------------------------------------------\n");
}

void SoCShell::showUsage()
{
	show("--help(-h): Print this help.\n");
	show("-xc core-binary:Load file for core thread.If no commands specified, execute it and return.\n");
	show("-xb bb-binary.If no commands specified, execute it and return.\n");
	show("-d Run as a GDB target.\n");
}

void SoCShell::start()
{
}

