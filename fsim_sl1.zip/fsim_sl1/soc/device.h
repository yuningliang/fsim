/*
 * Memory mapped device base class
 */
#ifndef DEVICE_H_
#define DEVICE_H_

#include "defs.h"
#include "ifhandler.h"
#include "system.h"

typedef unsigned int dev_addr;
typedef signed long long dev_s64;
typedef unsigned long long dev_u64;
typedef unsigned int dev_u32;
typedef unsigned short dev_u16;
typedef unsigned char dev_u8;



class Device : public InterfaceHandler
{
private:
	System* const _system;
public:
	Device(System* const sys, ADDR base);
	
	/* Wrapper function to get System object address */
	System* const system();
	ADDR baddr();

	/* Rest all states */
	virtual void reset() = 0;

	/* Call in every scheduled tick */
	virtual void tick() = 0;
};

#endif /* DEVICE_H_ */
