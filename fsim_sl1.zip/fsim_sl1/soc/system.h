#ifndef SYSTEM_H_
#define SYSTEM_H_

#include "simconfig.h"
#include "cmmu.h"
#include "regdefs.h"

#include <map>

#define CORE_MAX_THREAD 4

class SysCtrl;
class Device;

class DeviceScheduler
{
private:
	/* Cycle executed */
	unsigned long long _cycle;

	/* Schedule items container */
	typedef multimap<unsigned long long, Device*> DeviceMap;
	DeviceMap _devMap;

public:
	DeviceScheduler();

	unsigned long long cycles();
	void add(Device* dev, unsigned int cycles);
	void remove(Device* dev);

	/* Call this in every clock cycle in machine */
	void clock();
};

class Serial;
class Timer;
class PIC;
class Keypad;
class DMAController;

class System
{
	/* Friend class for cmodel */
	friend class SL1SocCmodel;

public:
	enum RESET_ID {
		RESET_NORMAL = 0,
		RESET_ENABLE = 1,
		RESET_DISABLE = -1,
	};
	
	enum STATUS_ID {
		STATUS_NORMAL,
		STATUS_EXCEPT,
	};
private:
	/* System status array */
	STATUS_ID _status[CORE_MAX_THREAD];
	STATUS_ID _globalStatus;
	RESET_ID _threadReset[CORE_MAX_THREAD];
	ADDR _handlerAddr[CORE_MAX_THREAD];

	/* Reference for common instances */
	CoreMMU& _mmu;
	SimConfig& _config;

	/* Class variables */
	DeviceScheduler _scheduler;
	vector<Timer*> _timers;
	vector<Serial*> _serials;
	PIC* _picCore;
	PIC* _picDsp;
	Keypad* _keypad;
	SysCtrl* _sysctrl;
	DMAController* _dmaController;
	bool _enableClock;
	
	/* wrapper functions for retrieving core modules in the simulator */
	SimConfig& config();
	DeviceScheduler& scheduler();

	/* Peripherals initialization */
	void initTimer(SimConfig& c);
	void initSerial(SimConfig& c);
	void initPIC(SimConfig& c);
	void initDmaController(SimConfig& c);


public:
	enum CORE_TRAP_ID {
// Make sure DSP and CPU use the same IRQ no.
#if INTRC_INDEX_DSPRST != INTRC_INDEX_CPURST
#error
#endif
		TRAP_POWER_RESET	= 0,
		TRAP_EXCEPT		= (1 << INTRC_INDEX_EXCPT),
		TRAP_BREAK		= (1 << INTRC_INDEX_BREAK),
		TRAP_SIG		= (1 << INTRC_INDEX_SW_INT),
		TRAP_SYSCALL		= (1 << INTRC_INDEX_SW_INT),
		/* Define peripheral irq for dsp thread here */
		TRAP_INT_ABB_CTRL	= (1 << INTRC_INDEX_ABBCTL),
		TRAP_INT_ABB_IQD	= (1 << INTRC_INDEX_ABBIQD),
		TRAP_INT_ABB_CODEC	= (1 << INTRC_INDEX_ABBCODEC),
		TRAP_INT_ABB_RFIIQ	= (1 << INTRC_INDEX_RFIIQ),
		TRAP_INT_ABB_RFICON	= (1 << INTRC_INDEX_RFICON),
		TRAP_INT_ABB_GRFIIQ	= (1 << INTRC_INDEX_GRFIIQ),
		TRAP_INT_ABB_GRFICON	= (1 << INTRC_INDEX_GRFICON),
		TRAP_INT_DSP_RESET	= (1 << INTRC_INDEX_DSPRST),
		/* Define peripheral irq for core thread here */
		TRAP_INT_PFAIL		= (1 << INTRC_INDEX_PFAIL),
		TRAP_INT_PDOWN		= (1 << INTRC_INDEX_PDOWN),
		TRAP_INT_WAKEUP		= (1 << INTRC_INDEX_WKUP),
		TRAP_INT_DMA		= (1 << INTRC_INDEX_DMA),
		TRAP_INT_PMU		= (1 << INTRC_INDEX_PMU),
		TRAP_INT_USB		= (1 << INTRC_INDEX_USB),
		TRAP_INT_LCD		= (1 << INTRC_INDEX_LCDC),
		TRAP_INT_CPU_RESET	= (1 << INTRC_INDEX_CPURST),
		TRAP_INT_UNKNOWN3	= (1 << INTRC_INDEX_UNUSE0),
		TRAP_INT_WATCHDOG	= (1 << INTRC_INDEX_WDT),
		TRAP_INT_TIMER0		= (1 << INTRC_INDEX_TIM0),
		TRAP_INT_TIMER1		= (1 << INTRC_INDEX_TIM1),
		TRAP_INT_TIMER2		= (1 << INTRC_INDEX_TIM2),
		TRAP_INT_TIMER3		= (1 << INTRC_INDEX_TIM3),
		TRAP_INT_RTC		= (1 << INTRC_INDEX_RTC),
		TRAP_INT_SPI		= (1 << INTRC_INDEX_GSPI),
		TRAP_INT_IIC		= (1 << INTRC_INDEX_GI2C),
		TRAP_INT_GSSI 		= (1 << INTRC_INDEX_GSSI),
		TRAP_INT_GPIO0		= (1 << INTRC_INDEX_GPIO0),
		TRAP_INT_GPIO1		= (1 << INTRC_INDEX_GPIO1),
		TRAP_INT_GPIO2		= (1 << INTRC_INDEX_GPIO2),
		TRAP_INT_GPIO3		= (1 << INTRC_INDEX_GPIO3),
		TRAP_INT_GPIO4		= (1 << INTRC_INDEX_GPIO4),
		TRAP_INT_UART1		= (1 << INTRC_INDEX_UART1),
		TRAP_INT_UART2		= (1 << INTRC_INDEX_UART2),
		TRAP_INT_UART3		= (1 << INTRC_INDEX_UART3),
		TRAP_INT_PMW		= (1 << INTRC_INDEX_PWM),
		TRAP_INT_SIMC		= (1 << INTRC_INDEX_SIMC),
		TRAP_INT_KEYPAD		= (1 << INTRC_INDEX_KEYPAD),
	};


	System(SimConfig& c, CoreMMU& m);

	CoreMMU& mmu();

	DMAController* dma();

	/* Master reset for all peripherals */	
	void reset();

	/* Exception event */
	void trap(CORE_TRAP_ID id);
	void trap(int threadid, CORE_TRAP_ID id);
	/* Trap complete handler, should be called when executing rete */
	void clearTrap(int threadid);

	unsigned long long getCycles();
	void addSchedule(Device* dev, unsigned int cycles);
	void removeSchedule(Device* dev);

	/* Peripheral working cycle */
	void clock(void);
	/* The system clock can be enable/disable for profiling */
	void enableClock(bool enable);
	
	/* set the status of the system */
	void setStatus(int threadid, STATUS_ID status);
	
	/* return handler address */
	ADDR getHandlerAddr(int threadid);
	
	/* Return the status of the system */
	STATUS_ID getStatus(int threadid);
	STATUS_ID getStatus(void);

	/* get/set thread reset */
	void setReset(int threadid, RESET_ID b);
	RESET_ID getReset(int threadid);
	
	/* get reset start PC */
	ADDR getStartPC(int threadid);
};

#endif /* SYSTEM_H_ */
