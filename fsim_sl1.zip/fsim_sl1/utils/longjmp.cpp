#include <stdlib.h>
#include <setjmp.h>
#include "longjmp.h"

#ifdef NEED_LONG_JMP
#include <setjmp.h>
#include "shellbase.h"

ShellBase* sim_shell_ptr = NULL;
jmp_buf *pJmpBuf=NULL;
jmp_buf myJmpBuf;

jmp_buf *getJmpBuf(void)
{
	return &myJmpBuf;
}

void setJmpBuf(jmp_buf *jmpbuf_)
{
	pJmpBuf = (jmp_buf *)&myJmpBuf;
}

void checkLongJmp(void)
{
	if (pJmpBuf) {
		if(sim_shell_ptr!=NULL) {
			sim_shell_ptr->showStatus();
		}
		longjmp(*pJmpBuf, 2);
	}
}

#endif
