#include "utils.h"

#define TOKEN_MAX_LENGTH 64

#ifdef __cplusplus
extern "C" {
#endif

UINT depositBits(UINT dest, UINT src, INT pos, INT width) {
	UINT mask = width>0?1:0;
	for(INT i = 1; i<width; i++) {
		mask = (mask<<1)+1;
	}
	pos = pos - width + 1;
	src = ((src & mask)<<pos);
	mask = (mask << pos);
	dest = dest & (~mask);
	dest = dest | src;
	return dest;
	
}

pair<BOOL, UINT> extractExtMetaData(STRING data) {
	pair<BOOL, UINT> ret (FALSE, 0);
	if(strlen(data)>0) {
		char* tok = strtok(data, " ");
		while(tok!=NULL) {
			if(strstr(tok, "stack=")!=NULL) {
				tok = strchr(tok, '=');
				if(tok!=NULL) {
					UINT value;
					tok++;
					if(sscanf(tok, "%x", &value)==1) {
						ret.first = TRUE;
						ret.second = value;
						return ret;
					}
				}
			}
			tok = strtok(NULL, " ");
		} 
	}
	return ret;	
}
	
#ifdef __cplusplus
}
#endif
