/*
 * 	Copyright (c) 2006 Beijing SimpLight Nanoelectornics, Ltd.
 * 	All rights reserved.
 */

/*
	Copyright (C) 2005, 2006.  Free Software Foundation, Inc.

	This program is free software; you can redistribute it and/or modify it
	under the terms of version 2 of the GNU General Public License as
	published by the Free Software Foundation.

	This program is distributed in the hope that it would be useful, but
	WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

	Further, this software is distributed without any warranty that it is
	free of the rightful claim of any third person regarding infringement
	or the like.  Any license provided herein, whether implied or
	otherwise, applies only to this software file.  Patent licenses, if
	any, provided herein do not apply to combinations of this program with
	other software, or any other product whatsoever.

	You should have received a copy of the GNU General Public License along
	with this program; if not, write the Free Software Foundation, Inc., 59
	Temple Place - Suite 330, Boston MA 02111-1307, USA.
*/


#ifndef _LOADER_H_
#define _LOADER_H_

//#include "ELFIO/ELFIO.h"
#include <fcntl.h>
#include <unistd.h>
#include <elf.h>
#include "elf_reader.h"
#include "defs.h"

#define DISPLAY_ERR 1
#define _DEBUG_LOADER 0
#if _DEBUG_LOADER
#define DEBUG_LOADER printf
#else
#define DEBUG_LOADER(x,...) ((void)1)
#endif

template<class MMUClass>
class Loader {
	public:
	Loader();
	virtual ~Loader();
	ELF_object* createELFObj(STRING elfFile);
	INT loadELFObj(MMUClass& mmu, ELF_object *elfobj);
	
	private:
};

template<class MMUClass>
Loader<MMUClass>::Loader(){
}

template<class MMUClass>
Loader<MMUClass>::~Loader(){
}

/* Wrapper function for loading elf */
template<class MMUClass>
ELF_object* Loader<MMUClass>::createELFObj(STRING elfFile) {
	try{
		
		ELF_object* elfobj = new ELF_object(elfFile);
		return elfobj;
	} catch (STRING s) {
		throw s;
	}
}

template<class MMUClass>
INT Loader<MMUClass>::loadELFObj(MMUClass& mmu, ELF_object *elfobj) {
	try{
			
		// Write text segment to memory
		// write to virtual memory
		if (elfobj->textSegFSize() > 0) {
			DEBUG_LOADER("Text: %x %d\n", (ADDR)elfobj->textSegPAddr(), (UINT)elfobj->textSegFSize());
			mmu.writeBlock((ADDR)elfobj->textSegPAddr(), (BYTE*)elfobj->textSegFAddr(), 
			  (UINT)elfobj->textSegFSize());
			
			vmsg(VERBOSE_1, "Loading text segment: target addr=%#08x size=%#08x\n", 
				elfobj->textSegPAddr(),	elfobj->textSegFSize());
		}
		if (elfobj->textSegMSize()-elfobj->textSegFSize() > 0) {
			DEBUG_LOADER("BSS in Text: %x %d\n", (ADDR)elfobj->textSegVAddr() + elfobj->textSegFSize(), elfobj->textSegMSize() - elfobj->textSegFSize());
			mmu.initBlock((WORD)(elfobj->textSegVAddr() + elfobj->textSegFSize()),
		  		0, elfobj->textSegMSize() - elfobj->textSegFSize());
			vmsg(VERBOSE_1, "Clear bss in text segment: target addr=%#08x size=%#08x\n", 
				elfobj->textSegVAddr() + elfobj->textSegFSize(), 
				elfobj->textSegMSize() - elfobj->textSegFSize());
		}
		// Write rodata segment to memory
		// write to virtual memory
		if ((UINT)elfobj->rodataSegFSize() > 0) {
			DEBUG_LOADER("rodata: %x %d\n", (ADDR)elfobj->rodataSegPAddr(), (UINT)elfobj->rodataSegMSize());
			mmu.writeBlock((ADDR)elfobj->rodataSegPAddr(), (BYTE*)elfobj->rodataSegFAddr(), 
		  		(UINT)elfobj->rodataSegMSize());
			vmsg(VERBOSE_1, "Loading rodata segment: target addr=%#08x size=%#08x\n", 
				elfobj->rodataSegPAddr(),	elfobj->rodataSegMSize());
		}
		  
		// Write data segment to memory
		// write to virtual memory
		if ((UINT)elfobj->dataSegFSize() > 0) {
			DEBUG_LOADER(".data: %x %d\n", (ADDR)elfobj->dataSegPAddr(), (UINT)elfobj->dataSegFSize());
			mmu.writeBlock((ADDR)elfobj->dataSegPAddr(), (BYTE*)elfobj->dataSegFAddr(), 
		  		(UINT)elfobj->dataSegFSize());
			vmsg(VERBOSE_1, "Loading data segment: target addr=%#08x size=%#08x\n", 
				elfobj->dataSegPAddr(),	elfobj->dataSegFSize());
		}
		
		// BSS section inside data segment
		// write to virtual memory
		if (elfobj->dataSegMSize()-elfobj->dataSegFSize() > 0) {
			DEBUG_LOADER("BSS: %x %d\n", (ADDR)elfobj->dataSegVAddr() + elfobj->dataSegFSize(), elfobj->dataSegMSize() - elfobj->dataSegFSize());
			mmu.initBlock((WORD)(elfobj->dataSegVAddr() + elfobj->dataSegFSize()),
		  		0, elfobj->dataSegMSize() - elfobj->dataSegFSize());
			vmsg(VERBOSE_1, "Clear bss in data segment: target addr=%#08x size=%#08x\n", 
				elfobj->dataSegVAddr() + elfobj->dataSegFSize(), 
				elfobj->dataSegMSize() - elfobj->dataSegFSize());
		}
		
		// write to virtual memory
		if (elfobj->bssSegMSize() > 0) {
			DEBUG_LOADER(".data: %x %d\n", (ADDR)elfobj->bssSegVAddr(), (UINT)elfobj->bssSegMSize());
			mmu.initBlock((WORD)elfobj->bssSegVAddr(), 0, elfobj->bssSegMSize());
			vmsg(VERBOSE_1, "Clear bss segment: target addr=%#08x size=%#08x\n", 
				elfobj->bssSegVAddr(),	elfobj->bssSegMSize());
		}
		  
		return 0;
	} catch (STRING s) {
		throw s;
	}
	return -1;
}

#endif //_LOADER_H_
