#ifndef UTILS_H_
#define UTILS_H_

#include "defs.h"

#ifdef __cplusplus
extern "C" {
#endif

extern UINT depositBits(UINT dest, UINT src, INT pos, INT width);
extern pair<BOOL, UINT> extractExtMetaData(STRING data);


#ifdef __cplusplus
}
#endif
#endif /*UTILS_H_*/
