#ifndef LONGJMP_H_
#define LONGJMP_H_

// Uncomment below line if long jmp is needed or define it in Makefile
//#define NEED_LONG_JMP

#ifdef NEED_LONG_JMP
#include <setjmp.h>

class ShellBase;
extern ShellBase* sim_shell_ptr;

extern void setJmpBuf(jmp_buf *jmpbuf_);
extern void checkLongJmp(void);
extern jmp_buf *getJmpBuf(void);

class AutoClearJmpBuf
{
public:
	~AutoClearJmpBuf() { setJmpBuf( (jmp_buf *)NULL ); }
};

#define RETURN_TO_SHELL \
AutoClearJmpBuf clearJmpBuf;\
{ \
	setJmpBuf(getJmpBuf());  \
	if (setjmp(*getJmpBuf()) != 0) {  \
		printf("Application error happened. You're put back into fsim shell!!!\n"); \
		return TCL_OK;            \
	}                             \
}

#else

#define RETURN_TO_SHELL ;
#define checkLongJmp() NULL

#endif

#endif /*LONGJMP_H_*/
