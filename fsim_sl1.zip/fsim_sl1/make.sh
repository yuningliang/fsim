make soc_sl1
cp -f ./fsim_sl1/build/fsim_sl1/fsim_sl1 $TOOLROOT/usr/bin
cp -f ./fsim_sl1/build/fsim_sl2/fsim_sl2 $TOOLROOT/usr/bin
cp -f ./fsim_sl1/build/soc_sl1/soc_sl1 $TOOLROOT/usr/bin
