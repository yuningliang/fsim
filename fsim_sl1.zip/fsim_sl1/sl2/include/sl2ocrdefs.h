#ifndef SL2OCRDEFS_H_
#define SL2OCRDEFS_H_

// DMA registers
#define SL2_DMA_REGSET_SIZE	0x50
#define SL2_DMA_MAX_CHANNEL	8

#define SL2_OCR_DMA_BASE	0
#define SL2_OCR_DMA_CMD		(SL2_OCR_DMA_BASE + 0) /* 4bit DMA command; see below */
#define SL2_OCR_DMA_STATUS	(SL2_OCR_DMA_BASE + 0x4) /* See the values defined below */
#define SL2_OCR_DMA_SRC0	(SL2_OCR_DMA_BASE + 0x8) /* 32bit starting byte addr of DMA src */ 
#define SL2_OCR_DMA_SRC1	(SL2_OCR_DMA_BASE + 0xc) /* 1st 9-pixel location in chroma loads */
#define SL2_OCR_DMA_SRC2	(SL2_OCR_DMA_BASE + 0x10) /* 2nd 9-pixel location in chroma loads */
#define SL2_OCR_DMA_SRC3	(SL2_OCR_DMA_BASE + 0x14) /* 3rd 9-pixel location in chroma loads */
#define SL2_OCR_DMA_DST		(SL2_OCR_DMA_BASE + 0x18) /* 32bit starting byte addr of DMA dest */
#define SL2_OCR_DMA_CONST	(SL2_OCR_DMA_BASE + 0x1c) /* 8bit DMA constant */
#define SL2_OCR_DMA_SIZE	(SL2_OCR_DMA_BASE + 0x20) /* 16bit continguous byte transaction size */
#define SL2_OCR_DMA_CIMAGESZ	(SL2_OCR_DMA_BASE + 0x24) /* Chroma padding image size, [15:0]: Height, [31:16]: Width */
#define SL2_OCR_DMA_WINSZ	(SL2_OCR_DMA_BASE + 0x28) /* Search window size on the vbuf, [15:0]: Height, [31:16]: Width  */
#define SL2_OCR_DMA_PADCTRL	(SL2_OCR_DMA_BASE + 0x2c) /* Padding Control, [5:0]: Right padding width, [13:8]: Left padding width
                           * [21:16]: Bottom padding width, [29:24]: Top padding width, [31]: Read pixel disable */
#define SL2_OCR_DMA_REALSZ	(SL2_OCR_DMA_BASE + 0x30) /* Search window real pixel size loaded from external DRAM, [15:0]: Height, [31:16]: Width */
#define SL2_OCR_DMA_SRCOFFSET	(SL2_OCR_DMA_BASE + 0x34) /*  offset of src address for stride xfer */
#define SL2_OCR_DMA_DESTOFFSET	(SL2_OCR_DMA_BASE + 0x38) /* offset of dest address for stride xfer */
#define SL2_OCR_DMA_STRIDE	(SL2_OCR_DMA_BASE + 0x3C) /* number of bytes to be transferred for every stride */
#define SL2_OCR_DMA_DATATYPE	(SL2_OCR_DMA_BASE + 0x40) /* half-word or word type for reordering xfer */

#define SL2_OCR_DMA_ALL		(SL2_OCR_DMA_BASE + (SL2_DMA_MAX_CHANNEL *  SL2_DMA_REGSET_SIZE))


// EI registers
#define SL2_OCR_EI_BASE			(SL2_OCR_DMA_ALL)
#define SL2_OCR_EI_DRAMBASE		(SL2_OCR_EI_BASE+0x4) /* starting location of the extra DRAM */
#define SL2_OCR_EI_CONFIG		(SL2_OCR_EI_BASE+0x8) /* config. and enable bits for setup Javi core */
#define SL2_OCR_EI_JAVISTATUS	(SL2_OCR_EI_BASE+0xc) /* all running status of JaVi core */
#define SL2_OCR_EI_JAVIINTR		(SL2_OCR_EI_BASE+0x10) /* all various interrupts JaVi core has */
#define SL2_OCR_EI_JVSR0		(SL2_OCR_EI_BASE+0x14) /* reserved state registers 0 */
#define SL2_OCR_EI_JVSR1		(SL2_OCR_EI_BASE+0x18) /* reserved state registers 0 */
#define SL2_OCR_EI_TIMER		(SL2_OCR_EI_BASE+0x1c) /* reserved state registers 0 */
#define SL2_OCR_EI_JVSR3		(SL2_OCR_EI_BASE+0x20) /* reserved state registers 0 */
#define SL2_OCR_EI_JVSR4 		(SL2_OCR_EI_BASE+0x24) /* reserved state registers 0 */
#define SL2_OCR_EI_STARTPC		(SL2_OCR_EI_BASE+0x28)
#define SL2_OCR_EI_POST2DEC		(SL2_OCR_EI_BASE+0x2c)
#define SL2_OCR_EI_DEC2POST		(SL2_OCR_EI_BASE+0x30)
#define SL2_OCR_EI_PRE2ENC		(SL2_OCR_EI_BASE+0x34)
#define SL2_OCR_EI_ENC2PRE		(SL2_OCR_EI_BASE+0x38)
#define SL2_OCR_EI_CODECRES		(SL2_OCR_EI_BASE+0x3c)
#define SL2_OCR_EI_IMAGEBASE	(SL2_OCR_EI_BASE+0x40) /* image width and height */
#define SL2_OCR_EI_IMAGESZ		(SL2_OCR_EI_BASE+0x44) /* starting Dram location of the image */

#define SL2_OCR_EI_ALL			(SL2_OCR_EI_BASE+0x48)

#define SL2_OCR_THREAD_SP		(SL2_OCR_EI_ALL)

#endif /*SL2OCRDEFS_H_*/
