#ifndef SL2MMU_H_
#define SL2MMU_H_

#include "cmmu.h"
#include "sl2defs.h"
#include "sl2instr.h"
#include "sl2address.h"
#include "status.h"

#ifndef _SL2_VBUF_CHECK
#define _SL2_VBUF_CHECK 0
#endif

#if _SL2_VBUF_CHECK
#define SL2_MEM_TAG(tag) (tag|ET_HANDLE)
#define SL2_ASSERT_VBUF_READ(type, addr) AppFatal((type!=RANGE_IDX_VBUF), ("MMU: illegal read from Vbuf 0x%08x, PC[%08x].", addr, status().pre_pc()));
#define SL2_ASSERT_VBUF_WRITE(type, addr) AppFatal((type!=RANGE_IDX_VBUF), ("MMU: illegal write to Vbuf 0x%08x, PC[%08x]..", addr, status().pre_pc()));
#else
#define SL2_MEM_TAG(tag) (tag)
#define SL2_ASSERT_VBUF_READ(type, addr)
#define SL2_ASSERT_VBUF_WRITE(type, addr)
#endif

class AccessList;

class SL2MMU : public CoreMMU {
	private:
	ProcessStatus<SL2Instr> &_status;
	AccessList* _accessList;
	
	protected:
	ProcessStatus<SL2Instr>& status(void) { return _status; }
	
	public:
	SL2MMU(Address& addr, ProcessStatus<SL2Instr>& status);
	AccessList* accessList(void) { return _accessList; }
	
	BOOL isSRAM(UINT type) {
		return (type==RANGE_IDX_SBUF||type==RANGE_IDX_VBUF||type==RANGE_IDX_LUT);
	}
	BOOL isVbuf(ADDR addr);
	BOOL isSbuf(ADDR addr);
	BOOL isLut(ADDR addr);
	
	//used by instruction
	void writeByte(const ADDR, const BYTE);	
	void writeHword(const ADDR, const HWORD);
	void writeWord(const ADDR, const WORD);
	BYTE readByte(const ADDR);
	HWORD readHword(const ADDR);
	WORD readWord(const ADDR);		

	pair<ADDR, ADDR> cBufAddrReg(INT id){};
	void cBufAddrReg(ADDR start, ADDR end, INT id){};

	//writeSRAMBase assume start address is SRAM base address
	//without any checking and trigger event, kernel internal use only
	void setSRAMBaseWord(const ADDR addr, WORD data);
	void setSRAMBaseHword(const ADDR addr, HWORD data);
	void setSRAMBaseByte(const ADDR addr, BYTE data);	

	//get/set pair, without any checking and trigger event, kernel internal use only
	void setSRAMByte(const ADDR, const BYTE); 
	void setSRAMHword(const ADDR, const HWORD);  
	void setSRAMWord(const ADDR, const WORD); 
			
	//used by fsim directly 
	void copySram2Dram(ADDR dest, ADDR src, INT size);
	void copyDram2Sram(ADDR dest, ADDR src, INT size);
	void copySram2Sram(ADDR dest, ADDR src, INT size);
	void copyDMAByte(ADDR dest, ADDR src, INT size);
	
	BYTE readSbufByte(ADDR offset);
	HWORD readSbufHword(ADDR offset);
	HWORD readSbufSwapHword(ADDR offset);
	WORD readSbufWord(ADDR offset);
	WORD readSbufSwapWord(ADDR offset);
	void writeSbufByte(ADDR offset, BYTE byte);
	void writeSbufHword(ADDR offset, HWORD hword);
	void writeSbufSwapHword(ADDR offset, HWORD hword);
	void writeSbufWord(ADDR offset, WORD word);	
	void writeSbufSwapWord(ADDR offset, WORD word);	

	BYTE readVbufByte(ADDR offset);
	HWORD readVbufHword(ADDR offset);
	WORD readVbufWord(ADDR offset);
	void writeVbufByte(ADDR offset, BYTE byte);
	void writeVbufHword(ADDR offset, HWORD hword);
	void writeVbufWord(ADDR offset, WORD word);	

	UBYTE getSLOpMode(INT sl_indx);
	UBYTE getSLRow(INT sl_indx, INT bank);
	UBYTE getSLBank(INT sl_indx, INT bank);
	UBYTE getSLWen(INT sl_indx, INT bank);	
	
	INT getLutLL(INT index);
	INT getLutHL(INT index);
	INT getCL(INT index);
	INT getLutOrder(INT index);
	INT getLutCost(INT index);

	ADDR getForkThreadSP(void);	
	void setForkThreadSP(ADDR addr);	

	UINT readHandler(const ADDR addr, const UBYTE tag);	
	UINT writeHandler(const ADDR addr, const UBYTE tag);
	
	void registerDevice(InterfaceHandler* object, ADDR start, size_t size);
	void registerMemoryRange(UINT type, ADDR start, size_t size, bool readOnly);	
};

INLINE void SL2MMU::writeByte(const ADDR addr, const BYTE byte) {
	LOG_CBUS_WRITE(addr, byte, INT8_BYTE)
	UBYTE tag = CoreMMU::writeByte(addr, byte);
	if(SL2_MEM_TAG(tag)!=ET_NORMAL) {
		UINT type = writeHandler(addr, SL2_MEM_TAG(tag));
		SL2_ASSERT_VBUF_WRITE(type, addr)
	}	
}

INLINE void SL2MMU::writeHword(const ADDR addr, const HWORD hword) {
	AppFatal(((addr&HWORD_ALIGN_MASK)==0), ("MMU: unaligned hword write to 0x%08x.", addr));
	LOG_CBUS_WRITE(addr, hword, INT16_BYTE)
	UBYTE tag = CoreMMU::writeHword(addr, hword);
	if(SL2_MEM_TAG(tag)!=ET_NORMAL) {
		UINT type = writeHandler(addr, SL2_MEM_TAG(tag));
		SL2_ASSERT_VBUF_WRITE(type, addr)
	}
}

INLINE void SL2MMU::writeWord(const ADDR addr, const WORD word) {
	AppFatal(((addr&WORD_ALIGN_MASK)==0), ("MMU: unaligned word write to 0x%08x.", addr));
	LOG_CBUS_WRITE(addr, word, INT32_BYTE)
	UBYTE tag = CoreMMU::writeWord(addr, word);
	if(SL2_MEM_TAG(tag)!=ET_NORMAL) {
		UINT type = writeHandler(addr, SL2_MEM_TAG(tag));
		SL2_ASSERT_VBUF_WRITE(type, addr)
	}
}

INLINE BYTE SL2MMU::readByte(const ADDR addr) {
	pair<BYTE, UBYTE> data = CoreMMU::readByte(addr);
	if(SL2_MEM_TAG(data.second)!=ET_NORMAL) {
		UINT type = readHandler(addr, SL2_MEM_TAG(data.second));
		SL2_ASSERT_VBUF_READ(type, addr)
		data = CoreMMU::readByte(addr);
	}	
	LOG_CBUS_READ(addr, data.first, INT8_BYTE)
	return data.first;
}

INLINE HWORD SL2MMU::readHword(const ADDR addr) {
	AppFatal(((addr&HWORD_ALIGN_MASK)==0), ("MMU: unaligned hword write to 0x%08x.", addr));
	pair<HWORD, UBYTE> data = CoreMMU::readHword(addr);
	if(SL2_MEM_TAG(data.second)!=ET_NORMAL) {
		UINT type = readHandler(addr, SL2_MEM_TAG(data.second));
		SL2_ASSERT_VBUF_READ(type, addr)
		data = CoreMMU::readHword(addr);
	}	
	LOG_CBUS_READ(addr, data.first, INT16_BYTE)
	return data.first;	
}

INLINE WORD SL2MMU::readWord(const ADDR addr) {
	AppFatal(((addr&WORD_ALIGN_MASK)==0), ("MMU: unaligned word write to 0x%08x.", addr));
	pair<WORD, UBYTE> data = CoreMMU::readWord(addr);
	if(SL2_MEM_TAG(data.second)!=ET_NORMAL) {
		UINT type = readHandler(addr, SL2_MEM_TAG(data.second));
		SL2_ASSERT_VBUF_READ(type, addr)
		data = CoreMMU::readWord(addr);
	}	
	LOG_CBUS_READ(addr, data.first, INT32_BYTE)
	return data.first;
}

#endif /*SL2MMU_H_*/
