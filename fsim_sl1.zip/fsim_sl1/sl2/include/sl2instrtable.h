#ifndef SL2INSTRTABLE_H_
#define SL2INSTRTABLE_H_

#include "defs.h"
#include "cdefs.h"

class SL2Instr;
class SL2Exec;
class SL2Decoder;
class SL2Disasm;

typedef ADDR (SL2Exec::*SL2ExecPtr) (SL2Instr*);
typedef UINT32 (SL2Decoder::*SL2DecodePtr) (SL2Instr*, UINT);
typedef STRING (SL2Disasm::*SL2DisasmPtr) (ADDR, SL2Instr*, UINT);


enum SL2EINSTR_GR {
	EIG_gr = GROUP_ID_EIG_GR, //0
	EIG_alu = GROUP_ID_EIG_ALU, //1
	EIG_alu16 = GROUP_ID_EIG_ALU16, //2
	EIG_ls = GROUP_ID_EIG_LS, //3
	EIG_ls16 = GROUP_ID_EIG_LS16, //4
	EIG_br = GROUP_ID_EIG_BR, //5
	EIG_br16 = GROUP_ID_EIG_BR16, //6
	EIG_j = GROUP_ID_EIG_J, //7
	EIG_j16 = GROUP_ID_EIG_J16,	 //8	
	EIG_c2_ls = 9,
	EIG_c2_br = 10,
	EIG_c2_vmult = 11,
	EIG_c2_vadd = 12,
	EIG_c2_mult = 13,
	EIG_c2_add = 14,
	EIG_c2_bit = 15,
	EIG_c2_scan = 16,
	EIG_c2_sum = 17,
	EIG_c2_macro = 18,
	EIG_misc = 19,
	EIG_max = 20,
	EIG_invalid = 0xff,
};

class SL2InstrTableEntry 
{
	public:
	STRING _mn;
	UINT16 _id;
	UINT16 _enable;
	SL2EINSTR_GR _group;
	SL2DecodePtr _decode;
	SL2ExecPtr _exec;
	SL2DisasmPtr _print;
	
	public:
	char *mn(void) 			{ return _mn; }
	UINT16 id(void)			{ return _id; }
	BOOL enable(UINT16 mode) { return mode&_enable; }
	SL2EINSTR_GR group(void) { return _group; }
	SL2DecodePtr decode(void) { return _decode;}
	SL2ExecPtr exec(void) { return _exec;}
	SL2DisasmPtr print(void) { return _print;}
};

extern class SL2InstrTableEntry Top_Table[];
extern class SL2InstrTableEntry G0_Table[];
extern class SL2InstrTableEntry G1_Table[];
extern class SL2InstrTableEntry G2_Table[];
extern class SL2InstrTableEntry C2_Table[];
extern class SL2InstrTableEntry C3_Table[];
extern class SL2InstrTableEntry C2_Private_Table[]; 

#endif /*INSTRTABLE_H_*/
