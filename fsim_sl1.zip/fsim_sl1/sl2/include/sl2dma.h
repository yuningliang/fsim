//#define SL2DMA_H_

#ifndef SL2DMA_H_
#define SL2DMA_H_

#include "defs.h"
#include "sl2ocrdefs.h"
#include "ifhandler.h"
#include "sl2mmu.h"

#define SL2_DMA_VBUF_OFFSET	16
#define SL2_DMA_VBUF_SKIP	32
#define SL2_DMA_STRIDE_MAX	16
#define SL2_DMA_STRIDE_ADDR_MASK	0xf

enum EDMAR {
    DMAR_CMD      = 0, /* 4bit DMA command; see below */
    DMAR_STATUS   = 0x4, /* See the values defined below */
    DMAR_SRC0     = 0x8, /* 32bit starting byte addr of DMA src */ 
    DMAR_SRC1     = 0xc, /* 1st 9-pixel location in chroma loads */
    DMAR_SRC2     = 0x10, /* 2nd 9-pixel location in chroma loads */
    DMAR_SRC3     = 0x14, /* 3rd 9-pixel location in chroma loads */
    DMAR_DST      = 0x18, /* 32bit starting byte addr of DMA dest */
    DMAR_CONST    = 0x1c, /* 8bit DMA constant */
    DMAR_SIZE     = 0x20, /* 16bit continguous byte transaction size */
    DMAR_CIMAGESZ = 0x24, /* Chroma padding image size
                           * [15:0]: Height
                           * [31:16]: Width
                           */
    DMAR_WINSZ    = 0x28, /* Search window size on the vbuf
                           * [15:0]: Height
                           * [31:16]: Width
                           */
    DMAR_PADCTRL  = 0x2c, /* Padding Control
                           * [5:0]: Right padding width
                           * [13:8]: Left padding width
                           * [21:16]: Bottom padding width
                           * [29:24]: Top padding width
                           * [31]: Read pixel disable
                           */
    DMAR_REALSZ   = 0x30, /* Search window real pixel size loaded from external
                           * DRAM
                           * [15:0]: Height
                           * [31:16]: Width
                           */
    DMAR_MAX      = 0x34 /* Maximum address of the register area
                           * size = 0x40
                           */
};

/* Values of Command*/
enum EDMA_CMD {
    DMA_CMD_NOP         =0,
    DMA_CMD_LINEAR      =1,   /* Linear Transfer */
    DMA_CMD_L4X16BLK     =2,   /* Load 4x16 Block */
    DMA_CMD_L8X8BLK     =3,   /* Load 8x8 Block */
    DMA_CMD_L16X16BLK   =4,   /* Load 16x16 Block */
    DMA_CMD_SEARCHWIN   =5,   /* Search windows load with pixel padding */
    DMA_CMD_CHROMA      =6,   /* Chroma subpel interpolation load */
    DMA_CMD_CONST       =7,   /* Constant broadcast */
    DMA_CMD_LC4X8BLK    =10,  /* Load 4x8 Chroma Block */
    DMA_CMD_LC8X8BLK    =11,  /* Load 8x8 Chroma Block */
    DMA_CMD_LC16X16BLK  =12,  /* Load 16x16 Chroma Block */
    DMA_CMD_S4X16BLK     =18,  /* Store 4x16 Block */
    DMA_CMD_S8X8BLK     =19,  /* Store 8x8 Block */
    DMA_CMD_S16X16BLK   =20,  /* Store 16x16 Block */
    DMA_CMD_SC4X8BLK    =26,  /* Store 4x8 Chroma Block */
    DMA_CMD_SC8X8BLK    =27,  /* Store 8x8 Chroma Block */
    DMA_CMD_SC16X16BLK  =28,  /* Store 16x16 Chroma Block */
    DMA_CMD_SLINEAR		=33,  /* stride linear transfer. (bit 5 is stride bit) */
    DMA_CMD_RLINEAR     =65,  /* reordering linear transfer (bit 6 is reordering bit) */
    DMA_CMD_MAX         =DMA_CMD_RLINEAR + 1
};

enum EDMA_STATUS {
    DMA_STATUS_IDLE        =0,
    DMA_STATUS_LINEAR      =1, /* Active direct linear load */
    DMA_STATUS_4XNBLK       =2,
    DMA_STATUS_8X8BLK      =3,    
    DMA_STATUS_16X16BLK    =4,
    DMA_STATUS_SEARCHWIN   =5, /* Search windows load with pixel padding */
    DMA_STATUS_CHROMA      =6, /* Chroma subpel interpolation load */
    DMA_STATUS_BROADCAST   =7, /* Constant broadcast */
    DMA_STATUS_STRIDE      =8, /* Constant broadcast */
    DMA_STATUS_RECORDING   =9, /* Constant broadcast */
    DMA_STATUS_MAX         =DMA_STATUS_BROADCAST + 1
};


class SL2DMA : public InterfaceHandler{
    private:
    enum EPAD {
        EPAD_REAL   = 0,
        EPAD_TOP    = 1,
        EPAD_BOTTOM = 2,
        EPAD_LEFT   = 3,
        EPAD_RIGHT  = 4
    };
    
    private:
    UINT _channel;
    ADDR _channelBase;
    SL2MMU& _mmu;
    
    private:
    UINT channelBase(void) { return _channelBase; }
    void channel(UINT c) { 
    	AppFatal((c<SL2_DMA_MAX_CHANNEL), ("Invalid channel (%d)", c));
    	_channel = c; 
    	_channelBase = (c * SL2_DMA_REGSET_SIZE);
    }
    WORD getOnChipRegWord(ADDR addr) {
    	return getWord(addr + channelBase());
    }
    
    void setOnChipRegWord(ADDR addr, WORD data) {
    	setWord(addr + channelBase(), data);
    }

    WORD getOnChipRegEIWord(ADDR addr) {
    	return getWord(addr);
    }
    
    void setOnChipRegEIWord(ADDR addr, WORD data) {
    	setWord(addr, data);
    }
	
    public:
    SL2DMA(SL2MMU& m, Memory* mem, ADDR start, UINT size);
	SL2MMU& mmu(void) { return _mmu; }
	
	void readHook(ADDR addr);
	void writeHook(ADDR addr);	
    
    private:    
    void _onCmdWrite(EDMA_CMD cmd);
    INT _execLinear(void);
    INT _execL4x16Blk(void);
    INT _execL8x8Blk(void);
    INT _execL16x16Blk(void);
    INT _execS4x16Blk(void);
    INT _execS8x8Blk(void);
    INT _execS16x16Blk(void);
    INT _execLC4x8Blk(void);
    INT _execLC8x8Blk(void);
    INT _execLC16x16Blk(void);
    INT _execSC4x8Blk(void);
    INT _execSC8x8Blk(void);
    INT _execSC16x16Blk(void);
    INT _execSearchWin(void);
    INT _execChroma(void);
    INT _execConst(void);
    INT _exec4x4BlockXfer(BOOL isDramToV, BOOL isChromaLoad, INT count);
    INT _exec8x8BlockXfer(BOOL isDramToV, BOOL isChromaLoad);
    INT _exec16x16BlockXfer(BOOL isDramToV, BOOL isChromaLoad);

    INT _execStrideXfer(void);
    INT _execRecoderXfer(void);

    void _load4x16Block(BYTE *data, ADDR src, UINT win_w);
    void _loadBlock(BYTE *data, ADDR src, UINT w, UINT h, UINT win_w);
    void _store4x16Block(ADDR dest, BYTE *data);
    void _storePad(ADDR dest, BYTE *data, UINT pad_w, UINT pad_h, EPAD padtype);
};

#endif /*SL2DMA_H_*/
