#ifndef SL1INSTRPAGE_H_
#define SL1INSTRPAGE_H_

#include "instrpage.h"

class SL2Instr;

class SL2InstrPage : InstrPage<SL2Instr> {
}

#endif /*SL1INSTRPAGE_H_*/
