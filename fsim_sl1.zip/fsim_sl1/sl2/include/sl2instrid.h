#ifndef SL2INSTRID_H_
#define SL2INSTRID_H_

#include "cinstrid.h"
//Instruction ID

#define c2ld_id 0x200
#define c2st_id 0x201
#define c2mvgc_id 0x202
#define c2mvgr_id 0x203
#define c2brt_id 0x204
#define c2brf_id 0x205
#define c2fork_id 0x206
#define c2joint_id 0x207
#define c2vmul_id 0x208
#define c2vsad_old_id 0x209
#define c2satd_old_id 0x20a
#define c2vspel_id 0x20b
#define c2mmul_id 0x20c
#define c2vspmac_id 0x20d
#define c2vadds_id 0x20e
#define c2vspas_id 0x20f
#define c2vsubs_id 0x210
#define c2vneg_id 0x211
#define c2vcmpr_id 0x212
#define c2vshft_id 0x213
#define c2vclg_id 0x214
#define c2vcmov_id 0x215
#define c2lczero_id 0x216
#define c2vclp_id 0x217
#define c2vrnd_id 0x218
#define c2vmov_id 0x219
#define c2muls_id 0x21a
#define c2mads_id 0x21b
#define c2smads_id 0x21c
#define c2mvsel_id 0x21d
#define c2adds_id 0x21e
#define c2subs_id 0x21f
#define c2scond_id 0x220
#define c2clp_id 0x221
#define c2med_id 0x222
#define c2cmov_id 0x223
#define c2bcst_id 0x224
#define c2chkrng_id 0x225
#define c2intra_id 0x226
#define c2bop_id 0x227
#define c2bxtr_id 0x228
#define c2bdep_id 0x229
#define c2vlcs_id 0x22a
#define c2sum4_id 0x22b
#define c2gsum4s_id 0x22c
#define c2mov_id 0x22d
#define c2vcopy_id 0x22e
#define c2satd_id 0x22f
#define c2vsad_id 0x230
#define c2thctrl_id 0x231
#define c2prret_id 0x232
#define c2clzob_id 0x233


//private instruction id
#define c2psum16_old_id 0x2f0
#define c2psum4t1_id 0x2f1
#define c2psum4t2_id 0x2f2
#define c2padds_id 0x2f3
#define c2pmov_id 0x2f4
#define c2pmedc_id 0x2f5
#define c2psadds_id 0x2f6
#define c2pspadd_id 0x2f7
#define c2pxadd_id 0x2f8
#define c2pxsub_id 0x2f9
#define c2psum16_id 0x2fa

//instruction op used by macro
#define c2psum16_old_op 0x0
#define c2psum4t1_op 0x1
#define c2psum4t2_op 0x2
#define c2padds_op 0x3
#define c2pmov_op 0x4
#define c2pmedc_op 0x5
#define c2psadds_op 0x6
#define c2pspadd_op 0x7
#define c2pxadd_op 0x8
#define c2pxsub_op 0x9
#define c2psum16_op 0xa


#define c2vadds_op 0x0
#define c2vsubs_op 0x2
#define c2ld_op 0x8
#define c2st_op 0x9
#define c2vspel_op 0x14
#define c2mmul_op 0x16
#define c2adds_op 0x20
#define c2muls_op 0x26
#define c2mvsel_op 0x2e
#define c2mvgr_op 0x31

#endif /*SL2INSTRID_H_*/
