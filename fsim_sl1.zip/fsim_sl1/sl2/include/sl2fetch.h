#ifndef SL2FETCH_H_
#define SL2FETCH_H_

#include "fetch.h"
//#include "sl2decoder.h"

class SL2MMU;
class SL2Decoder;
class SL2Instr;

class SL2Fetch : public Fetch<SL2MMU, SL2Decoder, SL2Instr> {
	public:
	SL2Fetch(SL2MMU& mmu, Address& _addr, ProcessStatus<SL2Instr>& status) 
		: Fetch<SL2MMU, SL2Decoder, SL2Instr>(mmu, _addr, status) {
		}
};

#endif /*SL2FETCH_H_*/
