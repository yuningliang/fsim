#ifndef SL2INSTR_H_
#define SL2INSTR_H_

#include "sl2defs.h"
#include "sl2instrtable.h"
#include "sl2regdefs.h"
#include "cinstr.h"

class SL2Instr : public CoreInstr {
	
	private:
	//instruction info from instr table
	WORD _rawbits_bk;
	SL2ExecPtr _exec;
	SL2DisasmPtr _print;
	SL2EINSTR_GR _group;
	INT _macroCnt; //-1 means non-macro, 0 means macro but macrolist not initialized
	INT _macroIndex;
	SL2InstrList _macroList;
	
	//bit field
	struct Reg _specreg1;
	struct Reg _specreg2;
	struct Reg _ctrl3;
	struct Reg _acc;
	struct Reg _simd0a;
	struct Reg _simd0b;
	struct Reg _simd1a;
	struct Reg _simd1b;
	struct Reg _simd2a;
	struct Reg _simd2b;
	struct Reg _simd3a;
	struct Reg _simd3b;	
	struct Reg _reg3;

	UBYTE _imm1;
	UBYTE _gpr;
	UBYTE _macro;
	UBYTE _size;
	UBYTE _sign_ext;
	UBYTE _bank; //bk0 in private
	UBYTE _dstbank; //Add from ISA2.6
	UBYTE _op_mode;
	UBYTE _dir;  
	UBYTE _in_pair;
	UBYTE _carry;
	UBYTE _shft_mode; //lshft_amnt in private
	UBYTE _shft_amnt; //rshft_amnt in private
	UBYTE _other01; //mjr_fk, zero, gt, cmp_bit, mov_pat, abs, shft, hi_indx, lsb, op_code, opd_shft, thread
	UBYTE _other02; //sw_mv, imm2, lt, lo_indx, scalar, rev_pat, bk1 in private
	UBYTE _other03; //swap, bc_dir, eq, bk2 in private
	UBYTE _other04; //scalar workaround, wr_back
	UBYTE _other05; ///*** WWD : use as bk1 tempory
		
	public:	
	SL2Instr() : CoreInstr() {
		_other04 = 0;
		_macroIndex = -1;
		_macroCnt = -1;
		_macro = 0;
#if _INCLUDE_REG_DETAIL		
		_acc.status = ERS_UNDEF;
		_specreg1.status = ERS_UNDEF;
		_specreg2.status = ERS_UNDEF;
		_ctrl3.status = ERS_UNDEF;	
		_simd0a.status = ERS_UNDEF;	
		_simd0b.status = ERS_UNDEF;	
		_simd1a.status = ERS_UNDEF;	
		_simd1b.status = ERS_UNDEF;	
		_simd2a.status = ERS_UNDEF;	
		_simd2b.status = ERS_UNDEF;		
		_simd3a.status = ERS_UNDEF;	
		_simd3b.status = ERS_UNDEF;	
		_reg3.status = ERS_UNDEF;
#endif		
	}
	void init(SL2InstrTableEntry* entry, WORD raw) {
		_mn = entry->mn();
		_id = entry->id();
		_group = entry->group();
		_exec = entry->exec();
		_print =  entry->print();
		_rawbits = raw;
		clear();
	}
	void init() {
		CoreInstr::init();
		clear();
	}	
	WORD rawbits(void) { return _rawbits; }
	void rawbits(WORD r) { _rawbits = r; }
	STRING mn(void) { return _mn; }
	UINT16 id(void) { return _id; }
	SL2EINSTR_GR group(void) { return _group; }
	void group(SL2EINSTR_GR gr) { _group = gr; }
	SL2ExecPtr exec(void) { return _exec; }
	void exec(SL2ExecPtr e) { _exec = e; }
	SL2DisasmPtr print(void) { return _print; }	
	WORD meta(void) { return _meta; }
	void meta(INT c) { _meta = c; }	
	void macroCnt(WORD m) { _macroCnt = m; }
	INT macroCnt(void) { return _macroCnt; }
	void macroIndex(INT i) { _macroIndex = i; }
	INT macroIndex(void) { return _macroIndex; }	
	WORD instrsize(void) { return _instrsize; }
	void instrsize(UINT s) { _instrsize = s; }		
	void getRegList(RegList* destList, RegList* srcList);
	SL2InstrList* getMacro(void) {
		AppFatal((_macroCnt>0&&_macroList.size()>0), ("Non-macro insrtuction or macro list is empty."));
		return &_macroList;
	}
	void setMacro(SL2Instr* instr, INT index) {
		instr->macroIndex(index);
		_macroList.push_back(instr);
	}	
	void clearMacro(void);
	void clear(void) {
		clearMacro();
		_macroCnt = -1;
		_macroIndex = -1;
		_macroList.clear();
	}
	
	UINT32 rs1_imm() { return _reg1.index; }
	void rs1_imm(UINT32 r) {  
		_reg1.index = r; 
	}	
	UINT32 rs2_imm() { return _reg2.index; }
	void rs2_imm(UINT32 r) {  
		_reg2.index = r; 
	}
	UINT32 rs3_imm() { return _reg3.index; }
	void rs3_imm(UINT32 r) {  
		_reg3.index = r; 
	}	
			
	//cs2
	UINT32 cs2(void) { return _ctrl2.index; }
	void cs2(UINT32 r) {
		REG_DETAIL(_ctrl2, ERS_READ, EBASE_CTRL) 
		_ctrl2.index = r; 
	}		
	
	UINT32 rs3(void) { return _reg3.index; }
	void rs3(UINT32 r)   { 
		REG_DETAIL(_reg3, ERS_READ, EBASE_GPR) 
		_reg3.index = r; 
	}
		
	UINT32 c2cd(void) { return _ctrl1.index; }
	void c2cd(UINT32 r)   { 
		REG_DETAIL(_ctrl1, ERS_WRITE, EBASE_C2_CTRL) 
		_ctrl1.index = r; 
	}
	UINT32 c2cs1(void) { return _ctrl1.index; }
	void c2cs1(UINT32 r)   { 
		REG_DETAIL(_ctrl1, ERS_READ, EBASE_C2_CTRL) 
		_ctrl1.index = r; 
	}
	UINT32 c2cs2(void) { return _ctrl2.index; }
	void c2cs2(UINT32 r)   { 
		REG_DETAIL(_ctrl2, ERS_READ, EBASE_C2_CTRL) 
		_ctrl2.index = r; 
	}	
	UINT32 c2cs3(void) { return _ctrl3.index; }
	void c2cs3(UINT32 r)   { 
		REG_DETAIL(_ctrl3, ERS_READ, EBASE_C2_CTRL) 
		_ctrl3.index = r; 
	}	
	void acc(EREG_STATUS action, UINT r) {  
		REG_DETAIL(_acc, action, EBASE_C2_ACC) 
		_acc.index = r; 
	}		
	void c2spec1(EREG_STATUS s, UINT32 r)   { 
		REG_DETAIL(_specreg1, s, EBASE_C2_SPEC) 
		_specreg1.index = r; 
	}
	void c2spec2(EREG_STATUS s, UINT32 r)   { 
		REG_DETAIL(_specreg2, s, EBASE_C2_SPEC) 
		_specreg2.index = r; 
	}	

	UINT32 rd1_simd(void) { return _simd0a.index; }
	void rd1_simd(UINT32 r) {
		REG_DETAIL(_simd0a, ERS_WRITE, EBASE_SIMD) 
		_simd0a.index = r; 
	}	
	void rd1_simd_pair(UINT32 r) { 
		REG_DETAIL(_simd0a, ERS_WRITE, EBASE_SIMD) 
		_simd0a.index = r; 		
		REG_DETAIL(_simd0b, ERS_WRITE, EBASE_SIMD) 
		_simd0b.index = r + 1; 
	}	
	UINT32 rd2_simd(void) { return _simd3a.index; }
	void rd2_simd(UINT32 r) { 
		REG_DETAIL(_simd3a, ERS_WRITE, EBASE_SIMD) 
		_simd3a.index = r; 
	}	
	void rd2_simd_pair(UINT32 r) {
		REG_DETAIL(_simd3a, ERS_WRITE, EBASE_SIMD) 
		_simd3a.index = r; 		
		REG_DETAIL(_simd3b, ERS_WRITE, EBASE_SIMD) 
		_simd3b.index = r + 1; 
	}
	
	UINT32 rs1_simd(void) { return _simd1a.index; }
	void rs1_simd(UINT32 r) { 
		REG_DETAIL(_simd1a, ERS_READ, EBASE_SIMD)  
		_simd1a.index = r; 
	}	
	void rs1_simd_pair(UINT32 r) { 
		REG_DETAIL(_simd1a, ERS_READ, EBASE_SIMD)  
		_simd1a.index = r; 		
		REG_DETAIL(_simd1b, ERS_READ, EBASE_SIMD)  
		_simd1b.index = r + 1; 
	}	
	
	UINT32 rs2_simd(void) { return _simd2a.index; }
	void rs2_simd(UINT32 r) {  
		REG_DETAIL(_simd2a, ERS_READ, EBASE_SIMD)  
		_simd2a.index = r; 
	}	
	void rs2_simd_pair(UINT32 r) {
		REG_DETAIL(_simd2a, ERS_READ, EBASE_SIMD)   
		_simd2a.index = r; 		
		REG_DETAIL(_simd2b, ERS_READ, EBASE_SIMD)  
		_simd2b.index = r + 1; 
	}	

	UINT32 rs3_simd(void) { return _simd3a.index; }
	void rs3_simd(UINT32 r) {  
		REG_DETAIL(_simd3a, ERS_READ, EBASE_SIMD)   
		_simd3a.index = r; 
	}	
	void rs3_simd_pair(UINT32 r) { 
		REG_DETAIL(_simd3a, ERS_READ, EBASE_SIMD)   
		_simd3a.index = r; 
		REG_DETAIL(_simd3b, ERS_READ, EBASE_SIMD)   
		_simd3b.index = r + 1; 
	}

	//_modf6_6
	UBYTE unsigned_flag(void) { return _modf6_6;}
	void unsigned_flag(UBYTE f){ _modf6_6 = f;}
	
	
	//other flags
	WORD sl_indx(void) { return _imm_b16; }
	void sl_indx(WORD index) { _imm_b16 = index; }	
	WORD cl_indx(void) { return _imm_s16; }
	void cl_indx(WORD index) { _imm_s16 = index; }		
	UBYTE imm1(void) { return _imm1; }
	void imm1(UBYTE imm) { _imm1 = imm; }	
	UBYTE gpr(void) { return _gpr; }
	void gpr(UBYTE gpr) { _gpr = gpr; }	
	UBYTE macro(void) { return _macro; }
	void macro(UBYTE macro) { _macro = macro; }	
	UBYTE multi(void) { return _macro; }
	void multi(UBYTE macro) { _macro = macro; }		
	UBYTE size(void) { return _size; }
	void size(UBYTE size) { _size = size; }	
	UBYTE sign_ext(void) { return _sign_ext; }
	void sign_ext(UBYTE sign_ext) { _sign_ext = sign_ext; }	
	UBYTE bank(void) { return _bank; }
	void bank(UBYTE bank) { _bank = bank; }	
	UBYTE dstbank(void) { return _dstbank; }
	void dstbank(UBYTE bank) { _dstbank = bank; }	
	UBYTE op_mode(void) { return _op_mode; }
	void op_mode(UBYTE op_mode) { _op_mode = op_mode; }	
	UBYTE dir(void) { return _dir; }
	void dir(UBYTE dir) { _dir = dir; }
	UBYTE in_pair(void) { return _in_pair; }
	void in_pair(UBYTE p) { _in_pair = p; }	
	UBYTE carry(void) { return _carry; }
	void carry(UBYTE carry) { _carry = carry; }	
	UBYTE shft_mode(void) { return _shft_mode; }
	void shft_mode(UBYTE shf_mode) { _shft_mode = shf_mode; }	
	UBYTE shft_amnt(void) { return _shft_amnt; }
	void shft_amnt(UBYTE shf_amt) { _shft_amnt = shf_amt; }	
	
	UBYTE mjr_fk(void) { return _other01; }
	void mjr_fk(UBYTE val) { _other01 = val; }	
	UBYTE opd_shft(void) { return _other01; }
	void opd_shft(UBYTE val) { _other01 = val; }
	UBYTE zero(void) { return _other01; }
	void zero(UBYTE val) { _other01 = val; }				
	UBYTE gt(void) { return _other01; }
	void gt(UBYTE val) { _other01 = val; }	
	UBYTE cmp_bit(void) { return _other01; }
	void cmp_bit(UBYTE val) { _other01 = val; }	
	UBYTE mov_pat(void) { return _other01; }
	void mov_pat(UBYTE val) { _other01 = val; }	
	UBYTE abs(void) { return _other01; }
	void abs(UBYTE val) { _other01 = val; }	
	UBYTE shft(void) { return _other01; }
	void shft(UBYTE val) { _other01 = val; }		

	UBYTE hi_indx(void) { return _other01; }
	void hi_indx(UBYTE val) { _other01 = val; }
	UBYTE lsb(void) { return _other01; }
	void lsb(UBYTE val) { _other01 = val; }
	UBYTE start(void) { return _other01; }
	void start(UBYTE val) { _other01 = val; }	
	UBYTE op_code(void) { return _other01; }
	void op_code(UBYTE val) { _other01 = val; }
	UBYTE thread(void) { return _other01; }
	void thread(UBYTE val) { _other01 = val; }
			
	UBYTE sw_mv(void) { return _other02; }
	void sw_mv(UBYTE val) { _other02 = val; }		
	UBYTE imm2(void) { return _other02; }
	void imm2(UBYTE val) { _other02 = val; }	
	UBYTE lt(void) { return _other02; }
	void lt(UBYTE val) { _other02 = val; }	
	UBYTE lo_indx(void) { return _other02; }
	void lo_indx(UBYTE val) { _other02 = val; }	
	UBYTE rev_pat(void) { return _other02; }
	void rev_pat(UBYTE val) { _other02 = val; }	
	
	UBYTE swap(void) { return _other03; }
	void swap(UBYTE val) { _other03 = val; }	
	UBYTE bc_dir(void) { return _other03; }
	void bc_dir(UBYTE val) { _other03 = val; }	
	UBYTE eq(void) { return _other03; }
	void eq(UBYTE val) { _other03 = val; }									

	UBYTE wr_back(void) { return _other04; }
	void wr_back(UBYTE val) { _other04 = val; }
	UBYTE scalar(void) { return _other04; }
	void scalar(UBYTE val) { _other04 = val; }	

// private instruction fields
	UBYTE bk0(void) { return _bank; }
	void bk0(UBYTE val) { _bank = val; }	
	UBYTE bk1(void) { return _other05; }
	void bk1(UBYTE val) { _other05 = val; }	
	UBYTE bk2(void) { return _other03; }
	void bk2(UBYTE val) { _other03 = val; }	
	UWORD wen(void) { return _imm_b16; }
	void wen(UWORD val) { _imm_b16 = val; }	
	UBYTE lshft_amnt(void) { return _shft_mode; }
	void lshft_amnt(UBYTE val) { _shft_mode = val; }		
	UBYTE rshft_amnt(void) { return _shft_amnt; }
	void rshft_amnt(UBYTE val) { _shft_amnt = val; }		
	
//psim	
	pair<INT, INT> gprRegPort(void);
	pair<INT, INT> simdRegPort(void);
	INT c2Latency(void);
};

#endif /*INSTRUCTION_H_*/
