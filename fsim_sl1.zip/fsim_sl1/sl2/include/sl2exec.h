#ifndef SL2EXEC_H_
#define SL2EXEC_H_

#include "cexec.h"
#include "sl2reg.h"
#include "sl2mmu.h"

class SL2ThreadCtrl;
class SL2Instr;


class SL2Exec : public CoreExec<SL2MMU, SL2Register, SL2Instr> {
	private:
	SL2ThreadCtrl* _threadCtrl;
	BOOL _skipFork;
	
	public:	
	SL2Exec(SL2MMU& mmu, SL2Register& reg, ProcessStatus<SL2Instr>& status);
	SL2Exec(SL2MMU& mmu, SL2Register& reg, ProcessStatus<SL2Instr>& status, SL2ThreadCtrl* th);
	SL2ThreadCtrl* threadCtrl(void) { 
		SimFatal((_threadCtrl!=NULL), ("SL2MMU: threadCtrl is NULL (@%x).", pc()));
		return _threadCtrl; 
	}
	
	BOOL skipFork(void) { return _skipFork; }
	void skipFork(BOOL t) { _skipFork = t; }
	void setExecMode(INT modeID, WORD value);
	
	ADDR execute(ADDR addr, SL2Instr* instr) {
		ADDR ret_addr;
		pc(addr);
		this->reg().currAddr(addr);
		ret_addr = (this->*(instr->exec()))(instr);
		status().logExec(addr, ret_addr, instr);
		return loopMode(addr, ret_addr);
	}

	INT motionBitCost(WORD data);

	// Private
	ADDR execC2psum16_old (SL2Instr* instr);
	ADDR execC2psum16 (SL2Instr* instr);
	ADDR execC2pmov (SL2Instr* instr);
	ADDR execC2padds (SL2Instr* instr);
	ADDR execC2psum4t2 (SL2Instr* instr);
	ADDR execC2psum4t1 (SL2Instr* instr);
	ADDR execC2pmedc (SL2Instr* instr);
	ADDR execC2psadds (SL2Instr* instr);
	ADDR execC2pspadd (SL2Instr* instr);
	ADDR execC2pxadd (SL2Instr* instr);
	ADDR execC2pxsub (SL2Instr* instr);
	
	ADDR execC2prret (SL2Instr* instr);
	

	// BR
	ADDR execC2brf  (SL2Instr* instr);
	ADDR execC2brt (SL2Instr* instr);
	ADDR execC2fork (SL2Instr* instr);
	ADDR execC2joint (SL2Instr* instr);
	ADDR execC2thctrl (SL2Instr* instr);

	// LS
	ADDR execC2ldVB2RF (SL2Instr* instr);
	ADDR execC2ldVB2GPR (SL2Instr* instr);
	ADDR execC2stRF2VB (SL2Instr* instr);
	ADDR execC2stGPR2VB (SL2Instr* instr);
	ADDR execC2ld (SL2Instr* instr);
	ADDR execC2mvgc (SL2Instr* instr);
	ADDR execC2mvgr (SL2Instr* instr);
	ADDR execC2st (SL2Instr* instr);

	// Macro
	ADDR execC2intra (SL2Instr* instr);
	ADDR execC2mads (SL2Instr* instr);
	ADDR execC2mvsel (SL2Instr* instr);
	ADDR execC2satd_old (SL2Instr* instr);
	ADDR execC2satd (SL2Instr* instr);
	ADDR execC2smads (SL2Instr* instr);
	ADDR execC2vsad_old (SL2Instr* instr);
	ADDR execC2vsad (SL2Instr* instr);
	ADDR execC2vspel (SL2Instr* instr);
	ADDR execC2vspmac (SL2Instr* instr);

	// VMULT
	ADDR execC2mmul (SL2Instr* instr);
	ADDR execC2vcopy (SL2Instr* instr);
	ADDR execC2vmov (SL2Instr* instr);
	ADDR execC2vmul (SL2Instr* instr);

	// VADD
	ADDR execC2lczero (SL2Instr* instr);
	ADDR execC2vadds (SL2Instr* instr);
	ADDR execC2vclg (SL2Instr* instr);
	ADDR execC2vclp (SL2Instr* instr);
	ADDR execC2vcmov (SL2Instr* instr);
	ADDR execC2vcmpr (SL2Instr* instr);
	ADDR execC2vneg (SL2Instr* instr);
	ADDR execC2vrnd (SL2Instr* instr);
	ADDR execC2vshft (SL2Instr* instr);
	ADDR execC2vspas (SL2Instr* instr);
	ADDR execC2vsubs (SL2Instr* instr);

	// MULT
	ADDR execC2muls (SL2Instr* instr);

	// ADD
	ADDR execC2adds (SL2Instr* instr);
	ADDR execC2bcst (SL2Instr* instr);
	ADDR execC2chkrng (SL2Instr* instr);
	ADDR execC2cmov (SL2Instr* instr);
	ADDR execC2clp (SL2Instr* instr);
	ADDR execC2med (SL2Instr* instr);
	ADDR execC2scond (SL2Instr* instr);
	ADDR execC2subs (SL2Instr* instr);

	// BIT
	ADDR execC2bdep (SL2Instr* instr);
	ADDR execC2bop (SL2Instr* instr);
	ADDR execC2bxtr (SL2Instr* instr);
	ADDR execC2clzob (SL2Instr* instr);

	// SUM4
	ADDR execC2gsum4s (SL2Instr* instr);
	ADDR execC2sum4 (SL2Instr* instr);
	ADDR execC2mov (SL2Instr* instr);
	
	// VLCS		
	ADDR execC2vlcs (SL2Instr* instr);

};

#endif
