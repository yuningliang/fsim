#ifndef SL2DECODER_H_
#define SL2DECODER_H_
#include "cdecoder.h"
#include "sl2defs.h"
#include "sl2instr.h"

class SL2Decoder : public CoreDecoder<SL2Instr>{
	
	public:
	SL2Decoder(void);
	SL2Decoder(BOOL b);
	UINT32 decode (SL2Instr* instr, ADDR pc, WORD raw);
	UINT32 decode (SL2Instr* instr,  ADDR pc, WORD raw, UINT meta); //psim uses
	
	private:
	void decodeC2_psum16_private_old (SL2Instr* instr, UBYTE op_mode, UBYTE shft) {
		instr->op_mode(op_mode);
		instr->shft(shft);
	}
	void decodeC2_psum16_private(SL2Instr* instr, UBYTE op_mode, UBYTE shft) {
		instr->op_mode(op_mode);
		instr->shft(shft);
	}
	
	void decodeC2_psum4t1_private (SL2Instr* instr, UBYTE bk0, UBYTE bk1,
			 UBYTE bk2, UBYTE imm2, UBYTE lshft_amnt, UBYTE rshft_amnt, UWORD wen) {
		instr->bk0(bk0);
		instr->bk1(bk1);
		instr->bk2(bk2);
		instr->imm2(imm2);
		instr->lshft_amnt(lshft_amnt);
		instr->rshft_amnt(rshft_amnt);
		instr->wen(wen);	
	}
	void decodeC2_psum4t2_private (SL2Instr* instr, UBYTE bk0, UBYTE bk1, UBYTE bk2, 
				UBYTE lshft_amnt, UBYTE rshft_amnt, UWORD wen) {
		instr->bk0(bk0);
		instr->bk1(bk1);
		instr->bk2(bk2);
		instr->lshft_amnt(lshft_amnt);
		instr->rshft_amnt(rshft_amnt);
		instr->wen(wen);					
	}
	void decodeC2_padds_private (SL2Instr* instr, UBYTE bk0, UBYTE bk1, UBYTE carry, UBYTE shft_amnt, UWORD wen) {
		instr->bk0(bk0);
		instr->bk1(bk1);
		instr->carry(carry);
		instr->shft_amnt(shft_amnt);
		instr->wen(wen);
	}
	void decodeC2_pmov_private (SL2Instr* instr, UBYTE bk0, UWORD wen) {
		instr->bk0(bk0);
		instr->wen(wen);		
	}
	void decodeC2_pmedc_private (SL2Instr* instr, UBYTE op_mode) {
		instr->op_mode(op_mode);
	}

	void decodeC2_vsubs_private (SL2Instr* instr, UBYTE size,
			 	UBYTE in_pair, UBYTE op_mode, UBYTE shft_mode) {
		instr->size(size);
		instr->in_pair(in_pair);
		instr->op_mode(op_mode);
		instr->shft_mode(shft_mode);
	}
	void decodeC2_vadds_private (SL2Instr* instr, UBYTE size,
			 	UBYTE in_pair, UBYTE carry, UBYTE shft_mode) {
		instr->size(size);
		instr->in_pair(in_pair);
		instr->carry(carry);
		instr->shft_mode(shft_mode);
	}	
	void decodeC2_mmul_private (SL2Instr* instr, UBYTE op_mode, UBYTE size, WORD sl_indx) {
		instr->op_mode(op_mode);
		instr->size(size);
		instr->sl_indx(sl_indx);
	}
	void decodeC2_mvgr_private (SL2Instr* instr, UBYTE bank, UBYTE op_mode,
			 	UBYTE dir, UBYTE sign_ext, UBYTE bc_dir, UBYTE size) {
		instr->bank(bank);
		instr->op_mode(op_mode);
		instr->dir(dir);
		instr->sign_ext(sign_ext);
		instr->bc_dir(bc_dir);	
		instr->size(size);	
	}	
	void decodeC2_muls_private (SL2Instr* instr, UBYTE opd_shft, UBYTE shft_amnt) {
		//instr->size(size);
		instr->rs3(shft_amnt);      // ISA3.1
		instr->opd_shft(opd_shft);  // Add by WWD
	}
	void decodeC2_adds_private (SL2Instr* instr, UBYTE opd_shft, UBYTE size,
				UBYTE gpr, UBYTE imm1, UBYTE carry, UBYTE shft_amnt) {
		instr->opd_shft(opd_shft);
		instr->size(size);
		instr->gpr(gpr);
		instr->imm1(imm1);
		instr->carry(carry);
		instr->shft_amnt(shft_amnt);
	}	
	void decodeC2_mvsel_private (SL2Instr* instr, UBYTE op_mode) {
		instr->op_mode(op_mode);
	}
	void disasmC2_vspel_private (SL2Instr* instr, UBYTE cl_indx, UBYTE size, 
				UBYTE op_mode, WORD sl_indx) {
		instr->cl_indx(cl_indx);
		instr->size(size);
		instr->op_mode(op_mode);
		instr->sl_indx(sl_indx);
	}	
	void disasmC2_pspadd_private (SL2Instr* instr, UBYTE size, WORD sl_indx) {
		instr->sl_indx(sl_indx);
		instr->size(size);
	}	

	void decodeC2_pxadd_private (SL2Instr* instr,  WORD sl_indx) {
		instr->sl_indx(sl_indx);
	}	
	void decodeC2_pxsub_private (SL2Instr* instr,  WORD sl_indx) {
		instr->sl_indx(sl_indx);
	}		
	public:
	
	//private instruction
	UINT32 decodeC2_prret  (SL2Instr* instr, UINT meta);
	
	//autogen
	//SL2Instruction decoding function
	// BR
	UINT32 decodeC2_br  (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_fork (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_joint (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_thctrl (SL2Instr* instr, UINT meta);

	// LS
	UINT32 decodeC2_ld (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_mvgc (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_mvgr (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_st (SL2Instr* instr, UINT meta);

	// Macro
	UINT32 decodeC2_intra (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_mads (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_mvsel (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_satd_old (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_satd (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_smads (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_vsad_old (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_vsad (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_vspel (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_vspmac (SL2Instr* instr, UINT meta);

	// VMULT
	UINT32 decodeC2_mmul (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_vcopy (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_vmov (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_vmul (SL2Instr* instr, UINT meta);

	// VADD
	UINT32 decodeC2_lczero (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_vadds (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_vclg (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_vclp (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_vcmov (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_vcmpr (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_vneg (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_vrnd (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_vshft (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_vspas (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_vsubs (SL2Instr* instr, UINT meta);

	// MULT
	UINT32 decodeC2_muls (SL2Instr* instr, UINT meta);

	//ADD
	UINT32 decodeC2_adds (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_bcst (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_chkrng (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_cmov (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_clp (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_med (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_scond (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_subs (SL2Instr* instr, UINT meta);

	//BIT
	UINT32 decodeC2_bdep (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_bop (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_bxtr (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_clzob (SL2Instr* instr, UINT meta);

	// SUM4
	UINT32 decodeC2_gsum4s (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_mov (SL2Instr* instr, UINT meta);
	UINT32 decodeC2_sum4 (SL2Instr* instr, UINT meta);

	//VLCS
	UINT32 decodeC2_vlcs (SL2Instr* instr, UINT meta);

};
#endif /*SL1DECODER_H_*/
