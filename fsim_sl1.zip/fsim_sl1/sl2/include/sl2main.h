#ifndef SL2MAIN_H_
#define SL2MAIN_H_

//class Fetch;
//class SL2Decoder;
//class SL2Exec;
//class SL2Disasm;
//class SL2Instr;
//class SL2MMU;

int fsim_shell_set_param_core(SL2Fetch *pFetch, SL2Exec *pExec, SL2Disasm *pDisasm);

SL2Exec *fsim_get_core_exec(void);
SL2Fetch *fsim_get_core_fetch(void);
SL2Disasm *fsim_get_core_disasm(void);

#endif /*SL2MAIN_H_*/
