#ifndef SL2THREADCTRL_H_
#define SL2THREADCTRL_H_

#include "sl2defs.h"
#include "status.h"

class SL2Machine;

class SL2ThreadCtrl {
	private:
	BOOL _isThreadMode;
	UINT _thStackIndex;
	UINT _thStack[MAX_THREAD];
	UINT _thStatusBackup[MAX_THREAD];
	ProcessStatus<SL2Instr>& _status;
	SL2Machine& _machine;
	ADDR _jointAddr;
	
	public:
	SL2ThreadCtrl(ProcessStatus<SL2Instr>& s, SL2Machine& m);
	ProcessStatus<SL2Instr>& status(void) { return _status; }
	SL2Machine& machine(void) { return _machine; }
	BOOL isThreadMode(void) { return _isThreadMode; }
	ADDR joint(UINT thid, ADDR addr);
	void fork(UINT thid, ADDR addr, BOOL major);
	BOOL isEnd(void);
	ADDR jointAddr(void) { return _jointAddr; }
	void jointAddr(ADDR addr) { _jointAddr = addr; }
	void copyReg0_1(void); //copy whole GPR from thread0 to thread1
	void copyReg1_0(UINT rd, UINT rs1); //copy whole a single GPR from thread1 to thread0
	void thctrl(UINT cur_thid, UINT tar_thid, UINT op_mode);
};

#endif /*SL2THREADCTRL_H_*/
