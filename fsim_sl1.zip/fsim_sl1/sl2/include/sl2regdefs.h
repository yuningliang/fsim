#ifndef SL2REGDEFS_H_
#define SL2REGDEFS_H_

#include "cregdefs.h"

#define REG_SIMD_ROW 32
#define REG_SIMD_BANK 16
#define REG_SCALAR_SIZE REG_GPR_SIZE
#define REG_C2_CTRL_SIZE 8 //ISA2.9 for c2.muls
#define REG_C2_SPEC_SIZE 9
#define REG_C2_ACC_SIZE 1 
#define REG_C2_INTERNAL_SIZE 11


#define EBASE_SIMD (EBASE_CORE_REGS_LAST_INDEX + 1)
#define EBASE_C2_CTRL (EBASE_SIMD + REG_SIMD_ROW)
#define EBASE_C2_SPEC (EBASE_C2_CTRL + REG_C2_CTRL_SIZE)
//C2 ACC register
#define EBASE_C2_ACC (EBASE_C2_SPEC + REG_C2_SPEC_SIZE)
#define EBASE_C2_INTERNAL (EBASE_C2_ACC + REG_C2_ACC_SIZE)
#define EBASE_SCALAR (EBASE_C2_INTERNAL + REG_C2_INTERNAL_SIZE)
#define EBASE_C2_REGS_LAST_INDEX (EBASE_C2_INTERNAL + REG_C2_INTERNAL_SIZE - 1)
#define EBASE_C2_REGS_SIZE (EBASE_C2_INTERNAL + REG_C2_INTERNAL_SIZE - EBASE_CORE_REGS_SIZE)

#define SL2_SIMD_STATUS_UNUSED 		0
#define SL2_SIMD_STATUS_READ	 	1
#define SL2_SIMD_STATUS_WRITE 		2
#define SL2_SIMD_STATUS_READWRITE	3

#define SL2_SIMDBANK_STATUS_READ	 	0x55555555
#define SL2_SIMDBANK_STATUS_WRITE 		0xAAAAAAAA
#define SL2_SIMDBANK_STATUS_READWRITE	0xFFFFFFFF

#define SL2_SIMD_NOPAIR				0
#define SL2_SIMD_PAIR				1

enum ECR_C2_CTRL {
	EC2CR_UNDEF = -1,
	EC2CR_VADD_SHFT = 0,
	EC2CR_DCAC_SHFT = 1,
	EC2CR_ADD_CTRL = 2,
	EC2CR_MVSEL = 3,
	EC2CR_SUM_CTRL = 4,	
	EC2CR_LS_SW = 5,	
	EC2CR_LS_CTRL = 6,
	EC2CR_MULT_HI = 7, // ISA2.9 mul.s
	EC2CR_MAX = 8,
};

enum ECR_C2_ACC {
	EC2ACC_UNDEF = -1,
	EC2ACC_SUM = 0,
	EC2ACC_MAX = 1,
};

enum ECR_C2_SPEC {
	EC2SPEC_UNDEF = -1,
	EC2SPEC_COND = 0,
	EC2SPEC_MOV_PAT = 1,
	EC2SPEC_START = 2,
	EC2SPEC_BITS = 3,
	EC2SPEC_BEST_MV = 4,
	EC2SPEC_BEST_SAD = 5,
	EC2SPEC_BEST_COST = 6,
	EC2SPEC_BYTE_COLL = 7,
	EC2SPEC_MV_COST = 8,
	EC2SPEC_MAX = 9,
};

enum ECR_C2_INTERNEL {
	EC2INT_UNDEF = -1,
	EC2INT_START_OF_BLK = 0,
	EC2INT_ZERO_CNT = 1,
	EC2INT_TOTAL_ZERO = 2,
	EC2INT_TRAIL_ONE = 3,
	EC2INT_NUM_OF_NON_ZERO = 4,
	EC2INT_COEFF_COST = 5,
	EC2INT_COEFF_CNT = 6,
	EC2INT_WRITE_SEL = 7,
	EC2INT_BANK = 8,
	EC2INT_MED_CMP = 9,
	EC2INT_TRAIL_SIGN = 10,
	EC2INT_MAX = 11,
};

union c2_ctrl_simd_shft {
	unsigned word;
	struct {
		unsigned result_right_shift : 32;
	} bits;
};

union c2_ctrl_vmacs_shft {
	unsigned word;
	struct {
		unsigned result_rs_0 : 8;
		unsigned result_rs_15_1 : 8;
		unsigned na : 16;
	} bits;
};

union c2_ctrl_mad_ctrl {
	unsigned word;
	struct {
		unsigned rs1_bank : 4;
		unsigned rs2_bank : 4;
		unsigned rs3_bank : 4;
		unsigned opd_ls_rs : 2;
		unsigned result_rs : 2;
		unsigned rf_write_enable : 16;
	} bits;
};

union c2_ctrl_mad_mvsel {
	unsigned word;
	struct {
		unsigned lambda_factor : 16;
		unsigned na2 : 8;
		unsigned scalar_factor : 4;
		unsigned na1 : 4;
	} bits;
};

union c2_ctrl_sum_ctrl {
	unsigned word;
	struct {
		unsigned rs1_bank : 4;
		unsigned rs2_bank : 4;
		unsigned rs3_bank : 4;
		unsigned opd_ls_rs : 2;
		unsigned result_rs : 2;
		unsigned rf_write_enable : 16;
	} bits;
};

union c2_ctrl_ls_sw_ctrl {
	unsigned word;
	struct {
		unsigned dummy : 5;
		unsigned search_window_pitch: 11;
		unsigned search_window_size : 12;
		unsigned na : 4;
	} bits;
};

union c2_ctrl_ls_ctrl {
	unsigned word;
	struct {
		unsigned rf_vb_write_enable : 16;
		unsigned row_count : 5;
		unsigned na : 11;
	} bits;
};

#endif /*REGDEFS_H_*/
