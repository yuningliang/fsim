#ifndef SL2REGISTER_H_
#define SL2REGISTER_H_

#include "defs.h"
#include "creg.h"
#include "sl2regdefs.h"
#include "status.h"
#include "sl2defs.h"

class SL2Instr;

#define SL2_GETGPR(rs) reg().getGPR(rs)
#define SL2_SETGPR(rd, data) reg().setGPR(rd, data)

#define THREAD_PAIR_MAXNUMBER	3
#define THREAD_PAIR_ZERO		0
#define THREAD_PAIR_ONE 		1
#define THREAD_PAIR_TWO 		2


typedef struct _SIMD_Ctrol_Type{	
	WORD SIMD_Ctrl[THREAD_PAIR_MAXNUMBER][REG_SIMD_ROW][2];
	UINT Instr    [THREAD_PAIR_MAXNUMBER][REG_SIMD_ROW][2];
	UINT Thread_ID[THREAD_PAIR_MAXNUMBER][REG_SIMD_ROW][2];
	UINT conflict_SIMD_bank[THREAD_PAIR_MAXNUMBER][REG_SIMD_ROW][2];
	UINT conflict [THREAD_PAIR_MAXNUMBER][REG_SIMD_ROW];
	UINT Thread_pair_LUT[MAX_THREAD];  // thid is input index, and its value is thread_pair
	UINT _checkSIMDRegister;
	FILE *out;   // This is not good method, just save it here, will remove
}SIMD_Ctrol_Type;

class SL2Register : public CoreRegister<SL2Instr> {
	private:
	WORD* _c2ctrl;
	WORD* _c2spec;
	WORD* _c2internal;
	WORD _sum_acc;
	HWORD** _simd;
	WORD _hi;

	///*** add
	SIMD_Ctrol_Type*  _simd_ctrl;  // used for internal only (FSIM)
	ADDR	_curr_addr;
	
	public:
	SL2Register(ProcessStatus<SL2Instr>& status);
	SL2Register(ProcessStatus<SL2Instr>& status, 
			WORD* ctrl, WORD* spec, WORD* internal, HWORD** simd, SIMD_Ctrol_Type* simd_ctrl);
	SL2Register(ProcessStatus<SL2Instr>& status, HWORD** simd, SIMD_Ctrol_Type* simd_ctrl);			
	INT createNameMap(RegMap& regmap);
	//register checking interface switch
	void enableRegChecker(BOOL t) {
		checkSIMDRegister(t==TRUE?1:0);
	}
	
	void clear();
	WORD* getCtrlPtr(void) { return _c2ctrl; }
	WORD* getSpecPtr(void) { return _c2spec; }
	WORD* getInternalPtr(void) { return _c2internal; }
	HWORD** getSIMDPtr(void) { return _simd; }		
	SIMD_Ctrol_Type*  getSIMDCtrolPtr(void){ return _simd_ctrl; }	
	WORD getHI(void) { 
		return _hi;
	}	
	void setHI(WORD data) { 
//		LOG_REG_WRITE(ESR_HI, EBASE_CTRL, data)
		_hi = data;
	}

	///***
	INT checkSIMDRegister(void) { return _simd_ctrl->_checkSIMDRegister; }
	void checkSIMDRegister(INT val) { _simd_ctrl->_checkSIMDRegister= val; }
	ADDR currAddr(void) { return _curr_addr;}
	void currAddr(ADDR val) { _curr_addr = val; }
	// It will check SIMD conflict when "" set to 1 and give conflict position for programmer
	void Check_SIMD_Conflict(int row, int pair, int operation, int bank)  // when bank is 16, it means check all 16 banks
	{
		if(checkSIMDRegister())
		{
			INT thid = status().thread_id();
			// use which pair: we have three pair T0+T1; T0+T2; T1+T3. And it is dymamic changed by thread control functions
			INT thread_pair = _simd_ctrl->Thread_pair_LUT[thid];
			
			// ID in one pair: 0 or 1. Because T1 can belong two pair, process it specially.
			INT pid = (thid==0)? (0): ((thid>1)? (1): ((thread_pair==0)?1:0));
			INT opid = pid^1;

			ADDR currPC = currAddr();


			{
				if(operation == SL2_SIMD_STATUS_READ) // current operation is read SIMD, so, check write
				{
					UINT write_mask;
					UINT read_status;
					if(bank== 16)
					{
						// Check all bank in the row
						write_mask = SL2_SIMDBANK_STATUS_WRITE;
						read_status = SL2_SIMDBANK_STATUS_READ;
					}
					else
					{
						// Check all row[bank] only
						AppFatal((bank<16), ("SIMD bank can not be larger than 16\n"));
						write_mask = (SL2_SIMD_STATUS_WRITE << (2*bank));
						read_status = (SL2_SIMD_STATUS_READ << (2*bank));
					}
						
					if(_simd_ctrl->conflict[thread_pair][row] == 0) // do not conflict before, so, checking...
					{
						if(_simd_ctrl->SIMD_Ctrl[thread_pair][row][opid] & write_mask)
						{
							// Conflict
							_simd_ctrl->conflict[thread_pair][row] = 1;
							_simd_ctrl->Instr[thread_pair][row][1] = currPC;
							_simd_ctrl->Thread_ID[thread_pair][row][1] = thid;
							_simd_ctrl->conflict_SIMD_bank[thread_pair][row][1] = bank;

						}
						else
						{
							_simd_ctrl->SIMD_Ctrl[thread_pair][row][pid] |= read_status;
							_simd_ctrl->Instr[thread_pair][row][0] = currPC;
							_simd_ctrl->Thread_ID[thread_pair][row][0] = thid;
							_simd_ctrl->conflict_SIMD_bank[thread_pair][row][0] = bank;
						}
					}

					if((pair) && (_simd_ctrl->conflict[thread_pair][row+1] == 0))	// do not conflict before, so, checking...
					{
						if(_simd_ctrl->SIMD_Ctrl[thread_pair][row+1][opid] & write_mask)
						{
							_simd_ctrl->conflict[thread_pair][row+1] = 1;
							_simd_ctrl->Instr[thread_pair][row+1][1] = currPC;
							_simd_ctrl->Thread_ID[thread_pair][row+1][1] = thid;
							_simd_ctrl->conflict_SIMD_bank[thread_pair][row+1][1] = bank;
						}
						else
						{
							_simd_ctrl->SIMD_Ctrl[thread_pair][row+1][pid] |= read_status;
							_simd_ctrl->Instr[thread_pair][row+1][0] = currPC;
							_simd_ctrl->Thread_ID[thread_pair][row+1][0] = thid;
							_simd_ctrl->conflict_SIMD_bank[thread_pair][row+1][0] = bank;
						}
					}
				}
				else		// current thread operation is write, so, check 
				{
					UINT read_mask;
					UINT write_status;
					if(bank== 16)
					{
						// Check all bank in the row
						read_mask = SL2_SIMDBANK_STATUS_READWRITE;
						write_status = SL2_SIMDBANK_STATUS_WRITE;
					}
					else
					{
						// Check all row[bank] only
						AppFatal((bank<16), ("SIMD bank can not be larger than 16\n"));
						read_mask = (SL2_SIMD_STATUS_READWRITE << (2*bank));
						write_status = (SL2_SIMD_STATUS_WRITE<< (2*bank));
					}

					if(_simd_ctrl->conflict[thread_pair][row] == 0)
					{
						if(_simd_ctrl->SIMD_Ctrl[thread_pair][row][opid] & read_mask) // conflict
						{
							_simd_ctrl->conflict[thread_pair][row] = 1;
							_simd_ctrl->Instr[thread_pair][row][1] = currPC;
							_simd_ctrl->Thread_ID[thread_pair][row][1] = thid;
							_simd_ctrl->conflict_SIMD_bank[thread_pair][row][1] = bank;							
						}
						else
						{
							_simd_ctrl->SIMD_Ctrl[thread_pair][row][pid] |= write_status;
							_simd_ctrl->Instr[thread_pair][row][0] = currPC;
							_simd_ctrl->Thread_ID[thread_pair][row][0] = thid;
							_simd_ctrl->conflict_SIMD_bank[thread_pair][row][0] = bank;
						}
					}

					if((pair) && (_simd_ctrl->conflict[thread_pair][row+1] == 0))
					{
						if(_simd_ctrl->SIMD_Ctrl[thread_pair][row+1][opid] & read_mask)
						{
							_simd_ctrl->conflict[thread_pair][row+1] = 1;
							_simd_ctrl->Instr[thread_pair][row+1][1] = currPC;
							_simd_ctrl->Thread_ID[thread_pair][row+1][1] = thid;
							_simd_ctrl->conflict_SIMD_bank[thread_pair][row+1][1] = bank;
						}
						else
						{
							_simd_ctrl->SIMD_Ctrl[thread_pair][row+1][pid] |= write_status;
							_simd_ctrl->Instr[thread_pair][row+1][0] = currPC;
							_simd_ctrl->Thread_ID[thread_pair][row+1][0] = thid;
							_simd_ctrl->conflict_SIMD_bank[thread_pair][row+1][0] = bank;
						}
					}
				}
			}
		}
		
	}

	// This function should be called in joint instruction
	void dump_Conflict_info(int thread_pair){
		INT hasConflict = 0;
		if(checkSIMDRegister())	{
			for(INT i=0; i< REG_SIMD_ROW; i++){
				if(_simd_ctrl->conflict[thread_pair][i]){
					printf("#SIMD Checker: SIMD registers conflict in thread [%d]-[0x%08x] and [%d]-[0x%08x] in RF[%02d] (%02d, %02d).\n",
						_simd_ctrl->Thread_ID[thread_pair][i][0], _simd_ctrl->Instr[thread_pair][i][0], 
						_simd_ctrl->Thread_ID[thread_pair][i][1],_simd_ctrl->Instr[thread_pair][i][1],i, 
						_simd_ctrl->conflict_SIMD_bank[thread_pair][i][0], _simd_ctrl->conflict_SIMD_bank[thread_pair][i][1]);
					_simd_ctrl->conflict[thread_pair][i] = 0;
					hasConflict = 1;
				}
			}
			if(hasConflict)
				printf("\n");
		}
	}

	void clear_SIMD_Control(int thread_pair)	{
		if(checkSIMDRegister())		{
			for(INT i=0; i<REG_SIMD_ROW; i++){
				_simd_ctrl->SIMD_Ctrl[thread_pair][i][0] = 0;
				_simd_ctrl->SIMD_Ctrl[thread_pair][i][1] = 0;
				_simd_ctrl->Instr[thread_pair][i][0] = 0;
				_simd_ctrl->Instr[thread_pair][i][1]= 0;

				_simd_ctrl->conflict_SIMD_bank[thread_pair][i][0]= 0;
				_simd_ctrl->conflict_SIMD_bank[thread_pair][i][1]= 0;

				_simd_ctrl->conflict[thread_pair][i] = 0;
			}
		}
	}

	void set_SIMD_Control_LUT(int thid, int thread_pair){
		if(checkSIMDRegister())	{
			_simd_ctrl->Thread_pair_LUT[thid] = thread_pair;
		}
	}
	
	HWORD getSIMD(UINT32 row, UINT32 bank, BOOL b_mvgr=0) { 
		AppFatal((row<REG_SIMD_ROW), ("Register: invalid SIMD row index (%d) @0x%08x.", row, status().pre_pc())); 
		AppFatal((bank<REG_SIMD_BANK), ("Register: invalid SIMD bank index (%d) @0x%08x.", bank, status().pre_pc()));

		if(b_mvgr == 0)
			Check_SIMD_Conflict(row, SL2_SIMD_NOPAIR, SL2_SIMD_STATUS_READ, REG_SIMD_BANK);
		else
			Check_SIMD_Conflict(row, SL2_SIMD_NOPAIR, SL2_SIMD_STATUS_READ, bank);

		return _simd[row][bank];
	}
	void setSIMD(UINT32 row, UINT32 bank, HWORD data, BOOL b_mvgr=0) { 
		AppFatal((row<REG_SIMD_ROW), ("Register: invalid SIMD row index (%d) @0x%08x.", row, status().pre_pc())); 
		AppFatal((bank<REG_SIMD_BANK), ("Register: invalid SIMD bank index (%d) @0x%08x.", bank, status().pre_pc())); 		

		if(b_mvgr == 0)
			Check_SIMD_Conflict(row, SL2_SIMD_NOPAIR, SL2_SIMD_STATUS_WRITE, REG_SIMD_BANK);
		else
			Check_SIMD_Conflict(row, SL2_SIMD_NOPAIR, SL2_SIMD_STATUS_WRITE, bank);

		_simd[row][bank] = data;
	}
	WORD getSIMDPair(UINT32 row, UINT32 bank, BOOL b_mvgr=0) { 
		AppFatal(((row<REG_SIMD_ROW)&&((row&HWORD_ALIGN_MASK)==0)), ("Register: invalid pair SIMD row index (%d) @0x%08x.", row, status().pre_pc()));
		AppFatal((bank<REG_SIMD_BANK), ("Register: invalid SIMD bank index (%d) @0x%08x.", bank, status().pre_pc())); 

		if(b_mvgr == 0)
			Check_SIMD_Conflict(row, SL2_SIMD_PAIR, SL2_SIMD_STATUS_READ, REG_SIMD_BANK);
		else
			Check_SIMD_Conflict(row, SL2_SIMD_PAIR, SL2_SIMD_STATUS_READ, bank);

			
		WORD data = (((WORD)_simd[row+1][bank]&HWORD_DATA_MASK)<<HWORD_BIT) | (_simd[row][bank]&HWORD_DATA_MASK);
		return data;
	}
	void setSIMDPair(UINT32 row, UINT32 bank, WORD data, BOOL b_mvgr=0) { 
		AppFatal(((row<REG_SIMD_ROW)&&((row&HWORD_ALIGN_MASK)==0)), ("Register: invalid pair SIMD row index (%d) @0x%08x.", row, status().pre_pc()));
		AppFatal((bank<REG_SIMD_BANK), ("Register: invalid SIMD bank index (%d) @0x%08x.", bank, status().pre_pc())); 

		if(b_mvgr == 0)
			Check_SIMD_Conflict(row, SL2_SIMD_PAIR, SL2_SIMD_STATUS_WRITE, REG_SIMD_BANK);
		else
			Check_SIMD_Conflict(row, SL2_SIMD_PAIR, SL2_SIMD_STATUS_WRITE, bank);

			
		_simd[row+1][bank] = (HWORD) ((data>>HWORD_BIT)&HWORD_DATA_MASK);
		_simd[row][bank] = (HWORD) (data&HWORD_DATA_MASK);
	}

	void setSIMD_ROW(UINT32 row, HWORD data) {
		AppFatal((row<REG_SIMD_ROW), ("Register: invalid SIMD row index (%d) @0x%08x.", row, status().pre_pc())); 

		Check_SIMD_Conflict(row, SL2_SIMD_NOPAIR, SL2_SIMD_STATUS_WRITE, REG_SIMD_BANK);

		for(INT i=0; i< REG_SIMD_BANK; i++) 
			_simd[row][i] = data;
	}	
	void setSIMDPair_ROW(UINT32 row, WORD data) {
		AppFatal(((row<REG_SIMD_ROW)&&((row&HWORD_ALIGN_MASK)==0)), ("Register: invalid pair SIMD row index (%d) @0x%08x.", row, status().pre_pc())); 

		Check_SIMD_Conflict(row, SL2_SIMD_PAIR, SL2_SIMD_STATUS_WRITE, REG_SIMD_BANK);

		for(INT i=0; i< REG_SIMD_BANK; i++) {
			_simd[row+1][i] = (HWORD) ((data>>HWORD_BIT)&HWORD_DATA_MASK);
			_simd[row][i] = (HWORD) (data&HWORD_DATA_MASK);
		}
	}	

	WORD getC2CTRL(UINT32 index) { 
		AppFatal((index<REG_C2_CTRL_SIZE), ("Register: invalid c2 ctrl reg index (%d) @0x%08x.", index, status().pre_pc()));
		return (_c2ctrl[index]);
	}
	void setC2CTRL(UINT32 index, WORD data) { 
		AppFatal((index<REG_C2_CTRL_SIZE), ("Register: invalid c2 ctrl reg index (%d) @0x%08x.", index, status().pre_pc()));
		_c2ctrl[index] = data;
	}	

	WORD getC2SPEC(UINT32 index) { 
		AppFatal((index<REG_C2_SPEC_SIZE), ("Register: invalid c2 spec reg index (%d) @0x%08x.", index, status().pre_pc()));
		return (_c2spec[index]);
	}
	void setC2SPEC(UINT32 index, WORD data) { 
		AppFatal((index<REG_C2_SPEC_SIZE), ("Register: invalid c2 spec reg index (%d) @0x%08x.", index, status().pre_pc()));
		_c2spec[index] = data;
	}

	WORD getC2INT(UINT32 index) { 
		AppFatal((index<REG_C2_INTERNAL_SIZE), ("Register: invalid c2 internal reg index (%d) @0x%08x.", index, status().pre_pc()));
		return (_c2internal[index]);
	}
	void setC2INT(UINT32 index, WORD data) { 
		AppFatal((index<REG_C2_INTERNAL_SIZE), ("Register: invalid c2 internal reg index (%d) @0x%08x.", index, status().pre_pc()));
		_c2internal[index] = data;
	}
	void incC2INT(UINT32 index, WORD data) { 
		AppFatal((index<REG_C2_INTERNAL_SIZE), ("Register: invalid c2 internal reg index (%d) @0x%08x.", index, status().pre_pc()));
		_c2internal[index] += data;
	}	
	void initC2INT(void) { 
		_c2internal[EC2INT_START_OF_BLK] = 1;
		_c2internal[EC2INT_COEFF_COST] = 0;
		_c2internal[EC2INT_NUM_OF_NON_ZERO] = 0;
		_c2internal[EC2INT_TRAIL_ONE] = 0;
		_c2internal[EC2INT_COEFF_CNT] = 0;
		_c2internal[EC2INT_ZERO_CNT] = 0;
		_c2internal[EC2INT_TOTAL_ZERO] = 0;
		_c2internal[EC2INT_WRITE_SEL] = 0;
		_c2internal[EC2INT_TRAIL_SIGN] = 0;
	}	
		
	WORD getC2SUM_ACC(void) { 
		return _sum_acc;
	}
	void setC2SUM_ACC(WORD data) { 
		_sum_acc = data;
	}	
	
	WORD getC2ACC(UINT32 index) { 
		AppFatal((index<REG_C2_ACC_SIZE), ("Register: invalid acc index (%d) @0x%08x.", index, status().pre_pc()));
		switch (index) {
			case EC2ACC_SUM:
				return getC2SUM_ACC();
			default:
				AppFatal((0), ("SL2 regsiter: Invalid acc index (%d) @0x%08x.", index, status().pre_pc()));
				return 0;
		}
	}

	void setC2ACC(UINT32 index, WORD data) { 
		AppFatal((index<REG_C2_ACC_SIZE), ("Register: invalid acc index (%d) @0x%08x.", index, status().pre_pc()));
		switch (index) {
			case EC2ACC_SUM:
				setC2SUM_ACC(data);
				break;
			default:
				AppFatal((0), ("SL2 regsiter: Invalid acc index (%d) @0x%08x.", index, status().pre_pc()));
		}
	}
	INT getRegIndexByName(const STRING regName);
	INT setRegByName(const STRING regName, DWORD value);
	bool isValidRegName(const STRING regName);
	void dumpRegs2File(FILE* out, const char *regSetName);
	void dumpRegs(FILE* out, const char *regSetName);		
	INT initRegs(FILE* out, const char *regSetName);		
};


#endif /*REGISTER_H_*/
