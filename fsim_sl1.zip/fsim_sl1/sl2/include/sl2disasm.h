#ifndef SL2DISASM_H_
#define SL2DISASM_H_

#include "cdisasm.h"
#include "sl2instr.h"

class SymTable;
class SL2MMU;
class SL2Register;
class SL2Decoder;

class SL2Disasm : public CoreDisasm<SL2MMU, SL2Register, SL2Instr> {
	public:	
	SL2Disasm(SL2MMU& mmu, SL2Register& reg, UINT th_id);

	STRING disasm(ADDR addr, SL2Instr* instr, UINT meta) {
		return (this->*(instr->print()))(addr, instr, meta);;
	}

	
	//	Private
	STRING disasmC2_psum16_private_old (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_psum16_private (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_psum4t1_private (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_psum4t2_private (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_padds_private (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_pmov_private (ADDR pc, SL2Instr* instr, UINT meta);	
	STRING disasmC2_pmedc_private (ADDR pc, SL2Instr* instr, UINT meta);	
	STRING disasmC2_psadds_private (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_pspadd_private (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_pxadd_private (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_pxsub_private (ADDR pc, SL2Instr* instr, UINT meta);
	
	STRING disasmC2_prret (ADDR pc, SL2Instr* instr, UINT meta);
	
	//Instruction disassembler function
	// BR
	STRING disasmC2_br  (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_fork (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_joint (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_thctrl (ADDR pc, SL2Instr* instr, UINT meta);
	

    // LS
	STRING disasmC2_ld (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_mvgc (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_mvgr (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_st (ADDR pc, SL2Instr* instr, UINT meta);

	//Macro
	STRING disasmC2_intra (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_mads (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_mvsel (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_satd_old (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_satd (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_smads (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_vsad_old (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_vsad (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_vspel (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_vspmac (ADDR pc, SL2Instr* instr, UINT meta);

	// Vmult
	STRING disasmC2_mmul (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_vcopy (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_vmov (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_vmul (ADDR pc, SL2Instr* instr, UINT meta);

	//Vadd
	STRING disasmC2_lczero (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_vadds (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_vclg (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_vclp (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_vcmov (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_vcmpr (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_vneg (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_vrnd (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_vshft (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_vspas (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_vsubs (ADDR pc, SL2Instr* instr, UINT meta);

	//Mult
	STRING disasmC2_muls (ADDR pc, SL2Instr* instr, UINT meta);

	// Add
	STRING disasmC2_adds (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_bcst (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_chkrng (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_cmov (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_clp (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_med (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_scond (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_subs (ADDR pc, SL2Instr* instr, UINT meta);

	// BIT
	STRING disasmC2_bdep (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_bop (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_bxtr (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_clzob (ADDR pc, SL2Instr* instr, UINT meta);

	// SUM4
	STRING disasmC2_gsum4s (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_sum4 (ADDR pc, SL2Instr* instr, UINT meta);
	STRING disasmC2_mov (ADDR pc, SL2Instr* instr, UINT meta);

	
	// vlcs
	STRING disasmC2_vlcs (ADDR pc, SL2Instr* instr, UINT meta);	
};

#endif /*SL1DISASM_H_*/
