#ifndef SL2DEFS_H_
#define SL2DEFS_H_

#include "defs.h"
#include <list>

#define SL2_CLASS_LIST SL2Register, SL2MMU, SL2Instr, SL2Decoder, SL2Fetch, SL2Exec, SL2Disasm, SL2Machine

#define SL2_INSTR_MODE 0x5

#define MAX_THREAD 4
#define MAX_MEM_VIEW 1

//Load/Store size
#define SL2_LS_BYTE 2
#define SL2_LS_HWORD 0
#define SL2_LS_WORD 1

//execution mode id
#define EXEC_MODE_SKIP_FORK 0

//macro instruction list
class SL2Instr;
typedef std::list<SL2Instr*> SL2InstrList;
typedef std::list<SL2Instr*>::iterator SL2InstrListIter;


//enum
enum SL2THREAD{
	THREAD_ID_MAIN_0 = THREAD_ID_0,
	THREAD_ID_MAIN_1 = THREAD_ID_1,
	THREAD_ID_SLAVE_0 = THREAD_ID_2,
	THREAD_ID_SLAVE_1 = THREAD_ID_3,
	THREAD_ID_MAX = 8
};

const STRING prompt_str[] = {
	"SL2Th0>",
	"SL2Th1>",
	"SL2Th2>",
	"SL2Th3>"
};

#endif /*SL2DEFS_H_*/
