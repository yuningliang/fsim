#ifndef SL2MACHINE_H_
#define SL2MACHINE_H_

#include "sl2defs.h"
#include "machine.h"

class SL2MMU;
class SL2Fetch;
class SL2Exec;
class SL2Instr;
class SL2Disasm;
class SL2Register;

#define SL2_INTERRUPT_LIST_INI SL2MMU, SL2Exec, SL2Instr

class SL2Machine : public Machine<SL2MMU, SL2Register, SL2Fetch, SL2Exec, SL2Instr, SL2Disasm, SL2Machine> {
	public:
	SL2Machine(SL2MMU& mmu, SL2Fetch& fetch, ProcessStatus<SL2Instr>& status) : 
		Machine<SL2MMU, SL2Register, SL2Fetch, SL2Exec, SL2Instr, SL2Disasm, SL2Machine>(mmu, fetch, status) {
			isMultiObject(FALSE);
			_eHandler = new EventHandler<SL2MMU, SL2Register, SL2Machine>(*(&mmu), this);
	}
};

#endif /*SL2MACHINE_H_*/
