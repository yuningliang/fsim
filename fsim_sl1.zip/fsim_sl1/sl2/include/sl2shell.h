#ifndef SL2SHELL_H_
#define SL2SHELL_H_

#include "sl2defs.h"
#include "memory.h"
#include "sl2address.h"
#include "sl2instr.h"
#include "status.h"
#include "sl2mmu.h"
#include "sl2reg.h"
#include "sl2exec.h"
#include "sl2fetch.h"
#include "sl2decoder.h"
#include "sl2disasm.h"
#include "sl2machine.h"
#include "shell.h"

class SL2Shell : public Shell<SL2_CLASS_LIST>{
	public:
	SL2Shell(void);
};

#endif /*SL2SHELL_H_*/
