#include "sl2exec.h"
#include "sl2instrtable.h"
#include "sl2regdefs.h"
#include "sl2threadctrl.h"
#include "sl2machine.h"
#include "sl2mmu.h"
#include "sl2reg.h"

SL2ThreadCtrl::SL2ThreadCtrl(ProcessStatus<SL2Instr>& s, SL2Machine& m) : _status(s), _machine(m) {
	_isThreadMode = FALSE;
	_jointAddr = 0;
	for(UINT i = 0; i<MAX_THREAD; i++) {
		_thStack[i] = 0;
		_thStatusBackup[i] = 0;
	}
	machine().mmu().setForkThreadSP(SL2_FORK_SP_DEFAULT);
}

BOOL SL2ThreadCtrl::isEnd(void) {
	for(UINT i = 0; i<MAX_THREAD; i++) {
		if(_thStack[i]>0) {
			return FALSE;
		}
	}	
	return TRUE;
}

 //copy whole a single GPR from thread1 to thread0
void SL2ThreadCtrl::copyReg1_0(UINT rd, UINT rs1) {
	SL2Register& dest = machine().getExec(THREAD_ID_MAIN_0)->reg();
	SL2Register& src = machine().getExec(THREAD_ID_MAIN_1)->reg();	
	dest.setGPR(rd, src.getGPR(rs1));
}

//copy whole GPR from thread0 to thread1
void SL2ThreadCtrl::copyReg0_1() {
	SL2Register& dest = machine().getExec(THREAD_ID_MAIN_1)->reg();
	SL2Register& src = machine().getExec(THREAD_ID_MAIN_0)->reg();
	status().suspense();
	for(INT i = 1; i<REG_GPR_SIZE; i++) {
		dest.setGPR(i, src.getGPR(i));
	}
	for(INT i = 1; i<REG_C2_CTRL_SIZE; i++) {
		dest.setC2CTRL(i, src.getC2CTRL(i));
	}
	/*
	for(INT i = 1; i<REG_C2_SPEC_SIZE; i++) {
		dest.setC2SPEC(i, src.getC2SPEC(i));
	}
	for(INT i = 1; i<REG_C2_INTERNAL_SIZE; i++) {
		dest.setC2INT(i, src.getC2INT(i));
	}		
	*/	
	status().resume();
}

// Sometime we want to display some debug infromation in FSIM to debug application. So, just add this 
//#define _DISPLAY_THREAD_INFO_


ADDR SL2ThreadCtrl::joint(UINT thid, ADDR nextPC) {
	pair<UINT, ADDR> ret;
	ADDR retAddr = nextPC;
	BOOL minor_joint=0;
	SL2Register& sl2reg = machine().getExec(thid)->reg();
	if(machine().isMultiThreadMode()==TRUE) {
		switch(thid) {
			case THREAD_ID_MAIN_0:

				// WWD: here is one bug: when we do not have minor thread IN major thread, the _thStacks are not correct for checking
				//           Need further tetsing...
				// The following three statements have problem when minor thread within one loop
				//if(_thStack[THREAD_ID_SLAVE_0]>0||_thStack[THREAD_ID_MAIN_1]>0) {
				//	machine().disablePC(thid);
				//}
				// So,  change them to:
				
				if(_thStack[thid] == 2)
					minor_joint = 1;
				else
					minor_joint = 0;
				if(minor_joint)
				{
					if(_thStack[THREAD_ID_SLAVE_0]>0)
						machine().disablePC(thid);
					// Otherwise, it can continue even (_thStack[THREAD_ID_MAIN_1]>0)
				}
				else
				{
					if(_thStack[THREAD_ID_MAIN_1]>0)
						machine().disablePC(thid);
				}
							
				_thStack[thid]--;
				if(_thStack[thid]==0) {
					jointAddr(nextPC);
				}


				// Debug Information
				#ifdef _DISPLAY_THREAD_INFO_
				printf("Joint [Th-0]: Stack[%d], Next Address[%08x]- PC[%08x]\t", _thStack[thid], jointAddr(), (UINT)machine().getPC(0));
				printf("Status for Thread-0 after joint is [%d]\n", machine().getPCEnable(0));	fflush(0);
				#endif

				// DUMP SIMD Checker information
				if(_thStack[thid]==0)
				{
					// Current thread-0 is complete and only thread-1 can be active in this pair
					// Complete major thread
					sl2reg.dump_Conflict_info(THREAD_PAIR_ONE);
					sl2reg.dump_Conflict_info(THREAD_PAIR_ZERO);
					sl2reg.set_SIMD_Control_LUT(THREAD_ID_MAIN_0, THREAD_PAIR_ZERO);
				}
				else
				{
					// Complete minor thread
					sl2reg.dump_Conflict_info(THREAD_PAIR_ONE);
					sl2reg.set_SIMD_Control_LUT(THREAD_ID_MAIN_0, THREAD_PAIR_ZERO);
				}
				break;
			case THREAD_ID_MAIN_1:
				//if(_thStack[THREAD_ID_SLAVE_1]>0||_thStack[thid]==0 || _thStack[0]>0) {
				//	machine().disablePC(thid);
				//}				
				if(_thStack[thid] == 2)
					minor_joint = 1;
				else
					minor_joint = 0;

				if(minor_joint)
				{
					if(_thStack[THREAD_ID_SLAVE_1]>0)
						machine().disablePC(thid);
				}
				else
				{
					machine().disablePC(thid);
					// Check if M0 is blocked due to this joint
					if((machine().getPCEnable(0)==0) & (_thStack[THREAD_ID_MAIN_0]== 0))
					{
						machine().setPC(THREAD_ID_MAIN_0, jointAddr());
						machine().enablePC(THREAD_ID_MAIN_0);
					}
				}
				
				_thStack[thid]--;
				

				// Debug information
				#ifdef _DISPLAY_THREAD_INFO_
				printf("Joint [Th-1]: Stack[%d], -- PC[%08x]\t", _thStack[thid], (ADDR)machine().getPC(1));
				printf("Status for Thread-1 after joint is [%d]\n", machine().getPCEnable(1)); fflush(0);
				#endif

				// DUMP SIMD Checker information
				if(_thStack[thid]==0)
				{
					// Current thread-0 is end and only thread-0 can be active
					sl2reg.dump_Conflict_info(THREAD_PAIR_ZERO);
					sl2reg.dump_Conflict_info(THREAD_PAIR_TWO);
					sl2reg.set_SIMD_Control_LUT(THREAD_ID_MAIN_1, THREAD_PAIR_ZERO);
				}
				else
				{
					// Complete minor thread
					sl2reg.dump_Conflict_info(THREAD_PAIR_TWO);
					sl2reg.set_SIMD_Control_LUT(THREAD_ID_MAIN_1, THREAD_PAIR_ZERO);
				}

				break;
			case THREAD_ID_SLAVE_0:
				_thStack[thid]--;
				machine().disablePC(thid);

				// Debug information
				#ifdef _DISPLAY_THREAD_INFO_
				AppFatal((_thStack[thid]==0), ("Can not have two thread-2 in one application "));
				printf("Joint [Th-2]: Stack[%d], PC[%08x]\t", _thStack[thid], (ADDR)machine().getPC(2));
				printf("Status for Thread-2 after joint is [%d]\n", machine().getPCEnable(2)); 		fflush(0);
				#endif

				AppFatal((_thStack[thid]==0), ("SL2ThreadCtrl: invalid thread stack count (%d).", _thStack[thid]));

				// Check if M0 is blocked to wait htis joint
				if((machine().getPCEnable(THREAD_ID_MAIN_0)==FALSE) & (_thStack[THREAD_ID_MAIN_0]== 1)) {
					machine().enablePC(THREAD_ID_MAIN_0);
				}
				
				// SIMD Checker: may be already write the information in thread-0 joint, but doee not matter!!
				sl2reg.dump_Conflict_info(THREAD_PAIR_ONE);

				break;
			case THREAD_ID_SLAVE_1:
				_thStack[thid]--;
				machine().disablePC(thid);
				
				// Debug information
				#ifdef _DISPLAY_THREAD_INFO_
				AppFatal((_thStack[thid]==0), ("Can not have two thread-3 in one application "));
				printf("Joint [Th-3]: Stack[%d], PC[%08x]\t", _thStack[thid], (ADDR)machine().getPC(3));
				printf("Status for Thread-3 after joint is [%d]\n", machine().getPCEnable(3));		fflush(0);
				#endif

				
				AppFatal((_thStack[thid]==0), ("SL2ThreadCtrl: invalid thread stack count (%d).", _thStack[thid]));

				// Check if M1 is blocked to wait htis joint
				if((machine().getPCEnable(THREAD_ID_MAIN_1)==FALSE) & (_thStack[THREAD_ID_MAIN_1]== 1)) {
					machine().enablePC(THREAD_ID_MAIN_1);
				}
				
				// SIMD Checker: may be already write the information in thread-1 joint, but doee not matter!!
				sl2reg.dump_Conflict_info(THREAD_PAIR_TWO);
				
				break;
			default:
				break;
		}

		// Process ret-address
		if(isEnd()==TRUE ) {
			if(thid==THREAD_ID_MAIN_0) {
				retAddr = jointAddr();
			}
			else {
				// Must be thread-1
				machine().setPC(THREAD_ID_MAIN_0, jointAddr());
				machine().enablePC(THREAD_ID_MAIN_0);
			}	
		}

		return retAddr;
	}
	else {
		machine().disablePC(thid);
		_thStack[thid]--;
		AppFatal((_thStack[thid]>=0), ("SL2ThreadCtrl: invalid thread stack count (%d).", _thStack[thid]));
		if(_thStack[thid]==0){
			if(thid==THREAD_ID_MAIN_0) {
				jointAddr(nextPC);
			}
			machine().setPC(thid, 0);	
		}	
		else
		{
			// Why?
			//AppFatal(((_thStack[thid]>0)&& thid==THREAD_ID_SLAVE_0), ("SL2ThreadCtrl: Thread-2 can not have more threads in it."));
			//AppFatal(((_thStack[thid]>0)&& thid==THREAD_ID_SLAVE_1), ("SL2ThreadCtrl:  Thread-3 can not have more threads in it."));
		}
		
		if(isEnd()==FALSE) {
			UINT index = 0;

			// Add by WWD in 20070423: we need consider minor thread in thread-1
			// We will switch thread through the following stements, so, we need save PC here for the thread [thid]
			machine().setPC(thid, nextPC);
			
			for(UINT i = 0; i<MAX_THREAD; i++) {
				index = (thid + i)%MAX_THREAD;
				if(index!=thid&&_thStack[index]>0) {
					status().switchThread(index);
					break;
				}
			}			
		}
		else {
			machine().setPC(THREAD_ID_MAIN_0, jointAddr());	
			status().switchThread(THREAD_ID_MAIN_0);
			machine().enablePC(THREAD_ID_MAIN_0);
		}
		return nextPC;
	}
}

// When fork one thread, _thStack[thid] will be add "1" and its paired thread _thStack[paired_thid] will be add "1" also.
void SL2ThreadCtrl::fork(UINT thid, ADDR addr, BOOL major) {
	SL2Register& sl2reg = machine().getExec(thid)->reg();
	UINT nextThid = MAX_THREAD;
	_thStack[thid]++;
	_isThreadMode = TRUE;

	sl2reg.checkSIMDRegister(sl2reg.checkSIMDRegister() & ((machine().isMultiThreadMode())?1:0));

	switch(thid) {
		case THREAD_ID_MAIN_0:
			if(major==TRUE) {
				ADDR offset = machine().mmu().getForkThreadSP();
				ADDR curSP = machine().getExec(THREAD_ID_MAIN_0)->reg().getSP();
				copyReg0_1();	
				machine().getExec(THREAD_ID_MAIN_1)->reg().setSP(curSP+offset);
				nextThid = THREAD_ID_MAIN_1;

				AppFatal((_thStack[0]<2), ("SL2ThreadCtrl: Thread-0 can not create two major thread."));

				//sl2 SIMD checker
				sl2reg.clear_SIMD_Control(0); //means thread pair 0
				sl2reg.set_SIMD_Control_LUT(THREAD_ID_MAIN_0, THREAD_PAIR_ZERO);
				sl2reg.set_SIMD_Control_LUT(THREAD_ID_MAIN_1, THREAD_PAIR_ZERO);

			}
			else {
				nextThid = THREAD_ID_SLAVE_0;

				AppFatal((_thStack[0]<3), ("SL2ThreadCtrl: Thread-0 can not create more than one minor thread."));
				
				//sl2 SIMD checker
				sl2reg.clear_SIMD_Control(1) ;//means thread pair 1
				sl2reg.set_SIMD_Control_LUT(THREAD_ID_MAIN_0, THREAD_PAIR_ONE);
			}

			
			break;
		case THREAD_ID_MAIN_1:
			nextThid = THREAD_ID_SLAVE_1;
			
			AppFatal((major!=TRUE), ("SL2ThreadCtrl: thread 1 cannot create major thread."));
			AppFatal((_thStack[1]<=2), ("SL2ThreadCtrl: Thread-1 can not create more than one minor thread."));

			//sl2 SIMD checker
			sl2reg.clear_SIMD_Control(2) ;//means thread pair 0
			sl2reg.set_SIMD_Control_LUT(THREAD_ID_MAIN_1, THREAD_PAIR_TWO);
			
			break;
		case THREAD_ID_SLAVE_0:
		case THREAD_ID_SLAVE_1:
			AppFatal((0), ("SL2ThreadCtrl: the specified thread id (%d) cannot create extra thread.", thid));
			break;
		default:
			AppFatal((0), ("SL2ThreadCtrl: undefined thread id (%d).", thid));
			break;
	}
	AppFatal((nextThid<MAX_THREAD), ("SL2ThreadCtrl: undefined thread id (%d).", nextThid));
	_thStack[nextThid]++;
	machine().setPC(nextThid, addr);
	machine().enablePC(nextThid);

	// Debug information
	#ifdef _DISPLAY_THREAD_INFO_
	{
	if(major == TRUE)
	    printf("FORK  [Major] from [%d]: Statck for [%d] is <%d>, Statck for [%d] is <%d> - PC[%08x]\n", thid, thid,  _thStack[thid], nextThid,  _thStack[nextThid], machine().getPC(thid));
	else
	    printf("FORK  [Minor] from [%d]: Statck for [%d] is <%d>, Statck for [%d] is <%d> - PC[%08x]\n", thid, thid,  _thStack[thid], nextThid,  _thStack[nextThid], machine().getPC(thid));
	fflush(0);
	}
	#endif
}

void SL2ThreadCtrl::thctrl(UINT cur_thid, UINT tar_thid, UINT op_mode) {
	switch(op_mode) {
		case 0:		// Acquire Lock
			for(UINT i = 0; i<MAX_THREAD; i++) {
				if(i!=cur_thid) {
					_thStatusBackup[i] = machine().getPCEnable(i);
					machine().disablePC(i);
				}
			}

			#ifdef _DISPLAY_THREAD_INFO_
			printf("FSIM : Acquire lock in thread [%d], and deactive all others, [0: %d], [1: %d], [2: %d], [3: %d]\n", cur_thid, machine().getPCEnable(0), machine().getPCEnable(1), machine().getPCEnable(2), machine().getPCEnable(3));
			#endif
			break;
		case 1:	// Release Lock
			for(UINT i = 0; i<MAX_THREAD; i++) {
				if(i!=cur_thid) {
					_thStatusBackup[i]==TRUE?machine().enablePC(i):machine().disablePC(i);
				}
			}
			#ifdef _DISPLAY_THREAD_INFO_
			printf("FSIM : Release lock in thread [%d], and Active all others accordingly, [0: %d], [1: %d], [2: %d], [3: %d]\n", cur_thid,  machine().getPCEnable(0), machine().getPCEnable(1), machine().getPCEnable(2), machine().getPCEnable(3));
			#endif
			break;		
		case 2:	// Release Lock and deactive itself
			for(UINT i = 0; i<MAX_THREAD; i++) {
				if(i!=cur_thid) {
					_thStatusBackup[i]==TRUE?machine().enablePC(i):machine().disablePC(i);
				}
			}
			machine().disablePC(cur_thid);	// Deactive itself	

			#ifdef _DISPLAY_THREAD_INFO_
			printf("FSIM : Deactive isself and release LOCK in thread [%d], [0: %d], [1: %d], [2: %d], [3: %d]\n", cur_thid,  machine().getPCEnable(0), machine().getPCEnable(1), machine().getPCEnable(2), machine().getPCEnable(3));
			#endif
			
			break;	
		case 3:	// Active another thread and release Lock
			for(UINT i = 0; i<MAX_THREAD; i++) {
				if(i != cur_thid) {
					if(i!=tar_thid) {
						_thStatusBackup[i]==TRUE?machine().enablePC(i):machine().disablePC(i);
					}
					else {
						machine().enablePC(i);
					}
				}
			}

			#ifdef _DISPLAY_THREAD_INFO_
			printf("FSIM : Active other thread [%d] in thread [%d],  [0: %d], [1: %d], [2: %d], [3: %d]\n", tar_thid, cur_thid,  machine().getPCEnable(0), machine().getPCEnable(1), machine().getPCEnable(2), machine().getPCEnable(3));
			#endif
			break;	
			// TODO: Add codes, log for PSIM
		case 4:
			break;	
		case 5:
			break;
		case 6:
			break;				
		default:
			break;	
	}
}

