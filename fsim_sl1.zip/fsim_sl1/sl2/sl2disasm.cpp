#include "sl2mmu.h"
#include "sl2reg.h"
#include "sl2instr.h"
#include "sl2disasm.h"
#include "sl2defs.h"

#define GPR_STR "scalar"

STRING notImplemented = "Disassembly not implemented\n";

SL2Disasm::SL2Disasm(SL2MMU& mmu, SL2Register& reg, UINT th_id) 
	: CoreDisasm<SL2MMU, SL2Register, SL2Instr>(mmu, reg, th_id) {
}
#if 0
STRING SL2Disasm::disasmC2_tmp_mul (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rs1=%d, rs2=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rs1(),
		instr->rs2(),
		meta
	);
	return RET_STRBUF(pc);
}
#endif

STRING SL2Disasm::disasmC2_psum16_private_old (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, op_mode=%d, shft=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->op_mode(),
		instr->shft(),
		meta
	);
	return RET_STRBUF(pc);	
}

STRING SL2Disasm::disasmC2_psum16_private (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, op_mode=%d, shft=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd(),
		instr->rs1_simd(),
		instr->op_mode(),
		instr->shft(),
		meta
	);
	return RET_STRBUF(pc);	
}

STRING SL2Disasm::disasmC2_psum4t1_private(ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, bk0=%d, bk1=%d, bk2=%d, imm2=%d, lshft_amnt=%d, rshft_amnt=%d, wen=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->bk0(),
		instr->bk1(),
		instr->bk2(),
		instr->imm2(),
		instr->lshft_amnt(),
		instr->rshft_amnt(),
		instr->wen(),
		meta
	);
	return RET_STRBUF(pc);	
}

STRING SL2Disasm::disasmC2_psum4t2_private (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, bk0=%d, bk1=%d, bk2=%d, lshft_amnt=%d, rshft_amnt=%d, wen=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->bk0(),
		instr->bk1(),
		instr->bk2(),
		instr->lshft_amnt(),
		instr->rshft_amnt(),
		instr->wen(),
		meta
	);
	return RET_STRBUF(pc);	
}

STRING SL2Disasm::disasmC2_padds_private (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, bk0=%d, bk1=%d, carry=%d, shft_amnt=%d, wen=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->bk0(),
		instr->bk1(),
		instr->carry(),
		instr->shft_amnt(),
		instr->wen(),
		meta
	);
	return RET_STRBUF(pc);	
}

STRING SL2Disasm::disasmC2_pmov_private (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, bk0=%d, wen=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->bk0(),
		instr->wen(),
		meta
	);
	return RET_STRBUF(pc);	
}

STRING SL2Disasm::disasmC2_psadds_private (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, rs2=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd(),
		instr->rs1(),
		instr->rs2(),
		meta
	);
	return RET_STRBUF(pc);	
}

STRING SL2Disasm::disasmC2_pmedc_private (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, rs2=%d, rs3=%d, op_mode=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd(),
		instr->rs1(),
		instr->rs2(),
		instr->rs3(),
		instr->op_mode(),
		meta
	);
	return RET_STRBUF(pc);	
}

STRING SL2Disasm::disasmC2_pspadd_private (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, rs2=%d, size=%d, sl_indx=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->rs2_simd(),
		instr->size(),
		instr->sl_indx(),
		meta
	);
	return RET_STRBUF(pc);	
}

STRING SL2Disasm::disasmC2_pxadd_private (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, rs2=%d, sl_index=%d, <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->rs2_simd(),
		instr->sl_indx(),
		meta
	);
	return RET_STRBUF(pc);	
}

STRING SL2Disasm::disasmC2_pxsub_private (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, rs2=%d, sl_index=%d, <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->rs2_simd(),
		instr->sl_indx(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_prret (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd(),
		instr->rs1(),
		meta
	);
	return RET_STRBUF(pc);	
}

//Instruction disassembler function
// BR
STRING SL2Disasm::disasmC2_br (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s offset=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->offset(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_fork (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s mjr_fk=%d, offset=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->mjr_fk(),
		instr->offset(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_joint (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		meta
	);
	return RET_STRBUF(pc);
}

//THCTRL
STRING SL2Disasm::disasmC2_thctrl (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s th=%d, op_mode=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->thread(),
		instr->op_mode(),
		meta
	);
	return RET_STRBUF(pc);	
}

// LS
STRING SL2Disasm::disasmC2_ld (ADDR pc, SL2Instr* instr, UINT meta) {
	UINT rd = 0xff;
	UINT rs2 = 0xff;
	if(instr->op_mode()==0) {
		rd = instr->rd1_simd();
		rs2 = instr->rs2();
	}
	else if (instr->op_mode()==3) {
		rd = instr->cd();
	}
	else {
		rd  = instr->rd();
		rs2 = instr->rs2();
	}
	if(instr->imm1()==0) {
	    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs2=%d, imm1=%d, op_mode=%d, scalar=%d, sw_mv=%d, swap=%d, sign_ext=%d, size=%d, macro=%d <meta=%x> \n",
	        pc,
	        instr->rawbits(),
			instr->mn(),
			rd,
			rs2,
			instr->imm1(),
			instr->op_mode(),
			instr->scalar(),
			instr->sw_mv(),
			instr->swap(),
			instr->sign_ext(),
			instr->size(),
			instr->macro(),
			meta
			);
	}
	else {
	    sprintf(strbuf(), "0x%08x: 0x%08x %s %s=%d, imm1=%d, op_mode=%d, sign_ext=%d, size=%d, macro=%d, offset=%d <meta=%x>\n",
	        pc,
	        instr->rawbits(),
			instr->mn(),
			instr->op_mode()==3?"cd":"rd",
			rd,
			instr->imm1(),
			instr->op_mode(),
			instr->sign_ext(),
			instr->size(),
			instr->macro(),
			instr->offset(),
			meta
		);		
	}
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_mvgc (ADDR pc, SL2Instr* instr, UINT meta) {
	if(instr->dir()==1) {
	    sprintf(strbuf(), "0x%08x: 0x%08x %s cd1=%d, rs1=%d, dir=%d <meta=%x>\n",
	        pc,
	        instr->rawbits(),
			instr->mn(),
			instr->c2cd(),
			instr->rs1(),
			instr->dir(),
			meta
		);
	}
	else {
	    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, cs1=%d, dir=%d <meta=%x>\n",
	        pc,
	        instr->rawbits(),
			instr->mn(),
			instr->rd(),
			instr->c2cs1(),
			instr->dir(),
			meta
		);		
	}
	return RET_STRBUF(pc);
}


STRING SL2Disasm::disasmC2_mvgr (ADDR pc, SL2Instr* instr, UINT meta) {
	if(instr->dir()==1) {
	    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, bank/rs2=%d, op_mode=%d, dir=%d, scalar=%d, sign_ext=%d, size=%d, bc_dir=%d <meta=%x>\n",
	        pc,
	        instr->rawbits(),
			instr->mn(),
			instr->scalar()==1?instr->rd():instr->rd1_simd(),
			instr->rs1(),
			instr->op_mode()>0?instr->bank():0xff,
			instr->op_mode(),
			instr->dir(),
			instr->scalar(),
			instr->sign_ext(),
			instr->size(),
			instr->bc_dir(),
			meta
		);
	}
	else {
	    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, bank/rs2=%d, op_mode=%d, dir=%d, scalar=%d, sign_ext=%d, size=%d, bc_dir=%d <meta=%x>\n",
	        pc,
	        instr->rawbits(),
			instr->mn(),
			instr->rd(),
			instr->scalar()==1?instr->rs1():instr->rs1_simd(),
			instr->op_mode()==0?instr->bank():instr->rs2(),
			instr->op_mode(),
			instr->dir(),
			instr->scalar(),
			instr->sign_ext(),
			instr->size(),
			instr->bc_dir(),
			meta
		);	
	}
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_st (ADDR pc, SL2Instr* instr, UINT meta) {
	UINT rs2 = 0xff;
	UINT rs1 = 0xff;
	if(instr->op_mode()==0) {
		rs2 = instr->rs2();
		rs1 = instr->rs1_simd();
	}
	else if (instr->op_mode()==3) {
		rs1 = instr->cs1();
	}
	else {
		rs2 = instr->rs2();
		rs1 = instr->rs1();
	}
	if(instr->imm1()==0) {
	    sprintf(strbuf(), "0x%08x: 0x%08x %s rs1=%d, rs2=%d, imm1=%d, op_mode=%d, swap=%d, size=%d, macro=%d <meta=%x>\n",
	        pc,
	        instr->rawbits(),
			instr->mn(),
			rs1,
			rs2,
			instr->imm1(),
			instr->op_mode(),
			instr->swap(),
			instr->size(),
			instr->macro(),
			meta
		);
	}
	else {
	    sprintf(strbuf(), "0x%08x: 0x%08x %s %s=%d, imm1=%d, op_mode=%d, size=%d, macro=%d, offset=%d <meta=%x>\n",
	        pc,
	        instr->rawbits(),
			instr->mn(),
			instr->op_mode()==3?"cs1":"rs1",
			rs1,
			instr->imm1(),
			instr->op_mode(),
			instr->size(),
			instr->op_mode()==1?0:instr->macro(),
			instr->offset(),
			meta
		);		
	}
	return RET_STRBUF(pc);
}

//Macro
STRING SL2Disasm::disasmC2_intra (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, op_mode=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->op_mode(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_mads (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, rs2=%d, rs3=%d, imm1=%d, imm2=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd(),
		instr->rs1(),
		instr->rs2(),
		instr->rs3(),
		instr->imm1(),
		instr->imm2(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_mvsel (ADDR pc, SL2Instr* instr, UINT meta) {
	UINT rd = 0xff;
	UINT rs1 = 0xff;
	UINT rs2 = 0xff;
	switch(instr->op_mode()) {
		case 1:
		case 6:
           	sprintf(strbuf(), "0x%08x: 0x%08x %s, op_mode=%d <meta=%x>\n",
           	pc,
	        instr->rawbits(),
			instr->mn(),
			instr->op_mode(),
			meta
			);			
			break;
		case 0:		
		case 2:		
		case 7:
			rs1 = instr->rs1();
			rs2 = instr->rs2();
	        sprintf(strbuf(), "0x%08x: 0x%08x %s, rs1=%d, rs2=%d, op_mode=%d <meta=%x>\n",
           	pc,
	        instr->rawbits(),
			instr->mn(),
			rs1,
			rs2,
			instr->op_mode(),
			meta
			);		
			break;	
		case 3:	
		case 4:
		case 5:
			rd = instr->rd();
           	sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, op_mode=%d <meta=%x>\n",
           	pc,
	        instr->rawbits(),
			instr->mn(),
			rd,
			instr->op_mode(),
			meta
			);			
			break;		
		default:
			break;		
			//error
	}	

	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_satd_old (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, rs2=%d, rs3=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->rs2_simd(),
		instr->rs3(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_satd (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, rs2=%d, rd2=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->rs2_simd(),
		instr->rd(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_smads (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, rs2=%d, rs3=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd(),
		instr->rs1(),
		instr->rs2(),
		instr->rs3(),
		meta
	);
	return RET_STRBUF(pc);
}


STRING SL2Disasm::disasmC2_vsad_old (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rd2=%d, rs1=%d, rs2=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rd(),
		instr->rs1_simd(),
		instr->rs2_simd(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_vsad (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rd2=%d, rs1=%d, rs2=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rd(),
		instr->rs1_simd(),
		instr->rs2_simd(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_vspel (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, cl_indx=%d, size=%d, op_mode=%d, sl_indx=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->cl_indx(),
		instr->size(),
		instr->op_mode(),
		instr->sl_indx(),
		meta
	);
	return RET_STRBUF(pc);
}
STRING SL2Disasm::disasmC2_vspmac (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, size=%d, cl_indx=%d, sl_indx=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->size(),
		instr->cl_indx(),
		instr->sl_indx(),
		meta
	);
	return RET_STRBUF(pc);	
}

// Vmult
STRING SL2Disasm::disasmC2_mmul (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1 = %d, rs1=%d, rs2=%d, size=%d, op_mode=%d, sl_indx=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->rs2_simd(),
		instr->size(),
		instr->op_mode(),
		instr->sl_indx(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_vcopy (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs2=%d, size=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs2_simd(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_vmov (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs2=%d, rev_pat=%d, mov_pat=%d, sl_indx=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs2_simd(),
		instr->rev_pat(),
		instr->mov_pat(),
		instr->sl_indx(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_vmul (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, rs2=%d, size=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->rs2_simd(),
		instr->size(),
		meta
	);
	return RET_STRBUF(pc);
}


//Vadd
STRING SL2Disasm::disasmC2_lczero (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, dir=%d, zero=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->dir(),
		instr->zero(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_vadds (ADDR pc, SL2Instr* instr, UINT meta) {
	sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, rs2=%d, size=%d, in_pair=%d, carry=%d, shft_mode=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->rs2_simd(),
		instr->size(),
		instr->in_pair(),
		instr->carry(),
		instr->shft_mode(),
		meta
	);
	return RET_STRBUF(pc);
}


STRING SL2Disasm::disasmC2_vclg (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, rs2=%d, size=%d, in_pair=%d, op_mode=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		(instr->in_pair()==0&&instr->op_mode()<0xc)?instr->rs2_simd():0xff,
		instr->size(),
		instr->in_pair(),
		instr->op_mode(),
		meta
	);
	return RET_STRBUF(pc);
}


STRING SL2Disasm::disasmC2_vclp (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, rs2=%d, in_pair=%d, op_mode=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->rs2_simd(),
		instr->in_pair(),
		instr->op_mode(),
		meta
	);
	return RET_STRBUF(pc);
}


STRING SL2Disasm::disasmC2_vcmov (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, rs2=%d, size=%d, cmp_bit=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->rs2_simd(),
		instr->size(),
		instr->cmp_bit(),
		meta
	);
	return RET_STRBUF(pc);
}


STRING SL2Disasm::disasmC2_vcmpr (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, rs2=%d, size=%d, gt=%d, lt=%d, eq=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->rs2_simd(),
		instr->size(),
		instr->gt(),
		instr->lt(),
		instr->eq(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_vneg (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, rs2=%d, size=%d, in_pair=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->rs2_simd(),
		instr->size(),
		instr->in_pair(),
		meta
	);
	return RET_STRBUF(pc);
}


STRING SL2Disasm::disasmC2_vrnd (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, size=%d, op_mode=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->size(),
		instr->op_mode(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_vshft (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, size=%d, dir=%d, in_pair=%d, shft_amnt=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->size(),
		instr->dir(),
		instr->in_pair(),
		instr->shft_amnt(),
		meta
	);
	return RET_STRBUF(pc);
}


STRING SL2Disasm::disasmC2_vspas (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, imm5=%d, shft_amnt=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->imm5(),
		instr->shft_amnt(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_vsubs (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, rs2=%d, dir=%d, in_pair=%d, size=%d, shf_mode=%d, op_mode=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd1_simd(),
		instr->rs1_simd(),
		instr->rs2_simd(),
		instr->dir(),
		instr->in_pair(),
		instr->size(),
		instr->shft_mode(),
		instr->op_mode(),
		meta
	);
	return RET_STRBUF(pc);
}


// Mult
STRING SL2Disasm::disasmC2_muls (ADDR pc, SL2Instr* instr, UINT meta) {
	UINT rd = 0xff;
	UINT rs1 = 0xff;
	UINT rs2 = 0xff;
	//if(instr->gpr()==1) 
	{
		rs2 = instr->rs2();
		rs1 = instr->rs1();
		rd = instr->rd();		
	}/*
	else {
		rs2 = instr->rs2_simd();
		rs1 = instr->rs1_simd();
		rd = instr->rd1_simd();			
	}*/
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, rs2=%d, dir=%d, opd_shft=%d, shft_amnt=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		rd,
		rs1,
		rs2,
		instr->dir(),
		instr->opd_shft(),
		instr->rs3(),
		meta
	);
	return RET_STRBUF(pc);

}


// Add
STRING SL2Disasm::disasmC2_adds (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, rs2=%d, size=%d, opd_shft=%d, imm1=%d, gpr=%d, carry=%d, shft_amnt=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->gpr()==0?instr->rd1_simd():instr->rd(),
		instr->gpr()==0?instr->rs1_simd():instr->rs1(),
		instr->gpr()==0?instr->rs2_simd():instr->rs2(),
		instr->size(),
		instr->opd_shft(),
		instr->imm1(),
		instr->gpr(),
		instr->carry(),
		instr->shft_amnt(),
		meta
	);
	return RET_STRBUF(pc);
}


STRING SL2Disasm::disasmC2_bcst (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, shft=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd(),
		instr->rs1(),
		instr->shft(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_chkrng (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, hi_indx=%d, lo_indx=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd(),
		instr->rs1(),
		instr->hi_indx(),
		instr->lo_indx(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_cmov (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, rs2=%d, rs3=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd(),
		instr->rs1(),
		instr->rs2(),
		instr->rs3(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_clp (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, rs2=%d, rs3=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd(),
		instr->rs1(),
		instr->rs2(),
		instr->rs3(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_med (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, rs2=%d, rs3=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd(),
		instr->rs1(),
		instr->rs2(),
		instr->rs3(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_scond (ADDR pc, SL2Instr* instr, UINT meta) {
	if(instr->gpr())	
	    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, rs2=%d, imm1=%d, gpr=%d, wr_back=%d, gt=%d, lt=%d, eq=%d <meta=%x>\n",
	        pc,
	        instr->rawbits(),
			instr->mn(),
			(instr->wr_back()==1)?instr->rd():0xff,
			instr->rs1(),
			instr->rs2(),
			instr->imm1(),
			instr->gpr(),
			instr->wr_back(),
			instr->gt(),
			instr->lt(),
			instr->eq(),
			meta
		);
	else
	    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, rs2=%d, size=%d, imm1=%d, gpr=%d, wr_back=%d, gt=%d, lt=%d, eq=%d <meta=%x>\n",
	        pc,
	        instr->rawbits(),
			instr->mn(),
			(instr->wr_back()==1)?instr->rd():0xff,
			instr->rs1_simd(),
			instr->rs2_simd(),
			instr->size(),
			instr->imm1(),
			instr->gpr(),
			instr->wr_back(),
			instr->gt(),
			instr->lt(),
			instr->eq(),
			meta
		);
		
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_subs (ADDR pc, SL2Instr* instr, UINT meta) {
	UINT rd = 0xff;
	UINT rs1 = 0xff;
	UINT rs2 = 0xff;
	if(instr->gpr()==0) {
		rs1 = instr->rs1_simd();
		rs2 = instr->rs2_simd();
		rd = instr->rd1_simd();
	}
	else {
		rs1 = instr->rs1();
		rs2 = instr->rs2();
		rd = instr->rd();		
	}
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, rs2=%d, size=%d, imm1=%d, gpr=%d, abs=%d, shft_amnt=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		rd,
		rs1,
		rs2,
		instr->size(),
		instr->imm1(),
		instr->gpr(),
		instr->abs(),
		instr->shft_amnt(),
		meta
	);
	return RET_STRBUF(pc);
}


// BIT
STRING SL2Disasm::disasmC2_bdep (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, rs2=%d, lsb=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd(),
		instr->rs1(),
		instr->rs2(),
		instr->lsb(),
		meta
	);
	return RET_STRBUF(pc);
}


STRING SL2Disasm::disasmC2_bop (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, rs2=%d, imm1=%d, dir=%d, op_mode=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd(),
		instr->rs1(),
		instr->rs2(),
		instr->imm1(),
		instr->dir(),
		instr->op_mode(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_bxtr (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, rs2=%d, rs3=%d, lsb=%d, sign_ext=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd(),
		instr->rs1(),
		instr->rs2(),
		instr->rs3(),
		instr->lsb(),
		instr->sign_ext(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_clzob (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, rs2=%d, imm=%d, op_mode=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd(),
		instr->rs1(),
		instr->rs2(),
		instr->imm1(),
		instr->op_mode(),
		meta
	);
	return RET_STRBUF(pc);
}

// SUM4
STRING SL2Disasm::disasmC2_gsum4s  (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd=%d, rs1=%d, rs2=%d, shft_amnt=%d, imm5=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		instr->rd(),
		instr->rs1(),
		instr->rs2(),
		instr->shft_amnt(),
		instr->imm5(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_sum4 (ADDR pc, SL2Instr* instr, UINT meta) {
	UINT rd = 0xff;
	UINT rs1 = 0xff;
	UINT rs2 = 0xff;
	UINT rs3 = 0xff;
	switch(instr->op_mode()) {
		case 0:
			rs1 = instr->rs1_simd();
			rs2 = instr->bank();
			break;
		case 1:
		case 2:
			rd = instr->rd();
			rs1 = instr->rs1_simd();
			rs2 = instr->bank();
			break;	
		case 3:	
			rd = instr->rd1_simd();
			rs1 = instr->rs1_simd();
			rs2 = instr->rs2_simd();
			rs3 = instr->rs3_simd();
			break;		
		case 4:	
			rd = instr->rd();
			rs1 = instr->rs1();
			rs2 = instr->rs2();
			rs3 = instr->rs3();
			break;		
		default:
			break;		
			//error
	}	
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, rs2/bank=%d, rs3=%d, op_mode=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		rd,
		rs1,
		rs2,
		rs3,
		instr->op_mode(),
		meta
	);
	return RET_STRBUF(pc);
}

STRING SL2Disasm::disasmC2_mov (ADDR pc, SL2Instr* instr, UINT meta) {
	UINT rd = 0xff;
	UINT rs1 = 0xff;
	switch(instr->op_mode()) {
		case 0:
			rs1 = instr->rs1();
			rd = instr->rd();
			break;			
		case 1:
			rs1 = instr->rs1_simd();
			rd = instr->rd1_simd();
			break;
		case 2:
			rs1 = instr->rs1_simd();
			break;		
		case 3:
			rs1 = instr->rs1_simd();
			break;	
		case 4:
			rs1 = instr->rs1_simd();
			rd  = instr->rd1_simd();
			break;
		case 5:
			rs1 = instr->rs1_simd();
			rd  = instr->rd1_simd();
			break;
			
		default:
			break;		
			//error
	}	
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, srcbank=%d, dstbank=%d, op_mode=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		rd,
		rs1,
		instr->bank(),
		instr->bank(),
		instr->op_mode(),
		meta
	);
	return RET_STRBUF(pc);
}


//VLCS
STRING SL2Disasm::disasmC2_vlcs (ADDR pc, SL2Instr* instr, UINT meta) {
    sprintf(strbuf(), "0x%08x: 0x%08x %s rd1=%d, rs1=%d, op_mode=%d <meta=%x>\n",
        pc,
        instr->rawbits(),
		instr->mn(),
		((instr->op_mode()&1)==0)?instr->rd1_simd():instr->rd(),
		((instr->op_mode()&1)==0)?instr->rs1_simd():0xff,
		instr->op_mode(),
		meta
	);
	return RET_STRBUF(pc);
}


