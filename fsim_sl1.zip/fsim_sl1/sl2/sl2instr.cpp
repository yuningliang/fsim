#include "sl2instr.h"
#include "sl2instrid.h"

void SL2Instr::clearMacro() {
	SL2InstrListIter iter = _macroList.begin();
	SL2InstrListIter iter_end = _macroList.end();
	while(iter!=iter_end) {
		delete *iter;
		iter++;
	}
}

pair<INT, INT> SL2Instr::gprRegPort() {
	INT readReg = 0;
	INT writeReg = 0;
	pair<INT, INT> result;
	if((_reg0.status&ERS_WRITE)>0) {
		writeReg++;
	}
	if((_reg1.status&ERS_WRITE)>0) {
		writeReg++;
	}
	if((_reg2.status&ERS_WRITE)>0) {
		writeReg++;
	}
	if((_reg3.status&ERS_WRITE)>0) {
		writeReg++;
	}	
	
	if((_reg0.status&ERS_READ)>0) {
		readReg++;
	}
	if((_reg1.status&ERS_READ)>0) {
		readReg++;
	}
	if((_reg2.status&ERS_READ)>0) {
		readReg++;
	}
	if((_reg3.status&ERS_READ)>0) {
		readReg++;
						
	}	
	result.first = 	readReg;
	result.second = writeReg;	
	return result;
}

pair<INT, INT> SL2Instr::simdRegPort() {
	INT readReg = 0;
	INT writeReg = 0;
	pair<INT, INT> result;	
	if((_simd0a.status&ERS_WRITE)>0) {
		writeReg++;
		if((_simd0b.status&ERS_WRITE)>0) {
			writeReg++;
		}
	}	
	if((_simd1a.status&ERS_WRITE)>0) {
		writeReg++;
		if((_simd1b.status&ERS_WRITE)>0) {
			writeReg++;
		}		
	}	
	if((_simd2a.status&ERS_WRITE)>0) {
		writeReg++;
		if((_simd2b.status&ERS_WRITE)>0) {
			writeReg++;
		}		
	}			
	if((_simd0a.status&ERS_READ)>0) {
		readReg++;	
		if((_simd0b.status&ERS_READ)>0) {
			readReg++;
		}				
	}	
	if((_simd1a.status&ERS_READ)>0) {
		readReg++;	
		if((_simd1b.status&ERS_READ)>0) {
			readReg++;
		}		
	}	
	if((_simd2a.status&ERS_READ)>0) {
		readReg++;	
		if((_simd1b.status&ERS_READ)>0) {
			readReg++;
		}			
	}
	result.first = 	readReg;
	result.second = writeReg;	
	return result;
}

//construct the reg list for psim
void SL2Instr::getRegList(RegList* destList, RegList* srcList) {
	destList->clear();
	srcList->clear();	
	//dest list
	if((_reg0.status&ERS_WRITE)>0) {
		destList->push_back(_reg0.index+_reg0.regbase);
	}
	if((_reg1.status&ERS_WRITE)>0) {
		destList->push_back(_reg1.index+_reg1.regbase);
	}
	if((_reg2.status&ERS_WRITE)>0) {
		destList->push_back(_reg2.index+_reg2.regbase);
	}
	if((_reg3.status&ERS_WRITE)>0) {
		destList->push_back(_reg3.index+_reg3.regbase);
	}	
	if((_ctrl1.status&ERS_WRITE)>0) {
		destList->push_back(_ctrl1.index+_ctrl1.regbase);
	}
	if((_ctrl2.status&ERS_WRITE)>0) {
		destList->push_back(_ctrl2.index+_ctrl2.regbase);
	}		
	if((_ctrl3.status&ERS_WRITE)>0) {
		destList->push_back(_ctrl3.index+_ctrl3.regbase);
	}	
	if((_simd0a.status&ERS_WRITE)>0) {
		destList->push_back(_simd0a.index+_simd0a.regbase);
		if((_simd0b.status&ERS_WRITE)>0) {
			destList->push_back(_simd0b.index+_simd0b.regbase);
		}		
	}	
	if((_simd1a.status&ERS_WRITE)>0) {
		destList->push_back(_simd1a.index+_simd1a.regbase);
		if((_simd1b.status&ERS_WRITE)>0) {
			destList->push_back(_simd1b.index+_simd1b.regbase);
		}			
	}	
	if((_simd2a.status&ERS_WRITE)>0) {
		destList->push_back(_simd2a.index+_simd2a.regbase);
		if((_simd2b.status&ERS_WRITE)>0) {
			destList->push_back(_simd2b.index+_simd2b.regbase);
		}		
	}					
	if((_specreg1.status&ERS_WRITE)>0) {
		destList->push_back(_specreg1.index+_specreg1.regbase);
	}
	if((_specreg2.status&ERS_WRITE)>0) {
		destList->push_back(_specreg2.index+_specreg2.regbase);
	}
	if((_acc.status&ERS_WRITE)>0) {
		destList->push_back(_acc.index+_acc.regbase);
	}
				
	//src list
	if((_reg0.status&ERS_READ)>0) {
		srcList->push_back(_reg0.index+_reg0.regbase);
	}
	if((_reg1.status&ERS_READ)>0) {
		srcList->push_back(_reg1.index+_reg1.regbase);
	}
	if((_reg2.status&ERS_READ)>0) {
		srcList->push_back(_reg2.index+_reg2.regbase);
			
	}
	if((_reg3.status&ERS_READ)>0) {
		srcList->push_back(_reg3.index+_reg3.regbase);
		
	}	
	if((_ctrl1.status&ERS_READ)>0) {
		srcList->push_back(_ctrl1.index+_ctrl1.regbase);
	}
	if((_ctrl2.status&ERS_READ)>0) {
		srcList->push_back(_ctrl2.index+_ctrl2.regbase);
	}	
	if((_ctrl3.status&ERS_READ)>0) {
		srcList->push_back(_ctrl3.index+_ctrl3.regbase);
	}	
	if((_simd0a.status&ERS_READ)>0) {
		srcList->push_back(_simd0a.index+_simd0a.regbase);
		if((_simd0b.status&ERS_READ)>0) {
			srcList->push_back(_simd0b.index+_simd0b.regbase);
		}		
	}	
	if((_simd1a.status&ERS_READ)>0) {
		srcList->push_back(_simd1a.index+_simd1a.regbase);
		if((_simd1b.status&ERS_READ)>0) {
			srcList->push_back(_simd1b.index+_simd1b.regbase);
		}			
	}	
	if((_simd2a.status&ERS_READ)>0) {
		srcList->push_back(_simd2a.index+_simd2a.regbase);
		if((_simd2b.status&ERS_READ)>0) {
			srcList->push_back(_simd2b.index+_simd2b.regbase);
		}		
	}					
	if((_specreg1.status&ERS_READ)>0) {
		srcList->push_back(_specreg1.index+_specreg1.regbase);
	}
	if((_specreg2.status&ERS_READ)>0) {
		srcList->push_back(_specreg2.index+_specreg2.regbase);
	}
	if((_acc.status&ERS_READ)>0) {
		srcList->push_back(_acc.index+_acc.regbase);
	}				
}

INT SL2Instr::c2Latency() {
	if(isC2()) {
		switch (id()) {
			case c2ld_id:
				if(op_mode()==3)
					return 3;
				else
					return 6;
			case c2mvgc_id:
				if(dir())
					return 3;
				else
					return 6;	
			case c2st_id:
				if((op_mode()==0)||(op_mode()<1)||(op_mode()<2))	{
					switch (size()) {
						case 2:
						case 3:
							return 3;
						case 0:
							return 4;
						case 1:
							return 6;		
						default:
							AppFatal((0), ("Invalid size (%d).", size()));					
					}
				}
				else if(op_mode()==3) //SB->CR	
					return 3;
			default:
				return 6;
		}
		
	}
	else {
		AppFatal((0), ("c2Latency is for C2 only."));
		return 0;
	}
}

