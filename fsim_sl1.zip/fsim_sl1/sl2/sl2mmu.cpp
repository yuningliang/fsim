#include "sl2mmu.h"
#include "sl2ocrdefs.h"
#include "accesslist.h"
#include "ifhandler.h"

const STRING range_idx_name[RANGE_IDX_MAX+1] = {
	"Undefined",
	"SRAM",
	"OnChipRegister",
	"Framebuffer",
	"ROM",
	"ThreadBuffer",
	"Flash",
};

#define ISA_INCLUDE_NEWVLCS
#ifdef  ISA_INCLUDE_NEWVLCS  // temp for ISA3.1
static INT sl2_lut_order[LUT_ORDER_SIZE] = { 0, 1, 2, 3, 4, 5, 6, 7, 
					    8, 9, 10, 11, 12, 13, 14, 15 };
#else
static INT sl2_lut_order[LUT_ORDER_SIZE] = { 0, 1, 4, 8, 5, 2, 3, 6, 
					    9, 12, 13, 10, 7, 11, 14, 15 };
#endif
static INT sl2_lut_cost[LUT_COST_SIZE] = { 3, 2, 2, 1, 1, 1, 0, 0, 
											0, 0, 0, 0, 0, 0, 0, 0};
static INT sl2_cl[CL_SIZE] = {1, -5, 20, -1, 4, -12, 41, 5, 2, 3, -3, -6, 7, -7, 14, 19, 23};
static INT sl2_lut_ll[LUT_LL_SIZE] = 	{ 10, -12, -26, -32, -1024, 10 };
static INT sl2_lut_hl[LUT_HL_SIZE] = {   2,   3,   4,   5,   6,   8,
						  			 9,  10,  12,  13,  14,  15,	
						 			16,  17,  18,  22,  26,  32,
						 			48,  53,  64, 128, 257,  257, 
						 			1024 };

SL2MMU::SL2MMU(Address& addr, ProcessStatus<SL2Instr>& status) : CoreMMU(addr), _status(status) {
	_curthread = 0; 
	CoreMMU::setTextRange(0, 0xffffffff);
	CoreMMU::setDataRange(0, 0xffffffff);
	_memory = new Memory(addr);
	_accessList = new AccessList;
}

INT SL2MMU::getLutOrder(INT index){
	AppFatal((index>=0&&index<LUT_ORDER_SIZE), ("SL2 MMU: invaild LUT_ORDER_SIZE index (%d).", index));
	return sl2_lut_order[index];
}

INT SL2MMU::getLutCost(INT index){
	AppFatal((index>=0&&index<LUT_COST_SIZE), ("SL2 MMU: invaild LUT_COST_SIZE index (%d).", index));
	return sl2_lut_cost[index];
}

INT SL2MMU::getCL(INT index) {
	AppFatal((index>=0&&index<CL_SIZE), ("SL2 MMU: invaild CL_SIZE index (%d).", index));
	return sl2_cl[index];
}

INT SL2MMU::getLutLL(INT index) {
	AppFatal((index>=0&&index<LUT_LL_SIZE), ("SL2 MMU: invaild LUT_LL index (%d).", index));
	return sl2_lut_ll[index];
}

INT SL2MMU::getLutHL(INT index) {
	AppFatal((index>=0&&index<LUT_HL_SIZE), ("SL2 MMU: invaild LUT_HL index (%d).", index));
	return sl2_lut_hl[index];	
}

UBYTE SL2MMU::getSLOpMode(INT sl_indx) {
	AppFatal((0), ("MMU: invalid access to LUT (SLOpMode is removed)."));
	return 0;
}

UBYTE SL2MMU::getSLRow(INT sl_indx, INT bank) {
	INT bits = bank * LUT_ROW_EACH_BIT;
	INT shift = bits % INT8_BIT;
	INT index = bits / INT8_BIT;
	ADDR addr = accessList()->getAddr((sl_indx * LUT_BYTE_PER_ROW) + LUT_ROW_SHIFT_BYTE + index, RANGE_IDX_LUT);
	UWORD data = (((UBYTE)getByte(addr+INT8_BYTE))<<INT8_BIT) |  ((UBYTE) getByte(addr));
	return ((data>>shift)&LUT_ROW_MASK);
}

UBYTE SL2MMU::getSLBank(INT sl_indx, INT bank) {
	INT bits = bank * LUT_BANK_EACH_BIT;
	INT index = bits / INT8_BIT;
	ADDR addr = accessList()->getAddr((sl_indx * LUT_BYTE_PER_ROW) + LUT_BANK_SHIFT_BYTE + index, RANGE_IDX_LUT);
	UBYTE data = getByte(addr);
	if((bank&0x1)!=0) {
		data = (data >> LUT_BANK_EACH_BIT);
	}
	return (data&LUT_BANK_MASK);
}

UBYTE SL2MMU::getSLWen(INT sl_indx, INT bank) {
	ADDR addr = accessList()->getAddr((sl_indx * LUT_BYTE_PER_ROW) + LUT_WEN_SHIFT_BYTE, RANGE_IDX_LUT);
	UWORD data = getWord(addr);
	return ((data>>bank)&LUT_WEN_MASK);
}

BYTE SL2MMU::readSbufByte(ADDR a) {
	UINT type = readHandler(a, ET_HANDLE);
	AppFatal((type==RANGE_IDX_SBUF), ("MMU: invalid SRAM Sbuf 0x%08x.", a));
	BYTE data = getByte(a);
	return data;
}

HWORD SL2MMU::readSbufHword(ADDR a){
	UINT type = readHandler(a, ET_HANDLE);
	AppFatal((type==RANGE_IDX_SBUF), ("MMU: invalid SRAM Sbuf 0x%08x.", a));
	HWORD data = getHword(a);
	return data;
}

HWORD SL2MMU::readSbufSwapHword(ADDR addr){
	UINT type = readHandler(addr, ET_HANDLE);
	AppFatal((type==RANGE_IDX_SBUF), ("MMU: invalid SRAM Sbuf 0x%08x.", addr));	
	HWORD data = (((UBYTE)getByte(addr))<<INT8_BIT) 
				 | ((UBYTE)getByte(addr+1));
	return data;
}


WORD SL2MMU::SL2MMU::readSbufWord(ADDR a){
	UINT type = readHandler(a, ET_HANDLE);
	AppFatal((type==RANGE_IDX_SBUF), ("MMU: invalid SRAM Sbuf 0x%08x.", a));
	WORD data = getWord(a);
	return data;
}

WORD SL2MMU::readSbufSwapWord(ADDR a) {
	UINT type = readHandler(a, ET_HANDLE);
	AppFatal((type==RANGE_IDX_SBUF), ("MMU: invalid SRAM Sbuf 0x%08x.", a));
	WORD data =   (((UBYTE)getByte(a))<<INT24_BIT) 
				| (((UBYTE)getByte(a+1))<<INT16_BIT) 
				| (((UBYTE)getByte(a+2))<<INT8_BIT) 
				| ((UBYTE)getByte(a+3));
	return data;	
}

void SL2MMU::writeSbufByte(ADDR a, BYTE byte){
	UINT type = writeHandler(a, ET_HANDLE);
	AppFatal((type==RANGE_IDX_SBUF), ("MMU: invalid SRAM Sbuf 0x%08x.", a));
	setByte(a, byte);
}

void SL2MMU::writeSbufHword(ADDR a, HWORD hword){
	UINT type = writeHandler(a, ET_HANDLE);
	AppFatal((type==RANGE_IDX_SBUF), ("MMU: invalid SRAM Sbuf 0x%08x.", a));
	setHword(a, hword);	
}

void SL2MMU::writeSbufSwapHword(ADDR a, HWORD hword){
	UINT type = writeHandler(a, ET_HANDLE);
	AppFatal((type==RANGE_IDX_SBUF), ("MMU: invalid SRAM Sbuf 0x%08x.", a));
	setByte(a+1, (hword&BYTE_DATA_MASK)); 
	setByte(a, ((hword>>INT8_BIT)&BYTE_DATA_MASK)); 
}

void SL2MMU::writeSbufSwapWord(ADDR a, WORD word){
	UINT type = writeHandler(a, ET_HANDLE);
	AppFatal((type==RANGE_IDX_SBUF), ("MMU: invalid SRAM Sbuf 0x%08x.", a));
	setByte(a+3, (word&BYTE_DATA_MASK)); 
	setByte(a+2, ((word>>INT8_BIT)&BYTE_DATA_MASK)); 	
	setByte(a+1, ((word>>INT16_BIT)&BYTE_DATA_MASK)); 	
	setByte(a, ((word>>INT24_BIT)&BYTE_DATA_MASK)); 	
}	

void SL2MMU::writeSbufWord(ADDR a, WORD word){
	UINT type = writeHandler(a, ET_HANDLE);
	AppFatal((type==RANGE_IDX_SBUF), ("MMU: invalid SRAM Sbuf 0x%08x.", a));
	setWord(a, word);
}	

BYTE SL2MMU::readVbufByte(ADDR a) {
	UINT type = readHandler(a, ET_HANDLE);
	AppFatal((type==RANGE_IDX_VBUF), ("MMU: invalid SRAM Vbuf 0x%08x.", a));
	BYTE data = getByte(a);
	return data;
}

HWORD SL2MMU::readVbufHword(ADDR a){
	UINT type = readHandler(a, ET_HANDLE);
	AppFatal((type==RANGE_IDX_VBUF), ("MMU: invalid SRAM Vbuf 0x%08x.", a));
	HWORD data = (((UBYTE)getByte(a+SL2_VBUF_BANK1_OFFSET))<<INT8_BIT) 
					| ((UBYTE)getByte(a));
	return data;
}

WORD SL2MMU::readVbufWord(ADDR a){
	UINT type = readHandler(a, ET_HANDLE);
	AppFatal((type==RANGE_IDX_VBUF), ("MMU: invalid SRAM Vbuf 0x%08x.", a));
	
	WORD data =   (((UBYTE)getByte(a+SL2_VBUF_BANK3_OFFSET))<<INT24_BIT) 
				| (((UBYTE)getByte(a+SL2_VBUF_BANK2_OFFSET))<<INT16_BIT) 
				| (((UBYTE)getByte(a+SL2_VBUF_BANK1_OFFSET))<<INT8_BIT) 
				| ((UBYTE)getByte(a));	
	return data;
}

void SL2MMU::writeVbufByte(ADDR a, BYTE byte){
	UINT type = writeHandler(a, ET_HANDLE);
	AppFatal((type==RANGE_IDX_VBUF), ("MMU: invalid SRAM Vbuf 0x%08x.", a));
	setByte(a, byte);
}

void SL2MMU::writeVbufHword(ADDR a, HWORD hword){
	UINT type = writeHandler(a, ET_HANDLE);
	AppFatal((type==RANGE_IDX_VBUF), ("MMU: invalid SRAM Vbuf 0x%08x.", a));
	setByte(a, (hword&BYTE_DATA_MASK));
	setByte(a+16, ((hword>>INT8_BIT)&BYTE_DATA_MASK));
}

void SL2MMU::writeVbufWord(ADDR a, WORD word){
	UINT type = writeHandler(a, ET_HANDLE);
	AppFatal((type==RANGE_IDX_VBUF), ("MMU: invalid SRAM Vbuf 0x%08x.", a));		
	setByte(a, (word&BYTE_DATA_MASK));
	setByte((a+16), ((word>>INT8_BIT)&BYTE_DATA_MASK));
	setByte((a+32), ((word>>INT16_BIT)&BYTE_DATA_MASK));
	setByte((a+48), ((word>>INT24_BIT)&BYTE_DATA_MASK));
}	

void SL2MMU::copySram2Dram(ADDR dest, ADDR src, INT size) {
	while (size--) {
		UINT typeDest = writeHandler(dest, ET_HANDLE);
		UINT typeSrc = readHandler(src, ET_HANDLE);
		AppFatal((typeDest==RANGE_IDX_MEMORY), ("MMU: invalid DRAM address 0x%08x.", dest));
		AppFatal((isSRAM(typeSrc)==TRUE), ("MMU: invalid SRAM address 0x%08x.", src));
		setByte(dest, getByte(src));
		dest++;
		src++;
	}
}

void SL2MMU::copyDram2Sram(ADDR dest, ADDR src, INT size) {
	while (size--) {
		UINT typeDest = writeHandler(dest, ET_HANDLE);
		UINT typeSrc = readHandler(src, ET_HANDLE);
		AppFatal((typeSrc==RANGE_IDX_MEMORY), ("MMU: invalid DRAM address 0x%08x.", dest));
		AppFatal((isSRAM(typeDest)==TRUE), ("MMU: invalid SRAM address 0x%08x.", src));		
		
		setByte(dest, getByte(src));
		dest++;
		src++;		
	}	
}

void SL2MMU::copySram2Sram(ADDR dest, ADDR src, INT size) {
	while (size--) {
		UINT typeDest = writeHandler(dest, ET_HANDLE);
		UINT typeSrc = readHandler(src, ET_HANDLE);
		AppFatal((isSRAM(typeDest)==TRUE), ("MMU: invalid SRAM address 0x%08x.", src));	
		AppFatal((isSRAM(typeSrc)==TRUE), ("MMU: invalid SRAM address 0x%08x.", src));	
				
		setByte(dest, getByte(src));
		dest++;
		src++;		
	}	
}

void SL2MMU::copyDMAByte(ADDR dest, ADDR src, INT size) {
	while (size--) {
		UINT typeDest = writeHandler(dest, ET_HANDLE);
		UINT typeSrc = readHandler(src, ET_HANDLE);
		AppFatal((typeSrc!=RANGE_IDX_MEMORY||typeDest!=RANGE_IDX_MEMORY)
					, ("MMU: DRAM to DRAM copying is not supported.", src, dest));	

		setByte(dest, getByte(src));
		dest++;
		src++;		
	}	
}

UINT SL2MMU::readHandler(const ADDR addr, const UBYTE tag){
	if((ET_BREAK&tag)>0) {
		CHECK_MEM_BREAK(addr, tag);
	}
	if((ET_HANDLE&tag)>0) {
		pair<UINT, InterfaceHandler*> ret = accessList()->search(addr);
		if(ret.second!=NULL) {
			ret.second->readHook(addr);
		}
		return ret.first;
	}
	return RANGE_IDX_MEMORY;
}
	
UINT SL2MMU::writeHandler(const ADDR addr, const UBYTE tag){
	if((ET_BREAK&tag)>0) {
		CHECK_MEM_BREAK(addr, tag);
	}
	if((ET_READONLY&tag)>0) {
		//assert read only region
	}	
	if((ET_HANDLE&tag)>0) {
		pair<UINT, InterfaceHandler*> ret = accessList()->search(addr);
		if(ret.second!=NULL) {
			ret.second->writeHook(addr);
		}
		return ret.first;		
	}
	return RANGE_IDX_MEMORY;
}

BOOL SL2MMU::isVbuf(ADDR addr) {
	return (accessList()->getType(addr)==RANGE_IDX_VBUF);
}
BOOL SL2MMU::isSbuf(ADDR addr) {
	return (accessList()->getType(addr)==RANGE_IDX_SBUF);
}
BOOL SL2MMU::isLut(ADDR addr) {
	return (accessList()->getType(addr)==RANGE_IDX_LUT);
}

ADDR SL2MMU::getForkThreadSP(void){
	return getWord(SL2_OCR_THREAD_SP);  
}
void SL2MMU::setForkThreadSP(ADDR addr) {
	setWord(SL2_OCR_THREAD_SP, addr);  
}

void SL2MMU::registerDevice(InterfaceHandler* object, ADDR start, size_t size)
{
	accessList()->insert(RANGE_IDX_OCR, start, start+size-1, object);
	memory()->setDefaultTag(start, start+size-1, ET_HANDLE);
}

void SL2MMU::registerMemoryRange(UINT type, ADDR start, size_t size, bool readOnly)
{
	accessList()->insert(type, start, start+size-1, NULL);
	if (readOnly) {
		memory()->setDefaultTag(start, start+size-1, ET_READONLY);
	}
}

void SL2MMU::setSRAMBaseWord(const ADDR addr, WORD word) {
	ADDR a = accessList()->getAddr(addr, RANGE_IDX_SBUF);
	AppFatal(((a&WORD_ALIGN_MASK)==0), ("MMU: unaligned word write to 0x%08x.", a));
	CoreMMU::setWord(a, word);
}	

void SL2MMU::setSRAMBaseHword(const ADDR addr, HWORD hword) {
	ADDR a = accessList()->getAddr(addr, RANGE_IDX_SBUF);
	AppFatal(((a&HWORD_ALIGN_MASK)==0), ("MMU: unaligned hword write to 0x%08x.", a));
	CoreMMU::setHword(a, hword);
}	

void SL2MMU::setSRAMBaseByte(const ADDR addr, BYTE byte) {
	ADDR a = accessList()->getAddr(addr, RANGE_IDX_SBUF);
	CoreMMU::setByte(a, byte);
}

void SL2MMU::setSRAMByte(const ADDR a, const BYTE byte) {
	CoreMMU::setByte(a, byte);
	UINT type = writeHandler(a, ET_HANDLE);
	AppFatal((isSRAM(type)==TRUE), ("MMU: invalid SRAM address 0x%08x.", a));
}

void SL2MMU::setSRAMHword(const ADDR a, const HWORD hword) {
	AppFatal(((a&HWORD_ALIGN_MASK)==0), ("MMU: unaligned hword write to 0x%08x.", a));
	CoreMMU::setHword(a, hword);
	UINT type = writeHandler(a, ET_HANDLE);
	AppFatal((isSRAM(type)==TRUE), ("MMU: invalid SRAM address 0x%08x.", a));
}
   
void SL2MMU::setSRAMWord(const ADDR a, const WORD word) {
	AppFatal(((a&WORD_ALIGN_MASK)==0), ("MMU: unaligned word write to 0x%08x.", a));
	CoreMMU::setWord(a, word);
	UINT type = writeHandler(a, ET_HANDLE);
	AppFatal((isSRAM(type)==TRUE), ("MMU: invalid SRAM address 0x%08x.", a));
} 
