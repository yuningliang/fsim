#include "sl2reg.h"
#include "status.h"
#include "messg.h"
#include "sl2defs.h"

const STRING reg_name_c2_ctrl[REG_C2_CTRL_SIZE] = {
	"simd_shft", "vmacs", "mad_ctrl", "mad_mvsel", 
	"sum_ctrl", "ls_sw", "ls_ctrl", "mult_hi"
};

const STRING reg_name_c2_spec[REG_C2_SPEC_SIZE] = {
	"cond", "mov_pat", "start", "bits", "best_mv", 
	"best_sad", "best_cost", "byte_coll", "mv_cost", 
};

const STRING reg_name_c2_acc[REG_C2_ACC_SIZE] = {
	"sum_acc",
};

const STRING reg_name_c2_internal[REG_C2_INTERNAL_SIZE] = {
	"start_of_blk", "zero_cnt", "total_zero", "trail_one", "num_of_non_zero", 
	"coeff_cost", "coeff_cnt", "write_sel", "bank", "med_cmp", "trail_sign",
};

//char reg_name_c2_scalar[REG_SCALAR_SIZE][16];
char reg_name_c2_simd[REG_SIMD_ROW][REG_SIMD_BANK][16];

SL2Register::SL2Register(ProcessStatus<SL2Instr>& status, 
			WORD* ctrl, WORD* spec, WORD* internal, HWORD** simd, SIMD_Ctrol_Type* simd_ctrl) : CoreRegister<SL2Instr>(status) {
	_c2ctrl = ctrl;
	_c2spec = spec;
	_c2internal = internal;
	_simd = simd;
	_simd_ctrl = simd_ctrl;
	
	clear();
	for(INT j=0; j<REG_SIMD_ROW; j++) {
		for(INT i = 0; i<REG_SIMD_BANK; i++) {
			sprintf(reg_name_c2_simd[j][i], "simd_%02d_%02d", j, i);
		}
	}		
}

SL2Register::SL2Register(ProcessStatus<SL2Instr>& status, HWORD** simd, SIMD_Ctrol_Type* simd_ctrl) : CoreRegister<SL2Instr>(status) {
	_c2ctrl = new WORD[REG_C2_CTRL_SIZE];
	_c2spec = new WORD[REG_C2_SPEC_SIZE];
	_c2internal = new WORD[REG_C2_INTERNAL_SIZE];
	_simd = simd;

	_simd_ctrl = simd_ctrl;

	clear();
	for(INT j=0; j<REG_SIMD_ROW; j++) {
		for(INT i = 0; i<REG_SIMD_BANK; i++) {
			sprintf(reg_name_c2_simd[j][i], "simd_%02d_%02d", j, i);
		}
	}		
}

SL2Register::SL2Register(ProcessStatus<SL2Instr>& status) 
								: CoreRegister<SL2Instr>(status) {
	_simd = new HWORD* [REG_SIMD_ROW];
	for (INT k = 0; k < REG_SIMD_ROW; k ++) {
		_simd[k] = new HWORD[REG_SIMD_BANK];
	}
	_c2ctrl = new WORD[REG_C2_CTRL_SIZE];
	_c2spec = new WORD[REG_C2_SPEC_SIZE];
	_c2internal = new WORD[REG_C2_INTERNAL_SIZE];
	
	_simd_ctrl = new SIMD_Ctrol_Type;

	clear();
	for(INT j=0; j<REG_SIMD_ROW; j++) {
		for(INT i = 0; i<REG_SIMD_BANK; i++) {
			sprintf(reg_name_c2_simd[j][i], "simd_%02d_%02d", j, i);
		}
	}		
}

INT SL2Register::createNameMap(RegMap& regmap)
{
	INT i, j;
	CoreRegister<SL2Instr>::createNameMap(regmap);

	for (i=0; i<REG_C2_CTRL_SIZE; i++) {
		regmap[reg_name_c2_ctrl[i]] = new RegMapItem(reg_name_c2_ctrl[i], WORD_BYTE, (BYTE*) &_c2ctrl[i]);
	}
	for (i=0; i<REG_C2_SPEC_SIZE; i++) {
		regmap[reg_name_c2_spec[i]] = new RegMapItem(reg_name_c2_spec[i], WORD_BYTE, (BYTE*) &_c2spec[i]);
	}
	for (i=0; i<REG_C2_INTERNAL_SIZE; i++) {
		regmap[reg_name_c2_internal[i]] = new RegMapItem(reg_name_c2_internal[i], WORD_BYTE, (BYTE*) &_c2internal[i]);
	}
	for(j=0; j<REG_SIMD_ROW; j++) {
		for(i = 0; i<REG_SIMD_BANK; i++) {
			regmap[reg_name_c2_simd[j][i]] = new RegMapItem(reg_name_c2_simd[j][i], HWORD_BYTE, (BYTE*) &_simd[j][i]);
		}
	}	
	regmap[reg_name_c2_acc[0]] = new RegMapItem(reg_name_c2_acc[0], WORD_BYTE, (BYTE*) &_sum_acc);
	return regmap.size();
}

void SL2Register::clear() {
	INT i, j;
	CoreRegister<SL2Instr>::clear();	

	// Init check condition for checkSIMD
	_simd_ctrl->_checkSIMDRegister = 0;
	
	for(j=0; j<THREAD_PAIR_MAXNUMBER; j++){
		for(i=0; i< REG_SIMD_ROW ; i++)
		{
			_simd_ctrl->SIMD_Ctrl[j][i][0] = 0;
			_simd_ctrl->SIMD_Ctrl[j][i][1] = 0;
			_simd_ctrl->Instr[j][i][0] = 0;
			_simd_ctrl->Instr[j][i][1]= 0;
			_simd_ctrl->conflict[j][i] = 0;
			_simd_ctrl->Thread_ID[j][i][0] = 0;
			_simd_ctrl->Thread_ID[j][i][1] = 0;
		}
	}
	//for(i=0; i< MAX_THREAD; i++)
	_simd_ctrl->Thread_pair_LUT[0] = 0;
	_simd_ctrl->Thread_pair_LUT[1] = 0;
	_simd_ctrl->Thread_pair_LUT[2] = 1;
	_simd_ctrl->Thread_pair_LUT[3] = 2;

	_simd_ctrl->out = NULL;


	for(i = 0; i<REG_C2_CTRL_SIZE; i++) {
		 _c2ctrl[i] = 0;
	}
	for(i = 0; i<REG_C2_SPEC_SIZE; i++) {
		 _c2spec[i] = 0;
	}
	_sum_acc = 0;
	
	for(j=0; j<REG_SIMD_ROW; j++) {
		for(i = 0; i<REG_SIMD_BANK; i++) {
			_simd[j][i] = 0;
		}
		//for(i = 0; i<MAX_THREAD; i++) {
		//	_simd_ctlr[j][i] = 0;
		//}
	}
	for(i = 0; i<REG_C2_INTERNAL_SIZE; i++) {
		_c2internal[i] = 0;
	}
	initC2INT();
}

void SL2Register::dumpRegs2File(FILE* out, const char *regSetName) {
	INT i, j;
	UINT simdchecker = checkSIMDRegister();
	checkSIMDRegister(FALSE);
	CoreRegister<SL2Instr>::dumpRegs2File(out, regSetName);
	
	if(strcasecmp(regSetName, "all")==0||strcasecmp(regSetName, "h264")==0) {
		for(i=0; i<REG_SIMD_ROW; i++) {
			for(j = 0; j<REG_SIMD_BANK; j++) {
				fprintf(out, "%04x \\\\ simd_%02d_%02d\n", (UHWORD)getSIMD(i, j), i, j);
			}
		}
		
		for(i = 0; i<REG_C2_CTRL_SIZE; i++) {
			fprintf(out, "%08x \\\\ %s\n", getC2CTRL(i), reg_name_c2_ctrl[i]);
		}
		fprintf(out, "%08x \\\\ %s\n", getC2SUM_ACC(), reg_name_c2_acc[EC2ACC_SUM]);
		/*
		fprintf(out, "%08x \\\\ %s\n", getC2MAD_ACC(), reg_name_c2_acc[EC2ACC_MAD]);
		for(i = 0; i<REG_SIMD_BANK; i++) {
			fprintf(out, "%08x \\\\ %s\n", getSIMD_ACC(i), reg_name_c2_simd_acc[i]);
		}
		*/
		for(i = 0; i<REG_C2_SPEC_SIZE; i++) {
			fprintf(out, "%08x \\\\ %s\n", getC2SPEC(i), reg_name_c2_spec[i]);
		}
		for(i = 0; i<REG_C2_INTERNAL_SIZE; i++) {
			fprintf(out, "%08x \\\\ %s\n", getC2INT(i), reg_name_c2_internal[i]);
		}		
	}

	checkSIMDRegister(simdchecker);
}	

INT SL2Register::initRegs(FILE* in, const char *regSetName) {
	INT line = CoreRegister<SL2Instr>::initRegs(in, regSetName);
	//UINT simdchecker = checkSIMDRegister();
	//checkSIMDRegister(FALSE);

	if(line>=0) {
		if(strcasecmp(regSetName, "all")==0||strcasecmp(regSetName, "h264")==0) {
		WORD data = 0;
		INT i, j;
		char str[50];			
			for(i=0; i<REG_SIMD_ROW; i++) {
				for(j = 0; j<REG_SIMD_BANK; j++) {
					line++;
					if(fscanf(in, "%x%[^\n]", &data, str)!=EOF&&(data==(UHWORD)data)) {
						setSIMD(i, j, data);
					}
					else {
						return (-line);
					}					
				}
			}
			
			for(i = 0; i<REG_C2_CTRL_SIZE; i++) {
				line++;
				if(fscanf(in, "%x%[^\n]", &data, str)!=EOF) {
					setC2CTRL(i, data);
				}
				else {
					return (-line);
				}					
			}
			line++;
			if(fscanf(in, "%x%[^\n]", &data, str)!=EOF) {
				setC2SUM_ACC(data);
			}
			else {
				return (-line);
			}	
			/*
			line++;
			if(fscanf(in, "%x%[^\n]", &data, str)!=EOF) {
				setC2MAD_ACC(data);
			}
			else {
				return (-line);
			}
										
			for(i = 0; i<REG_SIMD_BANK; i++) {
				line++;
				if(fscanf(in, "%x%[^\n]", &data, str)!=EOF) {
					setSIMD_ACC(i, data);
				}
				else {
					return (-line);
				}					
			}
			*/
			for(i = 0; i<REG_C2_SPEC_SIZE; i++) {
				line++;
				if(fscanf(in, "%x%[^\n]", &data, str)!=EOF) {
					setC2SPEC(i, data);
				}
				else {
					return (-line);
				}					
			}
			for(i = 0; i<REG_C2_INTERNAL_SIZE; i++) {
				line++;
				if(fscanf(in, "%x%[^\n]", &data, str)!=EOF) {
					setC2INT(i, data);
				}
				else {
					return (-line);
				}				
			}				
		}
	}
	return line;
}	

void SL2Register::dumpRegs(FILE* out,  const char *regSetName) {
	INT i, j;
	CoreRegister<SL2Instr>::dumpRegs(out, regSetName);
	UINT simdchecker = checkSIMDRegister();
	checkSIMDRegister(FALSE);

	
	if(strcasecmp(regSetName, "all")==0||strcasecmp(regSetName, "h264")) {
		fprintf(out, "C2 SIMD registers:\n");
		fprintf(out, "  ");
		for(i = 0; i<REG_SIMD_BANK; i++) {
			fprintf(out, " %4x", i);
		}
		fprintf(out, "\n");
		for(j=0; j<REG_SIMD_ROW; j++) {
			fprintf(out, "%02x", j);
			for(i = 0; i<REG_SIMD_BANK; i++) {
				fprintf(out, " %04x", (UHWORD) getSIMD(j, i));
			}
			fprintf(out, "\n");
		}
		
		fprintf(out, "C2 Control registers:\n");
		for(i = 0; i<REG_C2_CTRL_SIZE; i++) {
			fprintf(out, "%10s=%08x ", reg_name_c2_ctrl[i], getC2CTRL(i));
			if (i%REG_PRINT_PER_LINE == REG_PRINT_PER_LINE-1)
				fprintf(out, "\n");
		}
		fprintf(out, "\n");
		fprintf(out, "C2 ACC registers:\n");
		fprintf(out, "%10s=%08x \n", reg_name_c2_acc[EC2ACC_SUM], getC2SUM_ACC());
		/*
		fprintf(out, "%10s=%08x \n", reg_name_c2_acc[EC2ACC_MAD], getC2MAD_ACC());
		fprintf(out, "%10s:\n", reg_name_c2_acc[EC2ACC_SIMD_ACC]);
		for(i = 0; i<REG_SIMD_BANK; i++) {
			fprintf(out, "%10s=%08x ", reg_name_c2_simd_acc[i], getSIMD_ACC(i));
			if (i%REG_PRINT_PER_LINE == REG_PRINT_PER_LINE-1)
				fprintf(out, "\n");		 
		}
		*/
		
		fprintf(out, "C2 Special registers:\n");	
		for(i = 0; i<REG_C2_SPEC_SIZE; i++) {
			fprintf(out, "%10s=%08x ", reg_name_c2_spec[i], getC2SPEC(i));
			if (i%REG_PRINT_PER_LINE == REG_PRINT_PER_LINE-1)
				fprintf(out, "\n");		 
		}
		fprintf(out, "C2 Internal registers:\n");	
		for(i = 0; i<REG_C2_INTERNAL_SIZE; i++) {
			fprintf(out, "%16s=%08x\n", reg_name_c2_internal[i], getC2INT(i));
		}		
		fprintf(out, "\n");
	}

	checkSIMDRegister(simdchecker);
}	

INT SL2Register::setRegByName(const STRING regName, const DWORD value) {
	INT j, i;
	
	// Check if the register belongs to parent
	if (CoreRegister<SL2Instr>::setRegByName(regName, value) == 0)
		return 0;
	// acc
	for (i=0; i<REG_C2_CTRL_SIZE; i++) {
		if (strcmp(reg_name_c2_ctrl[i], regName) == 0) {
			setC2CTRL(i, value);
			return 0;
		}		
	}
	for (i=0; i<REG_C2_SPEC_SIZE; i++) {
		if (strcmp(reg_name_c2_spec[i], regName) == 0) {
			setC2SPEC(i, value);
			return 0;
		}			
	}
	for (i=0; i<REG_C2_ACC_SIZE-1; i++) {
		if (strcmp(reg_name_c2_acc[i], regName) == 0) {
			setC2ACC(i, value);
			return 0;
		}			
	}
	/*
	for (i=0; i<REG_SIMD_BANK; i++) {
		if (strcmp(reg_name_c2_simd_acc[i], regName) == 0) {
			setSIMD_ACC(i, value);
			return 0;
		}			
	}
*/
	UINT simdchecker = checkSIMDRegister();
	checkSIMDRegister(FALSE);

	for(j=0; j<REG_SIMD_ROW; j++) {
		for(i = 0; i<REG_SIMD_BANK; i++) {
			if (strcmp(reg_name_c2_simd[j][i], regName) == 0) {
				setSIMD(j, i, value);
				checkSIMDRegister(simdchecker);
				return 0;
			}			
		}
	}	

	checkSIMDRegister(simdchecker);

	return -1;
}	

bool SL2Register::isValidRegName(const STRING regName) {
	INT i, j;
	
	// Check if the register belongs to parent
	if (CoreRegister<SL2Instr>::isValidRegName(regName))
		return true;
	for (i=0; i<REG_C2_CTRL_SIZE; i++) {
		if (strcmp(reg_name_c2_ctrl[i], regName) == 0) {
			return TRUE;
		}		
	}
	for (i=0; i<REG_C2_SPEC_SIZE; i++) {
		if (strcmp(reg_name_c2_spec[i], regName) == 0) {
			return TRUE;
		}			
	}
	for (i=0; i<REG_C2_ACC_SIZE-1; i++) {
		if (strcmp(reg_name_c2_acc[i], regName) == 0) {
			return TRUE;
		}			
	}
	/*
	for (i=0; i<REG_SIMD_BANK; i++) {
		if (strcmp(reg_name_c2_simd_acc[i], regName) == 0) {
			return TRUE;
		}			
	}
	for (i=0; i<REG_SCALAR_SIZE; i++) {
		if (strcmp(reg_name_c2_scalar[i], regName) == 0) {
			return TRUE;
		}
	}
	*/	
	for(j=0; j<REG_SIMD_ROW; j++) {
		for(i = 0; i<REG_SIMD_BANK; i++) {
			if (strcmp(reg_name_c2_simd[j][i], regName) == 0) {
				return TRUE;
			}			
		}
	}	
	return FALSE;
}	

INT SL2Register::getRegIndexByName(const STRING regName)
{
	INT i;
	i = CoreRegister<SL2Instr>::getRegIndexByName(regName);
//	if(i<0) {
//		for (i=0; i<REG_ALL_C3_SPEC_SIZE; i++) {
//			if (strcmp(reg_name_c3_spec[i], regName)==0)
//				return i;
//		}			
//	}
	//acc, ar
	return i;	// not found
}

