#include "sl2shell.h"
#include "sl2threadctrl.h"
#include "sl2dma.h"


SL2Shell::SL2Shell() : Shell<SL2_CLASS_LIST>() {
	SL2ThreadCtrl* threadCtrl = new SL2ThreadCtrl(status(), machine());
	SL2Register* reg01 = new SL2Register(status());
	SL2Register* reg02= new SL2Register(status(), reg01->getSIMDPtr(), reg01->getSIMDCtrolPtr());
	SL2Disasm* disasm01 = new SL2Disasm((SL2MMU&)mmu(), *reg01, THREAD_ID_MAIN_0);
	SL2Disasm* disasm02 = new SL2Disasm((SL2MMU&)mmu(), *reg02, THREAD_ID_MAIN_1);
	SL2Exec* exec01 = new SL2Exec((SL2MMU&)mmu(), *reg01, status(), threadCtrl);
	SL2Exec* exec02 = new SL2Exec((SL2MMU&)mmu(), *reg02, status(), threadCtrl);
	
	SL2DMA* dam = new SL2DMA((SL2MMU&)mmu(), mmu().memory(), SL2_SDRAM_ADDR_START, SL2_OCR_EI_ALL);
	
	_profiler = new Profiler<SL2Instr, SL2Machine> (_status, _machine, EIG_max);
	_gdbServer = new GDBServer<SL2MMU, SL2Machine> ((CoreMMU&)_mmu, _machine);
	machine().profiler(_profiler);	
		
	machine().setThread(exec01, disasm01, THREAD_ID_MAIN_0);
	machine().setThread(exec02, disasm02, THREAD_ID_MAIN_1);
	machine().setThread(exec01, disasm01, THREAD_ID_SLAVE_0);
	machine().setThread(exec02, disasm02, THREAD_ID_SLAVE_1);

	mmu().curthread(THREAD_ID_MAIN_0);	
	mmu().registerMemoryRange(RANGE_IDX_SBUF, SL2_SB_ADDR_START, SL2_SB_ADDR_END-SL2_SB_ADDR_START+1, FALSE);
	mmu().registerMemoryRange(RANGE_IDX_VBUF, SL2_VB_ADDR_START, SL2_VB_ADDR_END-SL2_VB_ADDR_START+1, FALSE);
	mmu().registerMemoryRange(RANGE_IDX_LUT, SL2_SL_ADDR_START, SL2_SL_ADDR_END-SL2_SL_ADDR_START+1, FALSE);
	mmu().registerDevice(dam, SL2_SDRAM_ADDR_START, SL2_ONCHIPREG_SIZE);
	

#if _WARN_LAYOUT
	mmu().accessList()->printList();
#endif	
	machine().curthread(THREAD_ID_MAIN_0);
}
