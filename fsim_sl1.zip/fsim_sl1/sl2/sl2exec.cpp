#include "sl2threadctrl.h"
#include "sl2exec.h"
#include "sl2instr.h"
#include "utils.h"
#include "accesslist.h"

#define _FORK2NOP 1
#define _MVGR			1

SL2Exec::SL2Exec(SL2MMU& mmu, SL2Register& reg, ProcessStatus<SL2Instr>& status) 
						: CoreExec<SL2MMU, SL2Register, SL2Instr>(mmu, reg, status) {
	_threadCtrl = NULL;
	_skipFork = TRUE;
}

SL2Exec::SL2Exec(SL2MMU& mmu, SL2Register& reg, ProcessStatus<SL2Instr>& status, SL2ThreadCtrl* th)
						: CoreExec<SL2MMU, SL2Register, SL2Instr>(mmu, reg, status) {
	_threadCtrl = th;
	_skipFork = FALSE;
}

void SL2Exec::setExecMode(INT modeID, WORD value) {
	switch (modeID) {
		case EXEC_MODE_SKIP_FORK:
			skipFork(value);
			break;
		default:
			SimFatal((0), ("SL2Exec: unsupport execution mode (%d)", modeID));
			break;
		
	}
}


INT SL2Exec::motionBitCost(INT bits_hi) {
	if(((bits_hi & 0x300)>>8) == 0x1)
		bits_hi = 19;
	else if(((bits_hi & 0x380)>>7) == 0x1)
		bits_hi = 17;
	else if(((bits_hi & 0x3c0)>>6) == 0x1)
		bits_hi = 15;
	else if(((bits_hi & 0x3e0)>>5) == 0x1)
		bits_hi = 13;
	else if(((bits_hi & 0x3f0)>>4) == 0x1)
		bits_hi = 11;
	else if(((bits_hi & 0x3f8)>>3) == 0x1)
		bits_hi= 9;
	else if(((bits_hi & 0x3fc)>>2) == 0x1)
		bits_hi = 7;
	else if(((bits_hi & 0x3fe)>>1) == 0x1)
		bits_hi = 5;
	else if(((bits_hi & 0x3ff)) == 0x1)
		bits_hi = 3;
	else
		bits_hi = 1;
	          
		return bits_hi;
/*	
	if((data&0x300)==0x100) {
		return 19;
	}
	else if((data&0x280)==0x80) {
		return 17;
	}
	else if((data&0x240)==0x40) {
		return 15;
	}
	else if((data&0x220)==0x20) {
		return 13;
	}
	else if((data&0x210)==0x10) {
		return 11;
	}
	else if((data&0x208)==0x8) {
		return 9;
	}	
	else if((data&0x204)==0x4) {
		return 7;
	}	
	else if((data&0x202)==0x2) {
		return 5;
	}	
	else if((data&0x201)==0x1) {
		return 3;
	}	
	else {
		return 1;
	}	
*/
}

//private instructions
ADDR SL2Exec::execC2psum16 (SL2Instr* instr) {
	INT op_mode = instr->op_mode();
	WORD result;
	INT rs = instr->rs1_simd();
	INT rd = instr->rd();

	switch(op_mode) {
		case 0:
			result = reg().getSIMD(rs, 0)+reg().getSIMD(rs, 1)+reg().getSIMD(rs, 2) + reg().getSIMD(rs, 3);
			reg().setC2SUM_ACC(result);
			//printf("STEP 0:  [%08x]\n", result);
			break;
		case 1:
			result = reg().getSIMD(rs, 4)+reg().getSIMD(rs, 5)+reg().getSIMD(rs, 6) + reg().getC2SUM_ACC();
			reg().setC2SUM_ACC(result);
			//printf("STEP 1:  [%08x]\n",  result);
			break;
		case 2:
			result = reg().getSIMD(rs, 7)+reg().getSIMD(rs, 8)+reg().getSIMD(rs, 9) + reg().getC2SUM_ACC();
			reg().setC2SUM_ACC(result);
			//printf("STEP 2:[%08x]\n",  result);
			break;
		case 3:
			result = reg().getSIMD(rs, 10)+reg().getSIMD(rs, 11)+reg().getSIMD(rs, 12) + reg().getC2SUM_ACC();
			reg().setC2SUM_ACC(result);
			//printf("STEP 3: [%08x]\n",  result);
			break;
		case 4:
			result = reg().getSIMD(rs, 13)+reg().getSIMD(rs, 14)+reg().getSIMD(rs, 15) + reg().getC2SUM_ACC();
			if(instr->shft())
				result = result >> 1;
			
			//reg().setSIMD(rd, 0, result);
			reg().setGPR(rd, result);
			//printf("STEP 4: [%08x], sh[%01x], rd[%d] == [%08x]\n",  result,instr->shft(), rd, reg().getGPR(rd));
			break;
		default:
			AppFatal((0), ("ERROR! C2.PSUM16 only supports op_mode 0-4 but not %d!\n", op_mode));
	}

	return pc()+instr->instrsize();
}

ADDR SL2Exec::execC2psum16_old (SL2Instr* instr) {
	INT op_mode = instr->op_mode();
	WORD addin1, addin2;
	WORD result;
	INT rs = instr->rs1_simd();
	INT rd = instr->rd1_simd();

	switch(op_mode) {
		case 0:
			for(INT i=1; i<REG_SIMD_BANK; i=i+2) {
				addin1 = reg().getSIMD(rs, i);
				addin2 = reg().getSIMD(rs, i-1);
				result = addin1+addin2;
				reg().setSIMD(rd,i , result);
				//printf("STEP 0: [%04x]  [%04x] = [%08x]\n", addin1, addin2, result);
			}
			break;
		case 1:
			for(INT i=3; i<REG_SIMD_BANK; i=i+4) {
				addin1 = reg().getSIMD(rs, i);
				addin2 = reg().getSIMD(rs, i-2);
				result = addin1+addin2;
				reg().setSIMD(rd,i , result);
				//printf("STEP 1: [%04x]  [%04x] = [%08x]\n", addin1, addin2, result);
			}
			break;
		case 2:
			for(INT i=7; i<REG_SIMD_BANK; i=i+8) {
				addin1 = reg().getSIMD(rs, i);
				addin2 = reg().getSIMD(rs, i-4);
				result = addin1+addin2;
				reg().setSIMD(rd,i , result);
				//printf("STEP 2:[%04x]  [%04x] = [%08x]\n", addin1, addin2, result);
			}
			break;
		case 3:
			addin1 = reg().getSIMD(rs, 7);
			addin2 = reg().getSIMD(rs, 15);
			if(instr->shft())
				result = (addin1+addin2)>>1;
			else
				result = addin1+addin2;
			reg().setSIMD(rd, 15, (HWORD)result);
			//printf("STEP 3: [%04x]  [%04x] = [%08x], sh[%01x]\n", addin1, addin2, result,instr->shft());
			break;
		default:
			AppFatal((0), ("ERROR! C2.PSUM16 only supports op_mode 0-3 but not %d!\n", op_mode));
	}

	return pc()+instr->instrsize();
}

ADDR SL2Exec::execC2psum4t1 (SL2Instr* instr) {
	UINT rs1 = instr->rs1_simd();
	UINT rd1 = instr->rd1_simd();
	UINT bk0 = instr->bk0();
	UINT bk1 = instr->bk1();
	UINT bk2 = instr->bk2();
	UINT imm2 = instr->imm2();
	UINT lshft_amnt = instr->lshft_amnt();
	UINT rshft_amnt = instr->rshft_amnt();
	UHWORD wen = instr->wen();

	WORD addin1 = reg().getSIMD(rs1, bk0);
	WORD addin2 = reg().getSIMD(rs1, bk1);
	WORD addin3 = reg().getSIMD(rs1, bk2)<<lshft_amnt;
	WORD result = (addin1+addin2+addin3+imm2)>>rshft_amnt;
	for(INT i=0; i<REG_SIMD_BANK; i++) {
		if((wen&0x1)>0) {
			reg().setSIMD(rd1, i, result);
		}
		wen = wen >> 1;
	}
	//printf("Input, [%04x-%02x], [%04x-%02x], [%04x-%02x], Result [%04x]\n", addin1, bk0,addin2, bk1,reg().getSIMD(rs1, bk2), bk2, result);
	reg().setC2SUM_ACC(result);	
	return pc()+instr->instrsize();
}

ADDR SL2Exec::execC2psum4t2 (SL2Instr* instr) {
	UINT rs1 = instr->rs1_simd();
	UINT rd1 = instr->rd1_simd();
	UINT bk0 = instr->bk0();
	UINT bk1 = instr->bk1();
	UINT bk2 = instr->bk2();
	UINT lshft_amnt = instr->lshft_amnt();
	UINT rshft_amnt = instr->rshft_amnt();
	UHWORD wen = instr->wen();

	WORD addin1 = (WORD)reg().getSIMD(rs1, bk0);
	WORD addin2 = (WORD)reg().getSIMD(rs1, bk1);
	WORD addin3 = (WORD)reg().getSIMD(rs1, bk2)<<lshft_amnt;
	WORD addin4 = reg().getC2SUM_ACC();
	WORD result = (addin1+addin2+addin3+addin4)>>rshft_amnt;
	for(INT i=0; i<REG_SIMD_BANK; i++) {
		if((wen&0x1)>0) {
			reg().setSIMD(rd1, i, result);
		}
		wen = wen >> 1;
	}
	reg().setC2SUM_ACC(result);
	return pc()+instr->instrsize();
}

ADDR SL2Exec::execC2padds (SL2Instr* instr) {
	UINT rs1 = instr->rs1_simd();
	UINT rd1 = instr->rd1_simd();
	UINT bk0 = instr->bk0();
	UINT bk1 = instr->bk1();
	UINT carry = instr->carry();
	UINT shft_amnt = instr->shft_amnt();
	UHWORD wen = instr->wen();

	WORD addin1 = (WORD)reg().getSIMD(rs1, bk0);
	WORD addin2 = (WORD)reg().getSIMD(rs1, bk1);
	WORD result = (addin1+addin2+(WORD)carry)>>shft_amnt;
	for(UINT i=0; i<REG_SIMD_BANK; i++) {
		if((wen&0x1)>0) {
			reg().setSIMD(rd1, i, result);
		}
		wen = wen >> 1;
	}

	return pc()+instr->instrsize();
}

ADDR SL2Exec::execC2pmov (SL2Instr* instr) {
	UINT rs1 = instr->rs1_simd();
	UINT rd1 = instr->rd1_simd();
	UINT bk0 = instr->bk0();
	UHWORD wen = instr->wen();

	HWORD opd = reg().getSIMD(rs1, bk0);	
	for(UINT i = 0; i<REG_SIMD_BANK; i++) {
		if((wen&0x1)>0) {
			reg().setSIMD(rd1, i, opd);
		}
		wen = wen >> 1;		
	}
	return pc()+instr->instrsize();
}

ADDR SL2Exec::execC2pmedc (SL2Instr* instr) {
	INT16 rs1_data = SL2_GETGPR(instr->rs1());
	INT16 rs2_data;
	INT16 rs3_data = SL2_GETGPR(instr->rs3());
	WORD result1 = 0;
	WORD result2 = 0;
	WORD result = 0;
	switch(instr->op_mode()) {
		case 0:
			rs2_data = SL2_GETGPR(instr->rs2());
			result1 = rs1_data>rs2_data?1:0;
			result2 = rs2_data>rs3_data?1:0;
			result = ((result1&0x1)<<2 | (result2&0x1)<<1);
			reg().setC2INT(EC2INT_MED_CMP, result);
			break;
		case 1:
			result1 = result1 = rs1_data>rs3_data?1:0;
			result = (reg().getC2INT(EC2INT_MED_CMP) | result1);
			reg().setC2INT(EC2INT_MED_CMP, result);
			switch (result) {
				case 0:
				case 1:
				case 6:
				case 7:
					SL2_SETGPR(instr->rd(), SL2_GETGPR(instr->rs2()));
					break;
				case 2:
				case 5:
					SL2_SETGPR(instr->rd(), SL2_GETGPR(instr->rs3()));
					break;
				default:
					SL2_SETGPR(instr->rd(), SL2_GETGPR(instr->rs1()));
					break;		
			}
			break;
		default:
			AppFatal((0), ("Exec(execC2pmedc): undefined opd mode (%d).",  instr->op_mode()));
			break;
	}
	return pc()+instr->instrsize();
}

ADDR SL2Exec::execC2psadds (SL2Instr* instr) {
	UINT rs1_data = SL2_GETGPR(instr->rs1());
	UINT rs2_data = SL2_GETGPR(instr->rs2());
	UINT result = (rs1_data + (rs2_data>>2))<<4;
	SL2_SETGPR(instr->rd(), result);

	return pc()+instr->instrsize();
}

ADDR SL2Exec::execC2pspadd (SL2Instr* instr) {
	UINT rs1 = instr->rs1_simd();
	UINT rs2 = instr->rs2_simd();
	UINT rd1 = instr->rd1_simd();
	UINT sl_indx = instr->sl_indx();
	UINT size = instr->size();
	WORD result;

	for(UINT i = 0; i<REG_SIMD_BANK; i++) {
		if(mmu().getSLWen(sl_indx, i)) {
			if(size) {
				result = reg().getSIMDPair(rs1, i) + reg().getSIMDPair(rs2, i);
			//printf("[%08x] + [%08x] = [%08x]\n", reg().getSIMDPair(rs1, i), reg().getSIMDPair(rs2, i), result);
				reg().setSIMDPair(rd1, i, result);
			}
			else {
				result = reg().getSIMD(rs1, i) + reg().getSIMD(rs2, i);
				reg().setSIMD(rd1, i, (HWORD) result);
			}
		}
	}
	return pc()+instr->instrsize();
}


ADDR SL2Exec::execC2pxadd (SL2Instr* instr) {
	UINT rd1 = instr->rd1_simd();
	UINT rs1 = instr->rs1_simd();
	UINT rs2 = instr->rs2_simd();	
	UINT index = instr->sl_indx();  // sl_indx >= 8 && sl_indx <= 12
	UINT   bk;
	UHWORD wen;
	WORD result;

	for(UINT i=0; i<REG_SIMD_BANK; i++) {		
		if(mmu().getSLWen(index, i)==1) {
			bk = mmu().getSLBank(index, i);
			result = reg().getSIMD(rs1, i) + reg().getSIMD(rs2, bk);
			reg().setSIMD(rd1, i, result);
		}
	}
	
	return pc()+instr->instrsize();
}

ADDR SL2Exec::execC2pxsub (SL2Instr* instr) {
	UINT rd1 = instr->rd1_simd();
	UINT rs1 = instr->rs1_simd();
	UINT rs2 = instr->rs2_simd();	
	UINT index = instr->sl_indx();  // sl_indx >= 8 && sl_indx <= 12
	UINT   bk;
	UHWORD wen;
	WORD result;
	
	for(UINT i=0; i<REG_SIMD_BANK; i++) {		
		if(mmu().getSLWen(index, i)==1) {
			bk = mmu().getSLBank(index, i);
			result = reg().getSIMD(rs1, i) - reg().getSIMD(rs2, bk);
			reg().setSIMD(rd1, i, result);
		}
	}
	
	return pc()+instr->instrsize();
}

//PRRET
ADDR SL2Exec::execC2prret (SL2Instr* instr) {
	threadCtrl()->copyReg1_0(instr->rd(), instr->rs1());
	return pc()+instr->instrsize();
}

// BR
ADDR SL2Exec::execC2brf (SL2Instr* instr) {
	ADDR offset = 0;
	ADDR target = 0;
	BOOL cond = reg().getC2SPEC(EC2SPEC_COND);
	if(cond==FALSE) {
		offset = instr->offset()<<OFFSET_SHIFT_BR;
		target = pc() + offset;
	}
	else {
		target = pc() + instr->instrsize();
	}
	LOG_BR((cond==FALSE),offset);
	return pc() + offset;	
}

ADDR SL2Exec::execC2brt (SL2Instr* instr) {
	ADDR offset = 0;
	ADDR target = 0;
	BOOL cond = reg().getC2SPEC(EC2SPEC_COND);
	if(cond==TRUE) {
		offset = instr->offset()<<OFFSET_SHIFT_BR;
		target = pc() + offset;
	}
	else {
		target = pc() + instr->instrsize();
	}
	LOG_BR((cond==TRUE),offset);
	return pc() + offset;			
}

ADDR SL2Exec::execC2fork (SL2Instr* instr) {
	ADDR addr = pc() + (instr->offset()<<OFFSET_SHIFT_BR);
	//	ADDR addr = (instr->offset()<<OFFSET_SHIFT_BR);
	threadCtrl()->fork(status().thread_id(), addr, instr->mjr_fk());
	if(skipFork()==TRUE) {
		instr->rawbits(0);
	}
	return pc() + instr->instrsize();	
}

ADDR SL2Exec::execC2joint (SL2Instr* instr) {
	ADDR addr = pc() + instr->instrsize();	
	if(skipFork()==TRUE) {
		instr->rawbits(0);
	}
	return threadCtrl()->joint(status().thread_id(), addr);
}

// THCTRL
ADDR SL2Exec::execC2thctrl (SL2Instr* instr) {
	threadCtrl()->thctrl(status().thread_id(), instr->thread(), instr->op_mode());
	return pc() + instr->instrsize();		
}


// LS
ADDR SL2Exec::execC2ldVB2GPR (SL2Instr* instr) {
	ADDR rAddr = mmu().accessList()->getAddr(0, RANGE_IDX_VBUF);
	ADDR addr = 0;
	INT macroCnt = instr->macroCnt();
	WORD result = 0;
	INT sign_ext = instr->sign_ext();
	if(instr->imm1()) {
		addr = instr->offset() +  rAddr;
	}
	else {
		addr = reg().getGPR(instr->rs2()) +  rAddr;
	}	
	//printf("Base address is [%08x], offset is [%08x]\n", rAddr, reg().getGPR(instr->rs2()));
	for(INT j = 0; j <macroCnt; j++) {
		switch (instr->size()) {
			case SL2_LS_BYTE: // byte
				if(sign_ext) {
					result = (BYTE) mmu().readVbufByte(addr);
				}
				else {
					result = (UBYTE) mmu().readVbufByte(addr);							
				}
				reg().setGPR(instr->rd(), result);	
				break;					
			case SL2_LS_HWORD: // half word
				if(j==0) {
					result = (UBYTE) mmu().readVbufByte(addr);
				}
				else {
					if(sign_ext) {
						result = ((((HWORD) mmu().readVbufByte(addr))<<INT8_BIT) | result);
					}
					else {
						result = ((((UHWORD) mmu().readVbufByte(addr))<<INT8_BIT) | result);	
					}
					reg().setGPR(instr->rd(), result);				
				}
				break;
			case SL2_LS_WORD:// word
				if((j%INT32_BYTE)==0) {
					result = (UBYTE) mmu().readVbufByte(addr);
				}
				if((j%INT32_BYTE)!=3) {
					result = ((((UBYTE) mmu().readVbufByte(addr))<<(INT8_BIT*(j%INT32_BIT))) | result);
				}				
				else {
					result = (((mmu().readVbufByte(addr))<<(INT8_BIT*(j%INT32_BIT))) | result);
					reg().setGPR(instr->rd(), result);
				}				
				break;
			default:
				AppFatal((0), ("SL2 Exec: invaild C2ld size (%d).", instr->size()));
				break;
		}
		addr += 16; // update		
	}
	return instr->instrsize();
}

ADDR SL2Exec::execC2ldVB2RF (SL2Instr* instr) {
	INT macroCnt = instr->macroCnt();
	c2_ctrl_ls_sw_ctrl lsSwCtrl;
	c2_ctrl_ls_ctrl lsCtrl;
	UINT write_enable;
	lsSwCtrl.word = reg().getC2CTRL(EC2CR_LS_SW);
	ADDR pitch;
	ADDR sys_addr;
	ADDR bank_addr[REG_SIMD_BANK];
	INT sw_mv = instr->sw_mv();
	INT size = instr->size();
	INT h_delta = 0;
	INT v_delta = 0;
	INT bank_index = 0;
	INT window_limit = lsSwCtrl.bits.search_window_size;
	INT temp = 0;
	INT bank4_index[SL2_LOAD_BANK_SIZE];
	WORD result = 0;
	UINT rd1 = instr->rd1_simd();
	UINT rd;
	ADDR addr;
	UINT result_array[REG_SIMD_BANK];

	for(INT j = 0; j <macroCnt; j++) {
		switch (size) {
			case SL2_LS_BYTE:	
				rd = rd1 + j; 
				break;
			case SL2_LS_HWORD:	
				rd = rd1 + (int)j/2; 
			case SL2_LS_WORD:	
				rd = rd1 + (int)j/2; 
				break;
			default:		
				AppFatal((0), ("SL2 Exec: invaild C2ld size (%d).", size));
					break;					
		}

		if(instr->imm1()) {
			if(j==0) {
				ADDR offset = instr->offset();
      			for(INT k=0; k<REG_SIMD_BANK; k++) {
      				bank_addr[k] = offset;
					//buf_addr[k] = (offset&0x7fff) + k + mmu().vbufBase();
      			}
				
			}
			else {
				for(INT k=0; k<REG_SIMD_BANK; k++) {
					bank_addr[k] = bank_addr[k] + INT8_BYTE;
				}
			}			
		}
		else { //indirect
			pitch = lsSwCtrl.bits.search_window_pitch;
			if(j==0) {
				sys_addr = reg().getGPR(instr->rs2());
				if(sw_mv) {
					reg().setC2SPEC(EC2SPEC_MOV_PAT, (sys_addr&0xf));
				}		
			}
			else{
				sys_addr += 16;
			}

			h_delta = (sys_addr&0x3); //h_delta = sys_addr[1:0]
			v_delta = ((sys_addr>>2)&0x3); //v_delta = sys_addr[3:2]
			bank_index = ((sys_addr>>4)&0x7ff); //bank_index = sys_addr[14:4]
			for(INT i = 0; i<SL2_LOAD_BANK_SIZE; i++) {
				bank4_index[i] = bank_index;
			}
			temp = bank_index + pitch;
			
			switch(v_delta) {
				case 0:
					//do nothing
					break;
				case 1:
					bank4_index[0] = (temp>=window_limit)?temp-window_limit:temp;
					break;
				case 2:
					bank4_index[0] = (temp>=window_limit)?temp-window_limit:temp;
					bank4_index[1] = (temp>=window_limit)?temp-window_limit:temp;
					break;
				case 3:
					bank4_index[0] = (temp>=window_limit)?temp-window_limit:temp;
					bank4_index[1] = (temp>=window_limit)?temp-window_limit:temp;
					bank4_index[2] = (temp>=window_limit)?temp-window_limit:temp;
					break;				
				default:
					AppFatal((0), ("SL2 Exec: invaild C2ld v_delta (%d).", v_delta));
					break;	
			}
			for(INT i = 0; i<SL2_LOAD_BANK_SIZE; i++) {
				INT index = (i * SL2_LOAD_BANK_SIZE);
				bank_addr[index] = bank4_index[i];
				bank_addr[index+1] = bank4_index[i];
				bank_addr[index+2] = bank4_index[i];
				bank_addr[index+3] = bank4_index[i];
			}		
		
			switch(h_delta) {
				case 0:
					//do nothing
					break;				
				case 1:
					for(INT i = 0; i<SL2_LOAD_BANK_SIZE; i++) {
						bank_addr[(i*SL2_LOAD_BANK_SIZE)] = bank4_index[i] + 1;
					}					
					break;
				case 2:
					for(INT i = 0; i<SL2_LOAD_BANK_SIZE; i++) {
						INT index = i*SL2_LOAD_BANK_SIZE;
						bank_addr[index] = bank4_index[i] + 1;
						bank_addr[index+1] = bank4_index[i] + 1;
					}						
					break;
				case 3:
					for(INT i = 0; i<SL2_LOAD_BANK_SIZE; i++) {
						INT index = i*SL2_LOAD_BANK_SIZE;
						bank_addr[index] = bank4_index[i] + 1;
						bank_addr[index+1] = bank4_index[i] + 1;
						bank_addr[index+2] = bank4_index[i] + 1;
					}						
					break;				
				default:
					AppFatal((0), ("SL2 Exec: invaild C2ld h_delta (%d).", h_delta));
					break;	
			}
		} //indirect
		lsCtrl.word = reg().getC2CTRL(EC2CR_LS_CTRL);
		write_enable = lsCtrl.bits.rf_vb_write_enable;
		ADDR rAddr = mmu().accessList()->getAddr(0, RANGE_IDX_VBUF);
		ADDR vbufBase = rAddr;
		for(INT n = 0; n<REG_SIMD_BANK; n++) {
			//printf("Write Enable is [%2d]\n", (write_enable&0x1));
			if((write_enable&0x1)>0) {
				addr = (bank_addr[n]*REG_SIMD_BANK) + n + vbufBase;
				//printf("Address for reading is [%08x]\n",addr);
				if(sw_mv||((!sw_mv)&&(size>=2))){ //byte
					if(instr->sign_ext()) {
						result = (BYTE) mmu().readVbufByte(addr);
					}
					else {
						result = (UBYTE) mmu().readVbufByte(addr);
					}
					reg().setSIMD(rd, n, result);
				}
				else {
					switch (size) {
						case SL2_LS_HWORD:
						case SL2_LS_WORD:
							if((j%INT16_BYTE)==0) {
								result_array[n] = mmu().readVbufByte(addr);
							}
							else {
								result = ((mmu().readVbufByte(addr)<<INT8_BIT) | (result_array[n] & 0xFF));
								reg().setSIMD(rd, n, result);
							}
							break;
						default:		
							AppFatal((0), ("SL2 Exec: invaild C2ld size (%d).", size));
							break;				
					}
				}
			}
			write_enable = write_enable >> 1;
		}
	} //loop
	return instr->instrsize();
}

ADDR SL2Exec::execC2ld (SL2Instr* instr) {
	INT macroCnt = 1;
	ADDR addr;
	INT sign_ext;
	WORD result;
	ADDR rAddr;
	INT data_byte = 0;
	switch (instr->size()) {
		case SL2_LS_BYTE: data_byte = INT8_BYTE; break;
		case SL2_LS_HWORD: data_byte = INT16_BYTE; break;
		case SL2_LS_WORD: data_byte = INT32_BYTE; break;
		default:		
			AppFatal((0), ("SL2 Decoder: invaild C2ld size (%d).", instr->size()));
				break;					
	}		
	switch (instr->op_mode()) {
		case 0: //VB -> RF
			if(!instr->sw_mv()&&instr->multi()) {
				c2_ctrl_ls_ctrl lsCtrl;
				lsCtrl.word = reg().getC2CTRL(EC2CR_LS_CTRL);
				macroCnt = (lsCtrl.bits.row_count + 1) * data_byte;
				LOG_META(macroCnt);
			}
			else if(data_byte>INT8_BYTE){
				AppFatal((instr->sw_mv()==0), ("SL2 Exec: invaild data byte size (%d) for sw_mv==1.", data_byte));
				macroCnt *= data_byte;
				LOG_META(macroCnt);
			}
			instr->macroCnt(macroCnt);
			execC2ldVB2RF(instr);
			break;
		case 1: //VB - >GPR
			if(data_byte>INT8_BYTE){
				macroCnt *= data_byte;
				LOG_META(macroCnt);
			}
			instr->macroCnt(macroCnt);
			execC2ldVB2GPR(instr);

			break;
		case 2: //SB->GPR
			// WWD: Synchronize with ISA2.7
			rAddr = mmu().accessList()->getAddr(0, RANGE_IDX_SBUF);
			if(instr->imm1()) {
				addr = instr->offset() + rAddr;
			}
			else {
				addr = reg().getGPR(instr->rs2()) + rAddr;
			}
			sign_ext = instr->sign_ext();
			switch (instr->size()) {
				case SL2_LS_HWORD: // half word
					if(sign_ext) {
						if(instr->swap()) 
							result = (HWORD) mmu().readSbufSwapHword(addr);
						else
							result = (HWORD) mmu().readSbufHword(addr);
					}
					else {
						if(instr->swap()) 
							result = (UHWORD) mmu().readSbufSwapHword(addr);
						else
							result = (UHWORD) mmu().readSbufHword(addr);													
					}
					break;
				case SL2_LS_WORD:// word
					if(instr->swap()) 
						result = mmu().readSbufSwapWord(addr);
					else
						result = mmu().readSbufWord(addr);										
					break;
				default:
					AppFatal((0), ("SL2 Exec: invaild C2ld size (%d).", instr->size()));
					break;
			}
			reg().setGPR(instr->rd(), result);
			break;
		case 3: //SB -> CR
			rAddr = mmu().accessList()->getAddr(0, RANGE_IDX_SBUF);
			addr = instr->offset() + rAddr;
			result = mmu().readSbufWord(addr);
			reg().setC2CTRL(instr->cd(), result);
			break;
		default:		
			AppFatal((0), ("SL2 Exec: invaild C2ld op_mode (%d).", instr->op_mode()));
			return 0;									
		
	}
	return pc() + instr->instrsize();	
}

ADDR SL2Exec::execC2mvgc (SL2Instr* instr) {
	if(instr->dir()) {
		reg().setC2CTRL(instr->cd(), reg().getGPR(instr->rs1()));
	}
	else {
		reg().setGPR(instr->rd(), reg().getC2CTRL(instr->cs1()));
	}
	return pc() + instr->instrsize();			
}

ADDR SL2Exec::execC2mvgr (SL2Instr* instr) {
	UINT rs1;
	UINT rd;
	UINT bank = instr->bank();;
	UINT sign_ext = instr->sign_ext();
	WORD rs1_data;
	WORD rs2_data;
	INT size = instr->size();
	UINT imm_bank = instr->imm1();
	//printf("rd [%02x], rs[%02x], bank[%02x], op_mode[%02x], dir[%01x]\n", instr->rd(), instr->rs1_simd(),instr->bank(), instr->op_mode(), instr->dir());
	if(instr->dir()){ //GPR to RF
		HWORD data0;
		HWORD data1;
		HWORD data2;
		HWORD data3;		
		rs1 = instr->rs1();
		rd = instr->rd1_simd();		
		switch (instr->op_mode()) {
			case 0:
				rs1_data = reg().getGPR(rs1);
				switch (size) {
					case 0:
						reg().setSIMD_ROW(rd, (HWORD)rs1_data);
						break;
					case 1:
						reg().setSIMD_ROW(rd, ((rs1_data>>HWORD_BIT)&0xffff));
						break;
					default:
						reg().setSIMDPair_ROW(rd, rs1_data);
						break;				
				}
				break;
			case 1:
				rs1_data = reg().getGPR(rs1);
				if(!imm_bank)	// Not imm
					bank = reg().getGPR(instr->rs2());
				switch (size) {
					case 0:
						reg().setSIMD(rd, bank, (HWORD)rs1_data, _MVGR);
						break;
					case 1:
						reg().setSIMD(rd, bank, ((rs1_data>>HWORD_BIT)&0xffff), _MVGR);
						break;
					default:
						reg().setSIMDPair(rd, bank, rs1_data, _MVGR);
						break;				
				}
				break;
			case 2:
				sign_ext = instr->sign_ext();
				rs1_data = reg().getGPR(rs1);
				if(sign_ext) {
					data0 =  (BYTE) (rs1_data&BYTE_DATA_MASK);
					data1 =  (BYTE) ((rs1_data>>INT8_BIT)&BYTE_DATA_MASK);
					data2 =  (BYTE) ((rs1_data>>INT16_BIT)&BYTE_DATA_MASK);
					data3 =  (BYTE) ((rs1_data>>(INT8_BIT+INT16_BIT))&BYTE_DATA_MASK);
				}
				else {
					data0 =  (UBYTE) (rs1_data&BYTE_DATA_MASK);
					data1 =  (UBYTE) ((rs1_data>>INT8_BIT)&BYTE_DATA_MASK);
					data2 =  (UBYTE) ((rs1_data>>INT16_BIT)&BYTE_DATA_MASK);
					data3 =  (UBYTE) ((rs1_data>>(INT8_BIT+INT16_BIT))&BYTE_DATA_MASK);					
				}
				if(instr->bc_dir()) {
					reg().setSIMD(rd, 0, data0);
					reg().setSIMD(rd, 4, data0);
					reg().setSIMD(rd, 8, data0);
					reg().setSIMD(rd, 12, data0);
					reg().setSIMD(rd, 1, data1);
					reg().setSIMD(rd, 5, data1);
					reg().setSIMD(rd, 9, data1);
					reg().setSIMD(rd, 13, data1);
					reg().setSIMD(rd, 2, data2);
					reg().setSIMD(rd, 6, data2);
					reg().setSIMD(rd, 10, data2);
					reg().setSIMD(rd, 14, data2);
					reg().setSIMD(rd, 3, data3);
					reg().setSIMD(rd, 7, data3);
					reg().setSIMD(rd, 11, data3);
					reg().setSIMD(rd, 15, data3);															
				}
				else {
					reg().setSIMD(rd, 0, data0);
					reg().setSIMD(rd, 1, data0);
					reg().setSIMD(rd, 2, data0);
					reg().setSIMD(rd, 3, data0);
					reg().setSIMD(rd, 4, data1);
					reg().setSIMD(rd, 5, data1);
					reg().setSIMD(rd, 6, data1);
					reg().setSIMD(rd, 7, data1);
					reg().setSIMD(rd, 8, data2);
					reg().setSIMD(rd, 9, data2);
					reg().setSIMD(rd, 10, data2);
					reg().setSIMD(rd, 11, data2);
					reg().setSIMD(rd, 12, data3);
					reg().setSIMD(rd, 13, data3);
					reg().setSIMD(rd, 14, data3);
					reg().setSIMD(rd, 15, data3);					
				}
				break;
			case 3:
				rs1_data = reg().getGPR(rs1);
				if(!imm_bank)	// Not imm
					bank = reg().getGPR(bank);
				reg().setSIMD(rd, bank, (HWORD)rs1_data, _MVGR);
				reg().setSIMD(rd, bank+1, (HWORD)rs1_data, _MVGR);
				reg().setSIMD(rd, bank+2, (HWORD)rs1_data, _MVGR);
				reg().setSIMD(rd, bank+3, (HWORD)rs1_data, _MVGR);
				break;			
			default:
				AppFatal((0), ("SL2 Exec: invalid C2mvgr mode (%d).", instr->op_mode()));
				break;	
		}
	}
	else { //RF to GPR
		WORD result;
		rs1 = instr->rs1_simd();
		rd = instr->rd();			
		switch (instr->op_mode()) {
			case 0:
				if(size>1) {
					result = reg().getSIMDPair(rs1, bank, _MVGR);
				}
				else {
					if(sign_ext) {
						result = (HWORD) reg().getSIMD(rs1, bank, _MVGR);
					}
					else {
						result = (UHWORD) reg().getSIMD(rs1, bank, _MVGR);
					}
				}
				reg().setGPR(rd, result);
				break;
			case 1:
				rs2_data = reg().getGPR(instr->rs2());
				//rs2_data = (instr->bank());
				if(size>1) {
					result = reg().getSIMDPair(rs1, rs2_data, _MVGR);
				}
				else {
					if(sign_ext) {
						result = (HWORD) reg().getSIMD(rs1, rs2_data, _MVGR);
					}
					else {
						result = (UHWORD) reg().getSIMD(rs1, rs2_data, _MVGR);
					}					
				}
				//printf("Here is GPR [bank%02x], result[%08x]\n", rs2_data, result);

				reg().setGPR(rd, result);
				break;
			default:
				AppFatal((0), ("SL2 Exec: invalid C2mvgr mode (%d).", instr->op_mode()));
				break;	
		}		
	}
	return pc() + instr->instrsize();		
}

ADDR SL2Exec::execC2stGPR2VB (SL2Instr* instr) {
	ADDR rAddr = mmu().accessList()->getAddr(0, RANGE_IDX_VBUF);
	WORD data = reg().getGPR(instr->rs1());
	INT macroCnt = instr->macroCnt();
	ADDR addr = 0;
	
	if(instr->imm1()) {
		addr = instr->offset() + rAddr;
	}
	else {
		addr = reg().getGPR(instr->rs2()) + rAddr;
	}
	for(INT i = 0; i<macroCnt; i++) {
		AppFatal((i<INT32_BYTE), ("SL2 Exec: invaild macro count (%d).", i));
		mmu().writeVbufByte(addr, data);
		data >>= INT8_BIT;
		addr += 16;
	}
	return instr->instrsize();	
}

ADDR SL2Exec::execC2stRF2VB (SL2Instr* instr) {
	INT macroCnt = instr->macroCnt();
	INT size = instr->size();
	UINT rs1 = instr->rs1_simd();
	c2_ctrl_ls_ctrl lsCtrl;
	UINT write_enable;
	UINT rs;
	ADDR addrBase;
	ADDR rAddr = mmu().accessList()->getAddr(0, RANGE_IDX_VBUF);
	//ADDR addr;
	for(INT j = 0; j <macroCnt; j++) {
		switch (size) {
			 case SL2_LS_BYTE:	rs = rs1 + j; break;
			 case SL2_LS_HWORD: 
			 case SL2_LS_WORD: rs = rs1 + (int)j/2; break;
			default:		
				AppFatal((0), ("SL2 Exec: invaild C2st size (%d).", size));
					break;				 	
		}
		if(j==0) {
			if(instr->imm1()) {
				addrBase = (instr->offset()*REG_SIMD_BANK) + rAddr;
			}
			else {
				// WWD, we use 15bits for address ONLY
				///*** Add one assertion for Tangwei
				AppFatal((reg().getGPR(instr->rs2()&0x7fff)<0x8000), ("Invaild address(0x%08x) --Should be offset only(<0x8000).",(reg().getGPR(instr->rs2()&0x7fff) )));
				addrBase = reg().getGPR(instr->rs2()&0x7fff) + rAddr;
			}
		}
		else{
			 addrBase += 16;
		}
		// Here must add one assertion --WWD
		// We need ensure addrbase is 4-word aligned
		AppFatal(((addrBase&0xf)==0), ("Address is not aligned [%08x].", addrBase));
		
		lsCtrl.word = reg().getC2CTRL(EC2CR_LS_CTRL);
		write_enable = lsCtrl.bits.rf_vb_write_enable;
		//addr = (addrBase*REG_SIMD_BANK)+ mmu().vbufBase();
		for(INT n = 0; n<REG_SIMD_BANK; n++) {
			if((write_enable&1)>0) {
				switch (size) {
					 case SL2_LS_BYTE:
					 	mmu().writeVbufByte(addrBase+n, reg().getSIMD(rs, n));
						break;
					 case SL2_LS_HWORD: 
					 	if((j%INT16_BYTE)==0) {
					 		mmu().writeVbufByte(addrBase+n, reg().getSIMD(rs, n));
					 	}
					 	else {
					 		mmu().writeVbufByte(addrBase+n, (reg().getSIMD(rs, n)>>INT8_BIT));
					 	}
						break;
					 case SL2_LS_WORD:
					 	if((j%INT32_BYTE)==0) {
					 		mmu().writeVbufByte(addrBase+n, reg().getSIMD(rs, n));
					 	}
					 	else if((j%INT32_BYTE)==1) {
					 		mmu().writeVbufByte(addrBase+n, (reg().getSIMD(rs, n)>>INT8_BIT));
					 	}
					 	else if((j%INT32_BYTE)==2) {
					 		mmu().writeVbufByte(addrBase+n, reg().getSIMD(rs, n));
					 	}
					 	else {
					 		mmu().writeVbufByte(addrBase+n, (reg().getSIMD(rs, n)>>INT8_BIT));
					 	}
						break;					 
					default:		
						AppFatal((0), ("SL2 Exec: invaild C2st size (%d).", size));
							break;				 	
				}					
			}
			write_enable = write_enable >> 1;
		}
		
	}
	return instr->instrsize();	
}

ADDR SL2Exec::execC2st (SL2Instr* instr) {
	INT macroCnt = 1;
	ADDR addr;
	WORD data;
	ADDR rAddr;
	INT data_byte = 0;
	switch (instr->size()) {
		case SL2_LS_BYTE: data_byte = INT8_BYTE; break;
		case SL2_LS_HWORD: data_byte = INT16_BYTE; break;
		case SL2_LS_WORD: data_byte = INT32_BYTE; break;
		default:		
			AppFatal((0), ("SL2 Decoder: invaild C2ld size (%d).", instr->size()));
				break;					
	}		
		
	switch (instr->op_mode()) {
		case 0: //RF -> VB
			if(instr->multi()) {
				c2_ctrl_ls_ctrl lsCtrl;
				lsCtrl.word = reg().getC2CTRL(EC2CR_LS_CTRL);
				macroCnt = (lsCtrl.bits.row_count + 1) * data_byte;
				LOG_META(macroCnt);
			}
			else if(data_byte>INT8_BYTE){
				macroCnt *= data_byte;
				LOG_META(macroCnt);
			}
			instr->macroCnt(macroCnt);
			execC2stRF2VB(instr);			
			break;
		case 1: //GPR->VB
			if(data_byte>INT8_BYTE){
				macroCnt *= data_byte;
				LOG_META(macroCnt);
			}
			instr->macroCnt(macroCnt);
			execC2stGPR2VB(instr);			
			break;
		case 2: //SB->GPR
			// WWD: Synchronize with ISA2.7
			rAddr = mmu().accessList()->getAddr(0, RANGE_IDX_SBUF);
			if(instr->imm1()) {
				addr = instr->offset() + rAddr;
			}
			else {
				addr = reg().getGPR(instr->rs2()) + rAddr;
			}
			data = reg().getGPR(instr->rs1());
			switch (instr->size()) {
				case SL2_LS_HWORD: // half word
					if(instr->swap()) 
						mmu().writeSbufSwapHword(addr, data);
					else
						mmu().writeSbufHword(addr, data);
					break;
				case SL2_LS_WORD:// word
					if(instr->swap()) 
						mmu().writeSbufSwapWord(addr, data);
					else
						mmu().writeSbufWord(addr, data);
					break;
				default:
					AppFatal((0), ("SL2 Exec: invaild C2st size (%d).", instr->size()));
					break;
			}
			break;
		case 3: //SB -> CR
			rAddr = mmu().accessList()->getAddr(0, RANGE_IDX_SBUF);
			addr = instr->offset() + rAddr;
			data = reg().getC2CTRL(instr->cs1());
			mmu().writeSbufWord(addr, data);
			break;
		default:		
			AppFatal((0), ("SL2 Exec: invaild C2st op_mode (%d).", instr->op_mode()));
			return 0;									
		
	}	
	return pc() + instr->instrsize();	
}

// Macro
ADDR SL2Exec::execC2intra (SL2Instr* instr) {
	AppFatal((instr->macroCnt()>0), ("SL2Exec: Intra macro count <= 0."));
	SL2InstrListIter iter = instr->getMacro()->begin();
	SL2InstrListIter end_iter = instr->getMacro()->end();
	while(iter!=end_iter) {
		(this->*((*iter)->exec()))((*iter));
		iter++;
	}
	return pc() + instr->instrsize();	
}

ADDR SL2Exec::execC2mads (SL2Instr* instr) {
	AppFatal((instr->macroCnt()>0), ("SL2Exec: Intra macro count <= 0."));
	SL2InstrListIter iter = instr->getMacro()->begin();
	SL2InstrListIter end_iter = instr->getMacro()->end();
	//INT i=0;
	while(iter!=end_iter) {
		(this->*((*iter)->exec()))((*iter));
		iter++; 
		//printf("We in macro [mads] now, instructions[%d]!!!\n", i++); 
	}
	return pc() + instr->instrsize();	
}

ADDR SL2Exec::execC2mvsel (SL2Instr* instr) {
	WORD rs1_data;
	WORD rs2_data;
	c2_ctrl_mad_mvsel mad_mvsel;
	HWORD tmp1 = 0;
	HWORD tmp2 = 0;
	WORD bits;
	WORD bitsx;
	WORD bitsy;
	WORD result = 0;
	SL2InstrListIter iter;
	SL2InstrListIter end_iter;

	switch (instr->op_mode()) {
		case 0:
			mad_mvsel.word = reg().getC2CTRL(EC2CR_MVSEL);
			rs1_data = SL2_GETGPR(instr->rs1());
			rs2_data = SL2_GETGPR(instr->rs2());
			tmp1 = rs1_data&HWORD_DATA_MASK;
			tmp2 = rs2_data&HWORD_DATA_MASK;
			result = ((tmp1<<mad_mvsel.bits.scalar_factor)-tmp2)&HWORD_DATA_MASK;

			tmp1 = (rs1_data>>HWORD_BIT)&HWORD_DATA_MASK;
			tmp2 = (rs2_data>>HWORD_BIT)&HWORD_DATA_MASK;
						
			result |= ((((tmp1<<mad_mvsel.bits.scalar_factor)-tmp2)&HWORD_DATA_MASK)<<HWORD_BIT);
			
			reg().setC2SPEC(EC2SPEC_BITS, result);
			if(reg().getC2SPEC(EC2SPEC_START)) {
				reg().setC2SPEC(EC2SPEC_START, 0);
				reg().setC2SPEC(EC2SPEC_BEST_COST, 0xffff);
			}
			break;
		case 1:
			bits = reg().getC2SPEC(EC2SPEC_BITS);
			tmp1 = bits&HWORD_DATA_MASK;
			tmp2 = ((bits>>HWORD_BIT)&HWORD_DATA_MASK);
			tmp1 = Abs(tmp1);
			tmp2 = Abs(tmp2);
//			printf("bits=%x, x=%d y=%d\n", bits, tmp1, tmp2);
			bitsx = motionBitCost(tmp1);
			bitsy = motionBitCost(tmp2);
			result = bitsx + bitsy;
			reg().setC2SPEC(EC2SPEC_BITS, result);
			break;
		case 2:
			AppFatal((instr->macroCnt()>0), ("SL2Exec: Intra macro count <= 0."));
			iter = instr->getMacro()->begin();
			end_iter = instr->getMacro()->end();
			while(iter!=end_iter) {
				(this->*((*iter)->exec()))((*iter));
				iter++;
			}
			break;
		case 3:
			result = reg().getC2SPEC(EC2SPEC_BEST_MV);
			SL2_SETGPR(instr->rd(), result);
			break;			
		case 4:
			result = reg().getC2SPEC(EC2SPEC_BEST_SAD);
			SL2_SETGPR(instr->rd(), result);
			break;
		case 5:
			result = reg().getC2SPEC(EC2SPEC_BEST_COST);
			SL2_SETGPR(instr->rd(), result);
			reg().setC2SPEC(EC2SPEC_START, 1);
			break;		
		case 6:
			mad_mvsel.word = reg().getC2CTRL(EC2CR_MVSEL);
			bits = reg().getC2SPEC(EC2SPEC_BITS);
			result = ((mad_mvsel.bits.lambda_factor*bits)>>8);
			reg().setC2SPEC(EC2SPEC_MV_COST, result);
			break;
		case 7:
			rs2_data = SL2_GETGPR(instr->rs2());
			result = reg().getC2SPEC(EC2SPEC_MV_COST) + rs2_data;
			if(result<reg().getC2SPEC(EC2SPEC_BEST_COST)) {
				reg().setC2SPEC(EC2SPEC_BEST_COST, result);
				reg().setC2SPEC(EC2SPEC_BEST_SAD, (rs2_data&HWORD_DATA_MASK));
				reg().setC2SPEC(EC2SPEC_BEST_MV, SL2_GETGPR(instr->rs1()));
			}
			break;				
		default:
			AppFatal((0), ("SL2 Exec: invalid C2mvsel mode (%d).", instr->op_mode()));
			break;	
	}

	return pc() + instr->instrsize();		
}

ADDR SL2Exec::execC2satd_old (SL2Instr* instr) {
	AppFatal((instr->macroCnt()>0), ("SL2Exec: SATD macro count <= 0."));
	SL2InstrListIter iter = instr->getMacro()->begin();
	SL2InstrListIter end_iter = instr->getMacro()->end();
	while(iter!=end_iter) {
		(this->*((*iter)->exec()))((*iter));
		iter++;
	}	
	return pc() + instr->instrsize();	
}

ADDR SL2Exec::execC2satd(SL2Instr* instr) {
	AppFatal((instr->macroCnt()>0), ("SL2Exec: SATD macro count <= 0."));
	SL2InstrListIter iter = instr->getMacro()->begin();
	SL2InstrListIter end_iter = instr->getMacro()->end();
	while(iter!=end_iter) {
		(this->*((*iter)->exec()))((*iter));
		iter++;
	}	
	return pc() + instr->instrsize();	
}

ADDR SL2Exec::execC2smads (SL2Instr* instr) {
	AppFatal((instr->macroCnt()>0), ("SL2Exec: SATD macro count <= 0."));
	SL2InstrListIter iter = instr->getMacro()->begin();
	SL2InstrListIter end_iter = instr->getMacro()->end();
	while(iter!=end_iter) {
		(this->*((*iter)->exec()))((*iter));
		iter++;
	}	
	return pc() + instr->instrsize();	
}

ADDR SL2Exec::execC2vsad_old (SL2Instr* instr) {
	AppFatal((instr->macroCnt()>0), ("SL2Exec: VSAD macro count <= 0."));
	SL2InstrListIter iter = instr->getMacro()->begin();
	SL2InstrListIter end_iter = instr->getMacro()->end();
	while(iter!=end_iter) {
		(this->*((*iter)->exec()))((*iter));
		iter++;
	}	
	return pc() + instr->instrsize();
}

ADDR SL2Exec::execC2vsad (SL2Instr* instr) {
	AppFatal((instr->macroCnt()>0), ("SL2Exec: VSAD macro count <= 0."));
	SL2InstrListIter iter = instr->getMacro()->begin();
	SL2InstrListIter end_iter = instr->getMacro()->end();
	while(iter!=end_iter) {
		(this->*((*iter)->exec()))((*iter));
		iter++;
	}	
	return pc() + instr->instrsize();
}


ADDR SL2Exec::execC2vspel (SL2Instr* instr) {
	INT rd1 = instr->rd1_simd();
	INT size = instr->size();
	INT cl_indx = instr->cl_indx();
	INT sl_indx = instr->sl_indx();

	INT bk;
	INT rw;
	WORD result;
	WORD constant;
	WORD addin2;

	switch(instr->op_mode()) {
		case 0:
			constant = mmu().getCL(cl_indx);
			for(INT i=0; i<REG_SIMD_BANK; i++) {
				if(mmu().getSLWen(sl_indx, i)==1) {
					bk = mmu().getSLBank(sl_indx, i);
					rw = mmu().getSLRow(sl_indx, i);
					result = reg().getSIMD(rw, bk) * constant;
					LOG_META(rw+1)
					if(size) {
						//printf(" [%08x] * [%08x] = [%08x]\n", reg().getSIMD(rw, bk), constant, result);
						reg().setSIMDPair(rd1, i, result);
					}
					else {
						reg().setSIMD(rd1, i, (HWORD)result);
					}
					//reg().setSIMD_ACC(i, result);
				}
			}
			break;
		case 1:
			for(INT i=0; i<REG_SIMD_BANK; i++) {
				if(mmu().getSLWen(sl_indx, i)==1) {

					addin2 = reg().getSIMD(instr->rs1_simd(), i);					
					bk = mmu().getSLBank(sl_indx, i);
					rw = mmu().getSLRow(sl_indx, i);
					result = (reg().getSIMD(rw, bk) + addin2 +1) >>1;
					LOG_META(rw+1)
					if(instr->size()) {
						reg().setSIMDPair(rd1, i, result);
					}
					else {
						reg().setSIMD(rd1, i, (HWORD)result);
					}					
					//reg().setSIMD_ACC(i, result);
				}
			}
			break;
		default:
			AppFatal((0), ("SL2 Exec: invaild C2vspel op_mode (%d).", instr->op_mode()));
			break;			
	}
	return pc()+instr->instrsize();
}

ADDR SL2Exec::execC2vspmac (SL2Instr* instr) {
	AppFatal((instr->macroCnt()>0), ("SL2Exec: VSPMAC macro count <= 0."));
	SL2InstrListIter iter = instr->getMacro()->begin();
	SL2InstrListIter end_iter = instr->getMacro()->end();
	while(iter!=end_iter) {
		(this->*((*iter)->exec()))((*iter));
		iter++;
	}	
	return pc() + instr->instrsize();	
}


// VMULT
ADDR SL2Exec::execC2mmul (SL2Instr* instr) {
	INT rd1 = instr->rd1_simd();
	INT rs1 = instr->rs1_simd();
	INT rs2 = instr->rs2_simd();
	INT sl_indx = instr->sl_indx();
	INT size = instr->size();

	UBYTE bk;
	UBYTE shft;
	HWORD op1;
	HWORD op2;
	WORD result[REG_SIMD_BANK];
	
	switch(instr->op_mode()) {
		case 0:
			for(INT i=0; i<REG_SIMD_BANK; i++) {
				bk = mmu().getSLBank(sl_indx, i);
				op1 = reg().getSIMD(rs1, (i%4)*4);
				op2 = reg().getSIMD(rs2, bk);
				result[i] = op1 * op2;
			}
			break;
		case 1:
			for(INT i=0; i<REG_SIMD_BANK; i++) {
				bk = mmu().getSLBank(sl_indx, i);
				op1 = reg().getSIMD(rs1, (i%4)*4+1);
				op2 = reg().getSIMD(rs2, bk);
				result[i] = op1 * op2;
			}	
			break;
		case 2:
			for(UINT i=0; i<REG_SIMD_BANK; i++) {
				bk = mmu().getSLBank(sl_indx, i);
				shft = mmu().getSLWen(sl_indx, i);
				op1 = reg().getSIMD(rs1, (i%4)*4+1);
				op2 = reg().getSIMD(rs2, bk);
				if(shft==1) {
					result[i] = (op1>>1) * op2;
				}
				else {
					result[i] =  op1 * op2;
				}
			}
			break;
		case 3:
			for(UINT i=0; i<REG_SIMD_BANK; i++) {
				bk = mmu().getSLBank(sl_indx, i);
				shft = mmu().getSLWen(sl_indx, i);
				op1 = reg().getSIMD(rs1, (i%4)*4+1);
				op2 = reg().getSIMD(rs2, bk);
				///*** use >>1 in wrong branch
				if(shft==1) {
					result[i] = op1 * (op2>>1);
				}
				else {
					result[i] = op1 * (op2);
				}
			}
			break;
		case 4:
			for(UINT i=0; i<REG_SIMD_BANK; i++) {
				bk = mmu().getSLBank(sl_indx, i);
				op1 = reg().getSIMD(rs1, (i%4)*4+2);
				op2 = reg().getSIMD(rs2, bk);
				result[i] = op1 * op2 ;
			}
			break;
		case 5:
			for(INT i = 0; i<REG_SIMD_BANK; i++) {
				bk = mmu().getSLBank(sl_indx, i);
				op1 = reg().getSIMD(rs1, (i%4)*4+3),
				op2 = reg().getSIMD(rs2, bk);
				result[i] = op1 *op2;
			}
			break;	
		case 6:
			for(INT i = 0; i<REG_SIMD_BANK; i++) {
				bk = mmu().getSLBank(sl_indx, i);
				shft = mmu().getSLWen(sl_indx, i);
				if(shft==1)
					op1 = reg().getSIMD(rs1, (i%4)*4+3)>>1;
				else
					op1 = reg().getSIMD(rs1, (i%4)*4+3);
				op2 = reg().getSIMD(rs2, bk);
				result[i] = op1 * op2;
			}
			break;
		case 7:
			for(UINT i = 0; i<REG_SIMD_BANK; i++) {
				bk = mmu().getSLBank(sl_indx, i);
				shft = mmu().getSLWen(sl_indx, i);
				op1 = reg().getSIMD(rs1, (i%4)*4+3);
				if(shft==1)
					op2 = reg().getSIMD(rs2, bk)>>1;
				else
					op2 = reg().getSIMD(rs2, bk);
				result[i] = op1 * op2;
			}
			break;					
		default:
			AppFatal((0), ("SL2 Exec: inavild C2mmuls123 (%d).", instr->op_mode()));
			break;
	}
	for(INT i = 0; i<REG_SIMD_BANK; i++) {
		//reg().setSIMD_ACC(i, result[i]);
		if(size) {
			reg().setSIMDPair(rd1, i, result[i]);
		}
		else {
			reg().setSIMD(rd1, i, result[i]);
		}
	}
	return pc() + instr->instrsize();
}

ADDR SL2Exec::execC2vcopy (SL2Instr* instr) {
	UINT rd1 = instr->rd1_simd();
	UINT rs2 = instr->rs2_simd();


	for(INT i=0 ; i<REG_SIMD_BANK; i++)
	{
		reg().setSIMD(rd1, i, reg().getSIMD(rs2,i));		
	}
	return pc() + instr->instrsize();
}

ADDR SL2Exec::execC2vmov (SL2Instr* instr) {
	INT rd1 = instr->rd1_simd();
	INT rs2 = instr->rs2_simd();
	HWORD tmp[REG_SIMD_BANK];
	UINT reverse_lut[4] = {0, 3, 2, 1};
	UINT index, y, x, pat;
	INT bk;
	if(instr->mov_pat()==1) {
		pat = reg().getC2SPEC(EC2SPEC_MOV_PAT);
		if (instr->rev_pat()==1)
		{
			y = (pat & 0xC)>>2;
			x = pat & 0x3;
			pat = ((reverse_lut[y]<<2) + reverse_lut[x]) & 0xF;
		}
		index = (0x2<<4)|pat;
	}
	else {
		index = instr->sl_indx();  // sl_indx >= 32 && sl_indx <= 127
	}
	//printf("RS2 = [%08x]\n", rs2);

	for(INT i = 0; i<REG_SIMD_BANK; i++) {
		bk = mmu().getSLBank(index, i);
		tmp[i] = reg().getSIMD(rs2, bk);

	}
	for(INT i = 0; i<REG_SIMD_BANK; i++) {
		if(mmu().getSLWen(index, i)==1) {
			reg().setSIMD(rd1, i, tmp[i]);
		}		
	}

	return pc()+instr->instrsize();	
}

ADDR SL2Exec::execC2vmul (SL2Instr* instr) {
	UINT rd1 = instr->rd1_simd();
	UINT rs1 = instr->rs1_simd();
	UINT rs2 = instr->rs2_simd();
	UINT size = instr->size();

	WORD rslt;

	for(INT i=0 ; i<REG_SIMD_BANK ; i++)
	{
		rslt = (reg().getSIMD(rs1,i) * reg().getSIMD(rs2,i));

		if (size)
		{//word result
			reg().setSIMDPair(rd1,i, rslt);
		}
		else {//half result
			reg().setSIMD(rd1,i, (HWORD)rslt);
		}
		//reg().setSIMD_ACC(i, rslt);
	}
	return pc() + instr->instrsize();
}


// VADD
ADDR SL2Exec::execC2lczero (SL2Instr* instr) {
	WORD rs1 = instr->rs1_simd();
	WORD rd = instr->rd1_simd();
	WORD cnt=0, bank;

	if(instr->zero()) {
		for(INT i=0 ; i<REG_SIMD_BANK; i++)
		{
			if(reg().getSIMD(rs1, i)==0)
			{
				cnt++;
				bank = i;
			}
		}
	}
	else {
		if(instr->dir()) {
			for(INT i=0 ; i<REG_SIMD_BANK; i++)
			{
				if(reg().getSIMD(rs1, i)!=0)
				{
					cnt++;
					bank = i;
					break;
				}
			}		
		}
		else {
			for(INT i=(REG_SIMD_BANK-1) ; i>=0; i--)
			{
				if(reg().getSIMD(rs1, i)!=0)
				{
					cnt++;
					bank = i;
					break;
				}
			}		
		}
	}
	
	for(INT i=0 ; i<REG_SIMD_BANK ; i++)
	{
		WORD result;
		if(cnt==1)
			result = bank;
		else if(cnt==0)
			result = 0xFFF0;
		else
			result = 0xFFFF;
		reg().setSIMD(rd, i, result);	
		//reg().setSIMD_ACC(i, result);	
	}
	return pc() + instr->instrsize();	
}

ADDR SL2Exec::execC2vadds (SL2Instr* instr) {
	UINT rd = instr->rd1_simd();
	UINT rs1 = instr->rs1_simd();
	UINT rs2 = instr->rs2_simd();

	WORD shft_op1 = instr->shft_mode() & 1;
	WORD shft_op2 = instr->shft_mode() & 2;
	WORD shft_mask = 3, shft_amnt;
	HWORD UpHalf, LwHalf;
	WORD rslt;

	UINT carry = instr->carry();
	UINT size  = instr->size();
	UINT in_pair = instr->in_pair();

	for(INT i=0 ; i<REG_SIMD_BANK ; i++)
	{
		//if(shft_op2)
		//	shft_amnt = (UINT)(reg().getC2CTRL(EC2CR_VADD_SHFT) & shft_mask) >> (2*i);
		//else
		//	shft_amnt = shft_op1;

		///*** Add by WWD in 20070123
		if(instr->shft_mode() & 0x4)
		{//DC and AC shft_amnt are different
			if(i==0)
			{
				// DC
				if(shft_op2)
					shft_amnt = (reg().getC2CTRL(EC2CR_DCAC_SHFT)) & 0x1F;
				else
					shft_amnt = shft_op1;
			}
			else
			{
				// AC
				if(shft_op2)
					shft_amnt = (reg().getC2CTRL(EC2CR_DCAC_SHFT) >> 8) & 0x1F;
				else
					shft_amnt = shft_op1;
			}
		}
		else
		{
			if(shft_op2)
				shft_amnt = (UINT)(reg().getC2CTRL(EC2CR_VADD_SHFT) & shft_mask) >> (2*i);
			else
				shft_amnt = shft_op1;
		}


		if(in_pair)
		{
			UpHalf = (reg().getSIMD(rs1+1, i) + reg().getSIMD(rs2+1, i) +carry);
			LwHalf = (reg().getSIMD(rs1  , i) + reg().getSIMD(rs2  , i) +carry);

			UpHalf = (UpHalf >> shft_amnt);
			LwHalf = (LwHalf >> shft_amnt);
			
			rslt = (((UpHalf&HWORD_DATA_MASK)<<INT16_BIT)|(LwHalf&HWORD_DATA_MASK));
			reg().setSIMDPair(rd, i, rslt);

			//udpate simd_acc --WORD
			//reg().setSIMD_ACC(i, rslt);
		}
		else if (size)
		{//word		
			rslt = (reg().getSIMDPair(rs1, i) + reg().getSIMDPair(rs2, i) + carry) >> shft_amnt;
			//printf(" ([%08x] + [%08x] + [%01x]) >> [%02x] = [%08x]\n", reg().getSIMDPair(rs1, i), reg().getSIMDPair(rs2, i), carry, shft_amnt, rslt);

			reg().setSIMDPair(rd, i, rslt);
			//udpate simd_acc -- WORD
			//reg().setSIMD_ACC(i, rslt);
		}
		else
		{
			LwHalf = (reg().getSIMD(rs1  , i) + reg().getSIMD(rs2  , i) +carry) >> shft_amnt;
			reg().setSIMD(rd, i, LwHalf);

			//udpate simd_acc
			//reg().setSIMD_ACC(i, LwHalf);
		}

		shft_mask <<= 2;
	}
	return pc() + instr->instrsize();
}

ADDR SL2Exec::execC2vclg (SL2Instr* instr) {
	UINT rd1 = instr->rd1_simd();
	UINT rs1 = instr->rs1_simd();
	UINT rs2 = instr->rs2_simd();
	HWORD UpHalf, LwHalf, rslt, rslt2;

	UINT size    = instr->size();
	UINT in_pair = instr->in_pair();
	UINT op_mode = instr->op_mode();

	for(INT i=0 ; i<REG_SIMD_BANK; i++)
	{
		if(in_pair)
		{
			UpHalf = reg().getSIMD(rs1+1, i);
			LwHalf = reg().getSIMD(rs1  , i);

			switch(op_mode)
			{

			// Delete this from ISA2.6
#if 0
			case 0x0: //LT AND
				rslt = (UpHalf<0 && LwHalf<0) ? 1 : 0;
				reg().setSIMD(rd1,i, rslt);
			        //reg().setSIMD_ACC(i, rslt);
				break;

			case 0x1: // LT OR
				rslt = (UpHalf<0 || LwHalf<0) ? 1 : 0;
				reg().setSIMD(rd1,i, rslt);
			        //reg().setSIMD_ACC(i, rslt);
				break;

			case 0x2: // LE AND
				rslt = (UpHalf<=0 && LwHalf<=0) ? 1 : 0;
				reg().setSIMD(rd1,i, rslt);
			        //reg().setSIMD_ACC(i, rslt);
				break;

			case 0x3: // LE OR
				rslt = (UpHalf<=0 || LwHalf<=0) ? 1 : 0;
				reg().setSIMD(rd1,i, rslt);
			        //reg().setSIMD_ACC(i, rslt);
				break;

			case 0x4: // EQ AND
				rslt = (UpHalf==0 && LwHalf==0) ? 1 : 0;
				reg().setSIMD(rd1,i, rslt);
			        //reg().setSIMD_ACC(i, rslt);
				break;

			case 0x5: // EQ OR
				rslt = (UpHalf==0 || LwHalf==0) ? 1 : 0;
				reg().setSIMD(rd1,i, rslt);
			        //reg().setSIMD_ACC(i, rslt);
				break;

			case 0x6: // GE AND
				rslt = (UpHalf>=0 && LwHalf>=0) ? 1 : 0;
				reg().setSIMD(rd1,i, rslt);
			        //reg().setSIMD_ACC(i, rslt);
				break;

			case 0x7: // GE OR
				rslt = (UpHalf>=0 || LwHalf>=0) ? 1 : 0;
				reg().setSIMD(rd1,i, rslt);
			        //reg().setSIMD_ACC(i, rslt);
				break;

			case 0x8: // GT AND
				rslt = (UpHalf>0 && LwHalf>0) ? 1 : 0;
				reg().setSIMD(rd1,i, rslt);
			        //reg().setSIMD_ACC(i, rslt);
				break;

			case 0x9: // GT OR
				rslt = (UpHalf>0 || LwHalf>0) ? 1 : 0;
				reg().setSIMD(rd1,i, rslt);
			        //reg().setSIMD_ACC(i, rslt);
				break;

			case 0xa: // AND
				rslt = (UpHalf && LwHalf) ? 1 : 0;
				reg().setSIMD(rd1,i, rslt);
			        //reg().setSIMD_ACC(i, rslt);
				break;

			case 0xb: // OR
				rslt = (UpHalf || LwHalf) ? 1 : 0;
				reg().setSIMD(rd1,i, rslt);
			        //reg().setSIMD_ACC(i, rslt);
				break;
#endif
			case 0xc: // LE
				rslt = (UpHalf<=0) ? 1 : 0;
				reg().setSIMD(rd1+1,i, rslt);

				rslt2 = (LwHalf<=0) ? 1 : 0;
				reg().setSIMD(rd1,i, rslt2);
			        //reg().setSIMD_ACC(i, rslt<<16|rslt2);
				break;

			case 0xd: // EQ
				rslt = (UpHalf==0) ? 1 : 0;
				reg().setSIMD(rd1+1,i, rslt);

				rslt2 = (LwHalf==0) ? 1 : 0;
				reg().setSIMD(rd1,i, rslt2);
			        //reg().setSIMD_ACC(i, rslt<<16|rslt2);
				break;

			case 0xe: // GE
				rslt = (UpHalf>=0) ? 1 : 0;
				reg().setSIMD(rd1+1,i, rslt);

				rslt2 = (LwHalf>=0) ? 1 : 0; 
				reg().setSIMD(rd1,i, rslt2);
			        //reg().setSIMD_ACC(i, rslt<<16|rslt2);
				break;

			case 0xf: // GT
				rslt = (UpHalf>0) ? 1 : 0;
				reg().setSIMD(rd1+1,i, rslt);

				rslt2 = (LwHalf>0) ? 1 : 0;
				reg().setSIMD(rd1,i, rslt2);
			    //reg().setSIMD_ACC(i, rslt<<16|rslt2);
				break;
			}
		}
		else if (size)
		{//word
			switch(op_mode)
			{
			case 0x0: // LT AND
				rslt = (reg().getSIMDPair(rs1,i)<0 && reg().getSIMDPair(rs2,i)<0) ? 1 : 0;
				break;

			case 0x1: // LT OR
				rslt = (reg().getSIMDPair(rs1,i)<0 || reg().getSIMDPair(rs2,i)<0) ? 1 : 0;
				break;

			case 0x2: // LE AND
				rslt = (reg().getSIMDPair(rs1,i)<=0 && reg().getSIMDPair(rs2,i)<=0) ? 1 : 0;
				break;

			case 0x3: // LE OR
				rslt = (reg().getSIMDPair(rs1,i)<=0 || reg().getSIMDPair(rs2,i)<=0) ? 1 : 0;
				break;

			case 0x4: // EQ AND
				rslt = (reg().getSIMDPair(rs1,i)==0 && reg().getSIMDPair(rs2,i)==0) ? 1 : 0;
				break;

			case 0x5: // EQ OR
				rslt = (reg().getSIMDPair(rs1,i)==0 || reg().getSIMDPair(rs2,i)==0) ? 1 : 0;
				break;

			case 0x6: // GE AND
				rslt = (reg().getSIMDPair(rs1,i)>=0 && reg().getSIMDPair(rs2,i)>=0) ? 1 : 0;
				break;

			case 0x7: // GE OR
				rslt = (reg().getSIMDPair(rs1,i)>=0 || reg().getSIMDPair(rs2,i)>=0) ? 1 : 0;
				break;

			case 0x8: // GT AND
				rslt = (reg().getSIMDPair(rs1,i)>0 && reg().getSIMDPair(rs2,i)>0) ? 1 : 0;
				break;

			case 0x9: // GT OR
				rslt = (reg().getSIMDPair(rs1,i)>0 || reg().getSIMDPair(rs2,i)>0) ? 1 : 0;
				break;

			case 0xa: // AND
				rslt = (reg().getSIMDPair(rs1,i) && reg().getSIMDPair(rs2,i)) ? 1 : 0;
				break;

			case 0xb: // OR
				rslt = (reg().getSIMDPair(rs1,i) || reg().getSIMDPair(rs2,i)) ? 1 : 0;
				break;

			case 0xc: // LE
				rslt = (reg().getSIMDPair(rs1,i)<=0) ? 1 : 0;
				break;

			case 0xd: // EQ
				rslt = (reg().getSIMDPair(rs1,i)==0) ? 1 : 0;
				break;

			case 0xe: // GE
				rslt = (reg().getSIMDPair(rs1,i)>=0) ? 1 : 0;
				break;

			case 0xf: // GT
				rslt = (reg().getSIMDPair(rs1,i)>0) ? 1 : 0;
				break;
			}
			reg().setSIMD(rd1,i, rslt);
			//reg().setSIMD_ACC(i, rslt);
		}
		else
		{//half
			switch(op_mode)
			{
			case 0x0: // LT AND
				rslt = (reg().getSIMD(rs1,i)<0 && reg().getSIMD(rs2,i)<0) ? 1 : 0;
				break;

			case 0x1: // LT OR
				rslt = (reg().getSIMD(rs1,i)<0 || reg().getSIMD(rs2,i)<0) ? 1 : 0;
				break;

			case 0x2: // LE AND
				rslt = (reg().getSIMD(rs1,i)<=0 && reg().getSIMD(rs2,i)<=0) ? 1 : 0;
				break;

			case 0x3: // LE OR
				rslt = (reg().getSIMD(rs1,i)<=0 || reg().getSIMD(rs2,i)<=0) ? 1 : 0;
				break;

			case 0x4: // EQ AND
				rslt = (reg().getSIMD(rs1,i)==0 && reg().getSIMD(rs2,i)==0) ? 1 : 0;
				break;

			case 0x5: // EQ OR
				rslt = (reg().getSIMD(rs1,i)==0 || reg().getSIMD(rs2,i)==0) ? 1 : 0;
				break;

			case 0x6: // GE AND
				rslt = (reg().getSIMD(rs1,i)>=0 && reg().getSIMD(rs2,i)>=0) ? 1 : 0;
				break;

			case 0x7: // GE OR
				rslt = (reg().getSIMD(rs1,i)>=0 || reg().getSIMD(rs2,i)>=0) ? 1 : 0;
				break;

			case 0x8: // GT AND
				rslt = (reg().getSIMD(rs1,i)>0 && reg().getSIMD(rs2,i)>0) ? 1 : 0;
				break;

			case 0x9: // GT OR
				rslt = (reg().getSIMD(rs1,i)>0 || reg().getSIMD(rs2,i)>0) ? 1 : 0;
				break;

			case 0xa: // AND
				rslt = (reg().getSIMD(rs1,i) && reg().getSIMD(rs2,i)) ? 1 : 0;
				break;

			case 0xb: // OR
				rslt = (reg().getSIMD(rs1,i) || reg().getSIMD(rs2,i)) ? 1 : 0;
				break;

			case 0xc: // LE
				rslt = (reg().getSIMD(rs1,i)<=0) ? 1 : 0;
				break;

			case 0xd: // EQ
				rslt = (reg().getSIMD(rs1,i)==0) ? 1 : 0;
				break;

			case 0xe: // GE
				rslt = (reg().getSIMD(rs1,i)>=0) ? 1 : 0;
				break;

			case 0xf: // GT
				rslt = (reg().getSIMD(rs1,i)>0) ? 1 : 0;
				break;
			}
			reg().setSIMD(rd1,i, rslt);
			//reg().setSIMD_ACC(i, rslt);
		}
	}
	return pc() + instr->instrsize();
}

ADDR SL2Exec::execC2vclp (SL2Instr* instr) {
	UINT rd1 = instr->rd1_simd();
	UINT rs1 = instr->rs1_simd();
	UINT rs2 = instr->rs2_simd();
	HWORD UpHalf, LwHalf, rslt;

	UINT in_pair = instr->in_pair();
	UINT op_mode = instr->op_mode();
	WORD result;

	for(INT i=0 ; i<REG_SIMD_BANK; i++)
	{
		switch (op_mode)
		{
			case 0://clamp rs1 in (0,255)
				LwHalf = reg().getSIMD(rs1,i);
				LwHalf = Max(0, Min(255, LwHalf));
				reg().setSIMD(rd1,i, LwHalf);
	
				if (in_pair)
				{//pairwise clamp rs1+1 in (0,255)
					UpHalf = reg().getSIMD(rs1+1,i);
					UpHalf = Max(0, Min(255, UpHalf));
					result = (((UpHalf&HWORD_DATA_MASK)<<INT16_BIT)|(LwHalf&HWORD_DATA_MASK));
					reg().setSIMD(rd1 ,i, LwHalf);
					reg().setSIMD(rd1+1 ,i, UpHalf);
				}
				else {
					result = LwHalf;
					reg().setSIMD(rd1 ,i, result);
				}
				break;
	
			case 1://clamp rs1+rs2 in (0,255)
				LwHalf = reg().getSIMD(rs1,i) + reg().getSIMD(rs2,i);  // It is safe for use HWORD as result --WWD
				LwHalf = Max(0, Min(255, LwHalf));
				reg().setSIMD(rd1,i, LwHalf);
				break;
	
			case 2://clamp rs1-rs2 in (0,255)
				LwHalf = reg().getSIMD(rs1,i) - reg().getSIMD(rs2,i);
				LwHalf = Max(0, Min(255, LwHalf));
				reg().setSIMD(rd1,i, LwHalf);
				break;
	
			case 3://clamp rd1 in (rs1, rs2)  --- Revised in ISA2.7 clamp rd1 in (rs2, rs1) 
				LwHalf = reg().getSIMD(rs2,i);
				UpHalf = reg().getSIMD(rs1,i);
				rslt = reg().getSIMD(rd1,i);
				rslt = Max(LwHalf, Min(UpHalf, rslt));
				reg().setSIMD(rd1,i, rslt);
				break;
	
			case 4://clamp rs1 in (-rs2, rs2)  --- Revised in ISA2.7  clamp rs2 in (-rs1, rs1)
				UpHalf = reg().getSIMD(rs1,i);
	
				rslt = reg().getSIMD(rs2,i);
				rslt = Max(-UpHalf, Min(UpHalf, rslt));
				reg().setSIMD(rd1,i, rslt);
				break;
			default:
				AppFatal((0), ("SL2 Exec: invalid C2vclp mode (%d).", op_mode));
				break;
		}
	}
	return pc() + instr->instrsize();
}

ADDR SL2Exec::execC2vcmov (SL2Instr* instr) {
	UINT rd1 = instr->rd1_simd();
	UINT rs1 = instr->rs1_simd();
	UINT rs2 = instr->rs2_simd();
	WORD rslt,rslt_bit;

	UINT size = instr->size();
	HWORD cmp_bit = instr->cmp_bit();

	for(INT i=0 ; i<REG_SIMD_BANK; i++)
	{
		rslt_bit = reg().getSIMD(rs1,i);
		if(size==1) {
			rslt = reg().getSIMDPair(rs2 , i);
			if (rslt_bit == cmp_bit)
			{
				reg().setSIMDPair(rd1, i, rslt);
			}
		}
		else {
			rslt = reg().getSIMD(rs2,i);
			if (rslt_bit == cmp_bit)
			{
				reg().setSIMD(rd1, i, (HWORD)rslt);
			}
		}
		//reg().setSIMD_ACC(i, rslt); // Update ACC always and use rs2!!
		
	}
	return pc() + instr->instrsize();
}

ADDR SL2Exec::execC2vcmpr (SL2Instr* instr) {	
	UINT rd1 = instr->rd1_simd();
	UINT rs1 = instr->rs1_simd();
	UINT rs2 = instr->rs2_simd();
	UINT size = instr->size();
	BYTE cond = ( (instr->gt()<<2) | (instr->lt()<<1) | (instr->eq()) );

	WORD rslt, op1, op2;

	for(INT i=0 ; i<REG_SIMD_BANK; i++)
	{
		if (size)
		{//word
			op1 = reg().getSIMDPair(rs1,i);
			op2 = reg().getSIMDPair(rs2,i);
		}
		else
		{//half
			op1 = (INT)reg().getSIMD(rs1,i);
			op2 = (INT)reg().getSIMD(rs2,i);
		}

		switch(cond) {
			case 1: //eq
				rslt = (op1 == op2);
				break;
			case 2: //lt
				rslt = (op1 < op2);
				break;
			case 3: //le
				rslt = (op1 <= op2);
				break;
			case 4: //gt
				rslt = (op1 > op2);
				break;
			case 5: //ge
				rslt = (op1 >= op2);
				break;
			default:
				AppFatal((0), ("SL2 Exec: invalid execC2vcmpr mode (gt=%d, lt=%d, eq=%d).", instr->gt(), instr->lt(), instr->eq()));
				break;
		}

		reg().setSIMD(rd1,i,(HWORD)rslt);
		//reg().setSIMD_ACC(i, rslt);
	}
	return pc() + instr->instrsize();

}

ADDR SL2Exec::execC2vneg (SL2Instr* instr) {
	UINT rd1 = instr->rd1_simd();
	UINT rs1 = instr->rs1_simd();
	UINT rs2 = instr->rs2_simd();
	UINT size = instr->size();
	UINT in_pair = instr->in_pair();

	WORD rslt=0;
	HWORD UpHalf, LwHalf;

	for(INT i=0 ; i<REG_SIMD_BANK ; i++)
	{
		if (in_pair)
		{//pair wise half
			UpHalf = reg().getSIMD(rs2+1,i);
			LwHalf = reg().getSIMD(rs2,i);

			UpHalf = reg().getSIMD(rs1+1,i)<0 ? -UpHalf : UpHalf;
			LwHalf = reg().getSIMD(rs1,i)  <0 ? -LwHalf : LwHalf;
			rslt = (((UpHalf&HWORD_DATA_MASK)<<INT16_BIT)|(LwHalf&HWORD_DATA_MASK));
			reg().setSIMDPair(rd1, i, rslt);
			//reg().setSIMD_ACC(i, rslt);
		}
		else if (size)
		{//word
			rslt = reg().getSIMDPair(rs2,i);
			rslt = reg().getSIMDPair(rs1,i)<0 ? -rslt : rslt;
			reg().setSIMDPair(rd1, i, rslt);
			//reg().setSIMD_ACC(i, rslt);
		}
		else
		{//half
			LwHalf = reg().getSIMD(rs2,i);
			LwHalf = reg().getSIMD(rs1,i)<0 ? -LwHalf : LwHalf;
			reg().setSIMD(rd1, i, LwHalf);
			//reg().setSIMD_ACC(i, LwHalf);
		}
	}
	return pc() + instr->instrsize();
}

ADDR SL2Exec::execC2vrnd (SL2Instr* instr) {
	UINT rd1 = instr->rd1_simd();
	UINT rs1 = instr->rs1_simd();
	UINT size = instr->size();
	UINT op_mode = instr->op_mode();

	for(INT i=0 ; i<REG_SIMD_BANK ; i++)
	{
		if(size)
		{//word
			WORD  rslt;
			rslt = reg().getSIMDPair(rs1,i);

			switch (op_mode) {
				case 0:	rslt = (rslt+1)>>1; break;
				case 1:	rslt = (rslt+2)>>2; break;
				case 2:	rslt = (rslt+4)>>3; break;
				case 3:	rslt = (rslt+8)>>4; break;
				case 4:	rslt = (rslt+16)>>5; break;
				case 5:	rslt = (rslt+32)>>6; break;
				case 6:	rslt = (rslt+64)>>7; break;	
				case 7:	rslt = (rslt+512)>>10; break;
			}
			reg().setSIMD(rd1,i, (HWORD)rslt); // We need this type of operation in application-- deblocking -- WWD
		}
		else
		{
			HWORD  rslt;
			rslt = reg().getSIMD(rs1,i);

			switch (op_mode) {
				case 0:	rslt = (rslt+1)>>1; break;
				case 1:	rslt = (rslt+2)>>2; break;
				case 2:	rslt = (rslt+4)>>3; break;
				case 3:	rslt = (rslt+8)>>4; break;
				case 4:	rslt = (rslt+16)>>5; break;
				case 5:	rslt = (rslt+32)>>6; break;
				case 6:	rslt = (rslt+64)>>7; break;	
				case 7:	rslt = (rslt+512)>>10; break;
			}

			reg().setSIMD(rd1,i, rslt);
		}
	}
	return pc() + instr->instrsize();
}

ADDR SL2Exec::execC2vshft (SL2Instr* instr) {
	UINT rd1 = instr->rd1_simd();
	UINT rs1 = instr->rs1_simd();

	UINT size = instr->size();
	UINT in_pair = instr->in_pair();
	UINT dir = instr->dir();
	UINT shft_amnt = instr->shft_amnt();

	WORD rslt=0;
	HWORD UpHalf, LwHalf;


	for(INT i=0 ; i<REG_SIMD_BANK ; i++)
	{
		if(in_pair)	{
			if (dir)
			{
				UpHalf = (reg().getSIMD(rs1+1,i) << shft_amnt);
				LwHalf = (reg().getSIMD(rs1  ,i) << shft_amnt);
			}
			else
			{
				UpHalf = (reg().getSIMD(rs1+1,i) >> shft_amnt);
				LwHalf = (reg().getSIMD(rs1  ,i) >> shft_amnt);
			}
			rslt = (((UpHalf&HWORD_DATA_MASK)<<INT16_BIT)|(LwHalf&HWORD_DATA_MASK));
			reg().setSIMDPair(rd1, i, rslt);
			//reg().setSIMD_ACC(i, rslt);			
		}
		else if (size)	{//word
			if (dir)
				rslt = reg().getSIMDPair(rs1,i) << shft_amnt;
			else
				rslt = reg().getSIMDPair(rs1,i) >> shft_amnt;

			reg().setSIMDPair(rd1,i, rslt);
			//reg().setSIMD_ACC(i, rslt);
		}
		else {
			if (dir)
				LwHalf = (reg().getSIMD(rs1,i) << shft_amnt);
			else
				LwHalf = (reg().getSIMD(rs1,i) >> shft_amnt);

			reg().setSIMD(rd1, i, LwHalf);
			//reg().setSIMD_ACC(i, LwHalf);
		}
	}
	return pc() + instr->instrsize();
}

ADDR SL2Exec::execC2vspas (SL2Instr* instr) {
	UINT rd1 = instr->rd1_simd();
	UINT rs1 = instr->rs1_simd();

	UINT imm5 = instr->imm5();
	UINT shft_amnt = instr->shft_amnt();

	HWORD UpHalf, LwHalf;
	WORD rslt;

	for(INT i=0 ; i<REG_SIMD_BANK ; i++)
	{
		UpHalf = reg().getSIMD(rs1+1,i);
		if (UpHalf > 0)
			UpHalf = UpHalf >> shft_amnt;
		else
			UpHalf = (UpHalf + imm5) >> shft_amnt;

		LwHalf = reg().getSIMD(rs1,i);
		if (LwHalf > 0)
			LwHalf = LwHalf >> shft_amnt;
		else
			LwHalf = (LwHalf + imm5) >> shft_amnt;
		
		rslt = (((UpHalf&HWORD_DATA_MASK)<<INT16_BIT)|(LwHalf&HWORD_DATA_MASK));	
		reg().setSIMDPair(rd1, i, rslt);
		//reg().setSIMD_ACC(i, rslt);
	}
	return pc() + instr->instrsize();
}

ADDR SL2Exec::execC2vsubs (SL2Instr* instr) {
	UINT rd1 = instr->rd1_simd();
	UINT rs1 = instr->rs1_simd();
	UINT rs2 = instr->rs2_simd();
	UINT size  = instr->size();
	UINT in_pair = instr->in_pair();
	UINT dir = instr->dir();
	UINT op_mode = instr->op_mode();
	WORD shft_op1 = instr->shft_mode() & 1;
	WORD shft_op2 = instr->shft_mode() & 2;
	WORD shft_mask = 3;
	UINT shft_amnt;
	HWORD UpHalf, LwHalf;
	WORD rslt;

	if (op_mode<2)
	{//sub (and absolute for mode 1)
		for(INT i=0 ; i<REG_SIMD_BANK ; i++)
		{
			if(shft_op2)	///*** fixed bug 46
			{
				shft_amnt = (UINT)(reg().getC2CTRL(EC2CR_VADD_SHFT) & shft_mask) >> (2*i);
				AppFatal((shft_amnt>=0), ("shift bits must be set greater zero! [%2d]", shft_amnt));
			}
			else
				shft_amnt = shft_op1;

			if(in_pair)
			{
				// Add one assertion from ISA2.9
				AppFatal((shft_amnt<15), ("shift bits must be set less than 15! [%2d]", shft_amnt));
				
				UpHalf = (reg().getSIMD(rs1+1,i) - reg().getSIMD(rs2+1,i));
				LwHalf = (reg().getSIMD(rs1  ,i) - reg().getSIMD(rs2  ,i));

				if (op_mode==1) 
				{//abs
					UpHalf = (UpHalf>=0)? UpHalf: -UpHalf;
					LwHalf = (LwHalf>=0)? LwHalf: -LwHalf;
				}

				if (dir)
				{
					UpHalf = (UpHalf << shft_amnt);
					LwHalf = (LwHalf << shft_amnt);
				}
				else
				{
					UpHalf = (UpHalf >> shft_amnt);
					LwHalf = (LwHalf >> shft_amnt);
				}
				rslt = (((UpHalf&HWORD_DATA_MASK)<<INT16_BIT)|(LwHalf&HWORD_DATA_MASK));
				reg().setSIMDPair(rd1, i, rslt);
			}
			else if (size)
			{//word
				rslt = (reg().getSIMDPair(rs1,i) - reg().getSIMDPair(rs2,i));

				if (op_mode==1)
					rslt = (rslt>=0)? rslt: -rslt;

				if (dir)
					rslt <<= shft_amnt;
				else
					rslt >>= shft_amnt;

				reg().setSIMDPair(rd1,i, rslt);
			}
			else
			{
				LwHalf = (reg().getSIMD(rs1,i) - reg().getSIMD(rs2,i));
				if (op_mode==1)
					LwHalf = (LwHalf>=0)? LwHalf: -LwHalf;
				if (dir)
					LwHalf <<= shft_amnt;
				else
					LwHalf >>= shft_amnt;

				reg().setSIMD(rd1,i, LwHalf);
			}

			shft_mask <<= 2;
		}
	}
	else if (op_mode==2)
	{//absolute rs2 only
		for(INT i=0 ; i<REG_SIMD_BANK ; i++)
		{
			if(in_pair)
			{
				UpHalf = (reg().getSIMD(rs2+1,i));
				LwHalf = (reg().getSIMD(rs2  ,i));

				UpHalf = (UpHalf>=0)? UpHalf: -UpHalf;
				LwHalf = (LwHalf>=0)? LwHalf: -LwHalf;
				
				rslt = (((UpHalf&HWORD_DATA_MASK)<<INT16_BIT)|(LwHalf&HWORD_DATA_MASK));
				reg().setSIMDPair(rd1, i, rslt);
			}
			else if (size)
			{//word
				rslt = (reg().getSIMDPair(rs2,i));
				rslt = (rslt>=0)? rslt: -rslt;

				reg().setSIMDPair(rd1,i, rslt);
			}
			else
			{
				LwHalf = (reg().getSIMD(rs2,i));
				LwHalf = (LwHalf>=0)? LwHalf: -LwHalf;

				//printf("[%d]\n", LwHalf);
				reg().setSIMD(rd1,i, LwHalf);
			}
		}
	}

	return pc() + instr->instrsize();	
}


// MULT
ADDR SL2Exec::execC2muls (SL2Instr* instr) {
	UINT rd;
	UINT rs1;
	UINT rs2;
	UINT rs3;
	UINT dir = instr->dir();
	DWORD result;
	WORD result_low;
	rd = instr->rd();
	rs1 = instr->rs1();
	rs2 = instr->rs2();
	rs3 = instr->rs3();
	if(dir)
		result = (SL2_GETGPR(rs1) * (SL2_GETGPR(rs2)>>instr->opd_shft()))<< SL2_GETGPR(rs3);
	else
		result = (SL2_GETGPR(rs1) * (SL2_GETGPR(rs2)>>instr->opd_shft()))>> SL2_GETGPR(rs3);

	result_low = (WORD)result;
	SL2_SETGPR(rd, result_low);

	// Set high 16 bits to CR
	reg().setC2CTRL(EC2CR_MULT_HI, (WORD)(result>>32));
	return pc() + instr->instrsize();	
}


// ADD
ADDR SL2Exec::execC2adds (SL2Instr* instr) {
	WORD addin1;
	UINT rd;
	UINT rs1;
	UBYTE imm1 = instr->imm1();
	WORD addin2;
	WORD result;
	if(instr->gpr()==1) {
		rd = instr->rd();
		rs1 = instr->rs1();
		addin1 = SL2_GETGPR(rs1);
		addin2 = imm1==1?(WORD)instr->rs2_imm():SL2_GETGPR(instr->rs2());
		if(instr->dir())
			result = (addin2 + (addin1 << instr->opd_shft()) + instr->carry())>>instr->shft_amnt();	
		else
			result = (addin2 + (addin1 >> instr->opd_shft()) + instr->carry())>>instr->shft_amnt();	
			
		SL2_SETGPR(rd, result);
	}
	else {
		c2_ctrl_mad_ctrl madCtrl;
		madCtrl.word = reg().getC2CTRL(EC2CR_ADD_CTRL);
		UINT write_enable = madCtrl.bits.rf_write_enable;
		UBYTE size = instr->size();
		rd = instr->rd1_simd();
		rs1 = instr->rs1_simd();
		if(size==1) {
			addin1 = reg().getSIMDPair(rs1, madCtrl.bits.rs1_bank);
		}
		else {
			addin1 = reg().getSIMD(rs1, madCtrl.bits.rs1_bank);
		}
		
		if(imm1==1) {
			addin2 = instr->rs2_imm();
		}
		else if(size==1) {
			addin2 = reg().getSIMDPair(instr->rs2_simd(), madCtrl.bits.rs2_bank);
		}
		else {
			addin2 = reg().getSIMD(instr->rs2_simd(), madCtrl.bits.rs2_bank);
		}

		if(instr->dir())
			result = (addin1 + (addin2<<instr->opd_shft()) + instr->carry())>>instr->shft_amnt();
		else
			result = (addin1 + (addin2>>instr->opd_shft()) + instr->carry())>>instr->shft_amnt();
		
		for(INT i = 0; i<REG_SIMD_BANK; i++) {
			if((write_enable&1)==1){
				if(size==1) {
					reg().setSIMDPair(rd, i, result);
				}
				else {
					reg().setSIMD(rd, i, (HWORD) result);
				}
			}
			write_enable = write_enable>>1;
		}
	}
	//reg().setC2MAD_ACC(result);
	return pc() + instr->instrsize();
}

ADDR SL2Exec::execC2bcst (SL2Instr* instr) {
	UINT result;
	HWORD op = (SL2_GETGPR(instr->rs1()) & 0xFFFF);
	
	if(instr->shft()) {
		op = op << 2;
	}
	op = Abs(op);

	result = motionBitCost(op);
	
	SL2_SETGPR(instr->rd(), result);
	
	return pc() + instr->instrsize();	
}

ADDR SL2Exec::execC2chkrng (SL2Instr* instr) {
	WORD rs1_data = SL2_GETGPR(instr->rs1());
	WORD result;
	if(mmu().getLutLL(instr->lo_indx())<=rs1_data
		&&rs1_data<mmu().getLutHL(instr->hi_indx())) {
		result = 1;
	}
	else {
		result = 0;
	}
	SL2_SETGPR(instr->rd(), result);
	//reg().setC2MAD_ACC(result);
	return pc() + instr->instrsize();
}

ADDR SL2Exec::execC2cmov (SL2Instr* instr) {
	WORD rs1_data = SL2_GETGPR(instr->rs1());
	WORD rs2_data = SL2_GETGPR(instr->rs2());
	WORD rs3_data = SL2_GETGPR(instr->rs3());
	WORD result;

	result = rs3_data?rs1_data:rs2_data;
	SL2_SETGPR(instr->rd(), result);
	//reg().setC2MAD_ACC(result);
	return pc() + instr->instrsize();		
}
ADDR SL2Exec::execC2clp (SL2Instr* instr) {
	WORD rs1_data = SL2_GETGPR(instr->rs1());
	WORD rs2_data = instr->imm1()?instr->rs2_imm():SL2_GETGPR(instr->rs2());
	WORD rs3_data = SL2_GETGPR(instr->rs3());
	WORD result;
	if(rs3_data<rs1_data) {
		result = rs1_data;
	}
	else if(rs3_data>rs2_data) {
		result = rs2_data;
	}
	else {
		result = rs3_data;
	}
	SL2_SETGPR(instr->rd(), result);
	return pc() + instr->instrsize();	
}

ADDR SL2Exec::execC2med (SL2Instr* instr) {
	AppFatal((instr->macroCnt()>0), ("SL2Exec: Intra macro count <= 0."));
	SL2InstrListIter iter = instr->getMacro()->begin();
	SL2InstrListIter end_iter = instr->getMacro()->end();
	while(iter!=end_iter) {
		(this->*((*iter)->exec()))((*iter));
		iter++;
		//printf("We in macro [med]  now, instructions[%d]!!!\n", i++); 
	}
	return pc() + instr->instrsize();
}

ADDR SL2Exec::execC2scond (SL2Instr* instr) {
	WORD op1;
	WORD op2;
	BYTE cond = ( (instr->gt()<<2) | (instr->lt()<<1) | (instr->eq()) );
	WORD result = 0;
	UINT rs1, rs2; 
	
	c2_ctrl_mad_ctrl madCtrl;
	madCtrl.word = reg().getC2CTRL(EC2CR_ADD_CTRL);
	
	if(instr->gpr()) {
		op1 = SL2_GETGPR(instr->rs1());
		if(instr->imm1()) {
			op2 = instr->rs2_imm();
		}
		else {
			op2 = SL2_GETGPR(instr->rs2());
		}
	}
	else {
		rs1 = instr->rs1_simd();
	
		if(instr->size())
			op1 = reg().getSIMDPair(rs1, madCtrl.bits.rs1_bank);
		else
			op1 = reg().getSIMD(rs1, madCtrl.bits.rs1_bank);
		
		if(instr->imm1()) {
			op2 = instr->rs2_imm();
		}
		else {
			//op2 = reg().getSIMD(rs2, madCtrl.bits.rs2_bank);
			rs2 = instr->rs2_simd();
			if(instr->size())
				op2 = reg().getSIMDPair(rs2, madCtrl.bits.rs2_bank);
			else
				op2 = reg().getSIMD(rs2, madCtrl.bits.rs2_bank);		
		}		
	}

	// Compare
	switch(cond) {
		case 1:
			result = (op1==op2);
			break;
		case 2:
			result = (op1<op2);
			break;		
		case 3:
			result = (op1<=op2);
			break;		
		case 4:
			result = (op1>op2);
			break;		
		case 5:
			result = (op1>=op2);
			break;		
		default:
			AppFatal((0), ("SL2 Exec: invalid C2scond conditional mode (%d).", cond));
			break;
	}
	reg().setC2SPEC(EC2SPEC_COND, result);
	if(instr->wr_back()==1) {
		SL2_SETGPR(instr->rd(), result);
		//reg().setC2MAD_ACC(result);
	}
	return pc() + instr->instrsize();	
}

ADDR SL2Exec::execC2subs (SL2Instr* instr) {
	WORD subin;
	UINT rd;
	UINT rs1;
	UBYTE imm1 = instr->imm1();
	WORD result;
	
	if(instr->gpr()==1) {
		rd = instr->rd();
		rs1 = instr->rs1();
		SL2_GETGPR(rs1);
		imm1 = instr->imm1();
		subin = imm1==1?(WORD)instr->rs2_imm():SL2_GETGPR(instr->rs2());	
		result = SL2_GETGPR(rs1) - subin;
		result = instr->abs()==1?Abs(result):result>>instr->shft_amnt();
		SL2_SETGPR(rd, result);
	}
	else {
		c2_ctrl_mad_ctrl madCtrl;
		madCtrl.word = reg().getC2CTRL(EC2CR_ADD_CTRL);
		UINT write_enable = madCtrl.bits.rf_write_enable;
		UBYTE size = instr->size();
		rd = instr->rd1_simd();
		rs1 = instr->rs1_simd();
		if(imm1==1) {
			subin = instr->rs2_imm();
		}
		else if(size==1) {
			subin = reg().getSIMDPair(instr->rs2_simd(), madCtrl.bits.rs2_bank);
		}
		else {
			subin = reg().getSIMD(instr->rs2_simd(), madCtrl.bits.rs2_bank);
		}	
		
		if(size==1) {
			result = reg().getSIMDPair(rs1, madCtrl.bits.rs1_bank) - subin;
		}
		else {
			result = reg().getSIMD(rs1, madCtrl.bits.rs1_bank) - subin;
		}
		result = instr->abs()==1?Abs(result):(result>>instr->shft_amnt());
		
		for(INT i = 0; i<REG_SIMD_BANK; i++) {
			if((write_enable&1)==1){
				if(size==1) {
					reg().setSIMDPair(rd, i, result);
				}
				else {
					reg().setSIMD(rd, i, (HWORD) result);
				}
			}
			write_enable = write_enable>>1;
		}
	}
	//reg().setC2MAD_ACC(result);
	return pc() + instr->instrsize();	
}


// BIT
ADDR SL2Exec::execC2bdep (SL2Instr* instr) {
	WORD rs3_data = ((SL2_GETGPR(instr->rs2())>>16)&0x1f);
	INT pos = instr->lsb()?rs3_data:(31-rs3_data);
	INT width = (SL2_GETGPR(instr->rs2())&0x1f);
	WORD dest= SL2_GETGPR(instr->rd());
	WORD src= SL2_GETGPR(instr->rs1());
	UINT mask = width>0?1:0;
	for(INT i = 1; i<width; i++) {
		mask = (mask<<1)+1;
	}
	//printf("rd[%08x], rs1[%08x], rs2(width)[%08x], rs3(pos)[%08x]\n",SL2_GETGPR(instr->rd()),SL2_GETGPR(instr->rs1()),SL2_GETGPR(instr->rs2()),SL2_GETGPR(instr->rs3()));
	//printf("SRC is [%08x]--%02x, ", src, instr->rs1());
	pos = pos - width + 1;
	src = ((src & mask)<<pos);
	mask = (mask << pos);
	dest = dest & (~mask);
	dest = dest | src;
	//printf("Dest [%08x]\n", dest);
	SL2_SETGPR(instr->rd(), dest);
	return pc()+instr->instrsize();   	
}

ADDR SL2Exec::execC2bop (SL2Instr* instr) {
	WORD op1;
	WORD op2;
	WORD result;
	
	op1 = SL2_GETGPR(instr->rs1()); //
	op2 = instr->imm1()?instr->rs2_imm():SL2_GETGPR(instr->rs2());

	switch(instr->op_mode()) {
		case 0:
			op2 = op2 & 0x1f; // WWD add
			if(instr->dir()) {
				result = ((UWORD) op1) << op2;
			}
			else {
				result = ((UWORD) op1) >> op2;
			}
			break;
		case 1:
			result = op1 & op2;
			break;
		case 2:
			result = op1 | op2;
			break;
		case 3:
			result = op1 ^ op2;
			break;
		default:
			AppFatal((0), ("SL2 Exec: invaild C2bop op_mode (%d).", instr->op_mode()));
			break;	
	}
	SL2_SETGPR(instr->rd(), result);
	return pc() + instr->instrsize();		
}

ADDR SL2Exec::execC2bxtr (SL2Instr* instr) {
	WORD rs3_data = (SL2_GETGPR(instr->rs3())&0x1f);
	INT pos = instr->lsb()?rs3_data:(31-rs3_data);
	INT width = (SL2_GETGPR(instr->rs2())&0x1f);
	WORD src= SL2_GETGPR(instr->rs1());  
   
	UINT32 mask = WORD_DATA_MASK;
	src >>= (pos-width+1);   
	
	if(instr->sign_ext()) {
		mask <<= width;
		src &= (~mask);
		if((src&(mask>>1))>0)
			src |= mask;	
	}
	else {
		if(width<WORD_BIT)
			mask <<= width;
		else
			mask = 0;
		src &= (~mask);		
	}
	SL2_SETGPR(instr->rd(), src);
	return pc() + instr->instrsize();
}

ADDR SL2Exec::execC2clzob (SL2Instr* instr) {
	INT  op_mode = instr->op_mode();
	INT  imm = instr->imm1();
	UINT end_pos;
	WORD source= SL2_GETGPR(instr->rs1());
	UINT mask;
	UINT count=0;
   
	if(imm)
		end_pos = instr->rs2_imm();
	else
	   end_pos = SL2_GETGPR(instr->rs2_imm());

//    printf("source [%08x], start pos[%d], imm [%d]\n", source, start_pos, imm); fflush(0);
	switch(op_mode)
	{
		   case 0:
		   	    // Count zero from 31 to 0
				mask = 1<< (31);
				for(INT i=(31); i>= end_pos; i--)
				{
					if( !(source & mask))
						count ++;
					else
						break;

					mask = mask >> 1;
				 }
			  break;
		   case 1:
		   	    // Count zero from 0 to start_pos
				mask = 1<< 0;
				for(INT i=0; i< end_pos; i++)
				{
					if(!( source & mask))
						count ++;
					else
						break;

					mask = mask << 1;
				 }
			  break;
		   case 2:
		   	    // Count ones from 31-start_pos to 0
				mask = 1<< (31);
				for(INT i=(31); i>= end_pos; i--)
				{
					if( source & mask)
						count ++;
					else
						break;

					mask = mask >> 1;
				 }
			  break;
		   case 3:
		   	    // Count ones from 0 to start_pos
				mask = 1<< 0;
				for(INT i=0; i< end_pos; i++)
				{
					if( source & mask)
						count ++;
					else
						break;

					mask = mask << 1;
				 }
			  break;

	}

	SL2_SETGPR(instr->rd(), count);
	return pc() + instr->instrsize();
}

// SUM4
ADDR SL2Exec::execC2gsum4s (SL2Instr* instr) {
	WORD rs1_data = SL2_GETGPR(instr->rs1());
	WORD rs2_data = SL2_GETGPR(instr->rs2());
	WORD rd_data = (rs1_data + rs2_data + instr->imm5()) >> instr->shft_amnt();
	SL2_SETGPR(instr->rd(), rd_data);
	return pc() + instr->instrsize();	
}

ADDR SL2Exec::execC2sum4 (SL2Instr* instr) {
	UINT rd, rs2, rs3;
	UINT rs1 = instr->rs1_simd();
	c2_ctrl_sum_ctrl sumCtrl;
	UINT write_enable;
	WORD result;
	INT bank = instr->bank();

	switch(instr->op_mode()) {
		case 0:
			result = 	reg().getSIMD(rs1, bank) + 
						reg().getSIMD(rs1, bank + 1) + 
						reg().getSIMD(rs1, bank + 2) +
						reg().getSIMD(rs1, bank + 3); 
			break;
		case 1:
			rd = instr->rd();
			result = 	reg().getSIMD(rs1, bank) + 
						reg().getSIMD(rs1, bank + 1) + 
						reg().getSIMD(rs1, bank + 2) +
						reg().getSIMD(rs1, bank + 3); 
			SL2_SETGPR(rd, result);
			break;
		case 2:
		 	rd = instr->rd();
			result = 	reg().getSIMD(rs1, bank) + 
						reg().getSIMD(rs1, bank + 1) + 
						(reg().getSIMD(rs1, bank + 2)&3) +
						((reg().getSIMD(rs1, bank + 3)&3)<<2) ; 
			SL2_SETGPR(rd, result);
			break;	
		case 3:
			rd = instr->rd1_simd();
			sumCtrl.word = reg().getC2CTRL(EC2CR_SUM_CTRL);
			write_enable = sumCtrl.bits.rf_write_enable;	
			for(INT i = 0; i<REG_SIMD_BANK; i++) {
				if((write_enable&1)==1){
					result = 	(reg().getSIMD(rs1, sumCtrl.bits.rs1_bank) + 
								 reg().getSIMD(instr->rs3_simd(), sumCtrl.bits.rs3_bank) + 
								 (reg().getSIMD(instr->rs2_simd(), sumCtrl.bits.rs2_bank) <<
								  sumCtrl.bits.opd_ls_rs) +
								 reg().getC2SUM_ACC()) >>
								sumCtrl.bits.result_rs; 					
					reg().setSIMD(rd, i, result);
				}
				write_enable = write_enable>>1;
			}
			break;	
		case 4:
		 	rd = instr->rd();
			rs1 = instr->rs1();
			rs2 = instr->rs2();
			rs3 = instr->rs3();
			result = 	SL2_GETGPR(rs1) + 
						(SL2_GETGPR(rs2)&3) +
						((SL2_GETGPR(rs3)&3)<<2) ; 
			SL2_SETGPR(rd, result);
			break;	
		default:
			AppFatal((0), ("SL2 Exec: invaild C2mov op_mode (%d).", instr->op_mode()));
			break;					
	}
	reg().setC2SUM_ACC(result);
	return pc() + instr->instrsize();			
}


ADDR SL2Exec::execC2mov (SL2Instr* instr) {
	UINT rd;
	UINT rs1;
	c2_ctrl_sum_ctrl sumCtrl;
	UINT write_enable;
	WORD result;
	INT srcbank;
	INT dstbank;

	switch(instr->op_mode()) {
		case 0:
			rd = instr->rd();
			rs1 = instr->rs1();
			result = SL2_GETGPR(rs1);
			SL2_SETGPR(rd, result);
			reg().setC2SUM_ACC(result);
			break;
		case 1:
			rd = instr->rd1_simd();
			rs1 = instr->rs1_simd();		
			sumCtrl.word = reg().getC2CTRL(EC2CR_SUM_CTRL);
			write_enable = sumCtrl.bits.rf_write_enable;
			srcbank = sumCtrl.bits.rs1_bank;
			result = reg().getSIMD(rs1, srcbank);	
			for(INT i = 0; i<REG_SIMD_BANK; i++) {
				if((write_enable&1)==1){
					reg().setSIMD(rd, i, result);
				}
				write_enable = write_enable>>1;
			}		
			reg().setC2SUM_ACC(result);
			break;
		case 2:
			rs1 = instr->rs1_simd();	
			reg().setC2SUM_ACC(reg().getSIMD(rs1, instr->bank()));
			break;	
		case 3:
			rs1 = instr->rs1_simd();
			srcbank = instr->bank();
			//sumCtrl.word = reg().getC2CTRL(EC2CR_SUM_CTRL);
			reg().setC2SUM_ACC(reg().getSIMD(rs1, srcbank));
			break;
			// Need more test cases for it!!
		case 4:
			rs1 = instr->rs1_simd();	
			rd  = instr->rd1_simd();
			srcbank = instr->bank();
			dstbank = instr->dstbank();
			reg().setSIMD(rd, dstbank, reg().getSIMD(rs1, srcbank));
			break;	
		case 5:
			rs1 = instr->rs1_simd();	
			rd  = instr->rd1_simd();
			srcbank = SL2_GETGPR(instr->bank());
			dstbank = SL2_GETGPR(instr->dstbank());
			reg().setSIMD(rd, dstbank, reg().getSIMD(rs1, srcbank));
			break;		
		default:
			AppFatal((0), ("SL2 Exec: invaild C2mov op_mode (%d).", instr->op_mode()));
			break;					
	}
	return pc() + instr->instrsize();		
}


//VLCS
ADDR SL2Exec::execC2vlcs (SL2Instr* instr) {
	UINT op_mode = instr->op_mode();
	WORD coeff = 0;
	WORD bank = 0;
	BOOL zero_flag = FALSE;
	BOOL one_flag = FALSE;
	BOOL neg_flag = FALSE;
	UINT rs1;
	WORD result;
	WORD trail_sign;
	switch ((op_mode&1)) {
		case 0:
			rs1 = instr->rs1_simd();
			if(reg().getC2INT(EC2INT_START_OF_BLK)) {
				INT start = 0;
				reg().setC2INT(EC2INT_COEFF_COST, 0);
				
				reg().setC2INT(EC2INT_START_OF_BLK, 0);
				start = ((op_mode>>1)&1);
				coeff = reg().getSIMD(rs1, mmu().getLutOrder(start));
				reg().setC2INT(EC2INT_BANK, (start+1));
			}
			else {
				bank = reg().getC2INT(EC2INT_BANK);
				coeff = reg().getSIMD(rs1, mmu().getLutOrder(bank));
				reg().incC2INT(EC2INT_BANK, 1);
			}
			zero_flag = (coeff==0);
			one_flag = (Abs(coeff)==1);
			neg_flag = (coeff<0);
			
			if(zero_flag) {
				reg().incC2INT(EC2INT_ZERO_CNT, 1);
			}
			else {
				result = ((coeff<<HWORD_BIT)|(reg().getC2INT(EC2INT_ZERO_CNT)&HWORD_DATA_MASK));
				reg().setSIMDPair(instr->rd1_simd(), reg().getC2INT(EC2INT_WRITE_SEL), result);
				reg().incC2INT(EC2INT_WRITE_SEL, 1);
								
				reg().incC2INT(EC2INT_TOTAL_ZERO, reg().getC2INT(EC2INT_ZERO_CNT));
				reg().incC2INT(EC2INT_NUM_OF_NON_ZERO, 1);
				if(one_flag) {
					if(reg().getC2INT(EC2INT_TRAIL_ONE)<3) {
						//trail_sign = ((reg().getC2INT(EC2INT_TRAIL_SIGN)<<1) | neg_flag);
						trail_sign = ((neg_flag<< (reg().getC2INT(EC2INT_TRAIL_ONE))) | reg().getC2INT(EC2INT_TRAIL_SIGN));
						reg().setC2INT(EC2INT_TRAIL_SIGN, trail_sign);
						reg().incC2INT(EC2INT_TRAIL_ONE, 1);
					}
					else
					{
						trail_sign = ((neg_flag<< 2) | (reg().getC2INT(EC2INT_TRAIL_SIGN) >> 1));
						reg().setC2INT(EC2INT_TRAIL_SIGN, trail_sign);
					}
					if(reg().getC2INT(EC2INT_COEFF_COST)!=63) {
						reg().incC2INT(EC2INT_COEFF_COST, mmu().getLutCost(reg().getC2INT(EC2INT_ZERO_CNT)));
					}
				}
				else {
					reg().setC2INT(EC2INT_COEFF_COST, 63);
					reg().setC2INT(EC2INT_TRAIL_ONE, 0);
					reg().incC2INT(EC2INT_COEFF_CNT, 2);
					reg().setC2INT(EC2INT_TRAIL_SIGN, 0);
				}

				///*** Reset it here
				reg().setC2INT(EC2INT_ZERO_CNT, 0);

			}
			break;
		case 1:
			//UINT trail= reg().getC2INT(EC2INT_TRAIL_SIGN)&0x7;
			//Inverse it
			//trail = ((trail&0x1)<<2) | (trail&0x2) | ((trail&0x4)>>2);
			result =   ((reg().getC2INT(EC2INT_TRAIL_SIGN)&0x7)<<24)
			  		 | ((reg().getC2INT(EC2INT_COEFF_CNT)&0x3f)<<18)
			 		 | ((reg().getC2INT(EC2INT_COEFF_COST)&0x3f)<<12)
					 | ((reg().getC2INT(EC2INT_TOTAL_ZERO)&0x1f)<<7)
					 | ((reg().getC2INT(EC2INT_NUM_OF_NON_ZERO)&0x1f)<<2)
					 | (reg().getC2INT(EC2INT_TRAIL_ONE)&0x3);
			SL2_SETGPR(instr->rd(), result);
			reg().initC2INT();
			
			break;
		default:
			AppFatal((0), ("SL2 Exec: invalid C2vlcs op_mode mode (%d).", op_mode));
			break;		
	}
	return pc() + instr->instrsize();	
}

