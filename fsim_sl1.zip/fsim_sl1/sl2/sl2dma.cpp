#include "sl2dma.h"
#include "sl2address.h"
#include "sl2mmu.h"
#include "accesslist.h"

//===========================================================//
//                           Trace
//===========================================================//
// _DMA_TRACE_CODE: enable the generation of trace code
// TRACE_LEVEL    : set various level of trace (functional if and only
//                  if _DMA_TRACE_CODE is defined)


enum Trace_level
{
    TRACE_LEVEL_OFF     =0,
    TRACE_LEVEL_FLOW    =1,
    TRACE_LEVEL_DETAIL  =2
};

//Set your trace level by defined TRACE_LEVEL
#ifndef TRACE_LEVEL
#define TRACE_LEVEL TRACE_LEVEL_OFF
#endif

#define _print(params) printf params

#ifdef _DMA_TRACE_CODE
  //_IsTrace(level, (const char * Format_string, ...)) [Notice: parathesis for 2nd arg]
  #define IsTrace(level, msg) ((level <= TRACE_LEVEL) ? _print(("In %s:%d: ", __FILE__, __LINE__)), _print(msg) : (0))
  #define IsTraceEnter() \
     IsTrace(TRACE_LEVEL_FLOW, ("Enter %s.\n", __FUNCTION__))
  #define IsTraceLeave() \
     IsTrace(TRACE_LEVEL_FLOW, ("Leave %s.\n", __FUNCTION__))
#else
  #define IsTrace(level, msg) 
  #define IsTraceEnter()      
  #define IsTraceLeave()      
#endif 
//-----------------------------------------------------------------//


SL2DMA::SL2DMA(SL2MMU& m, Memory* mem, ADDR start, UINT size) 
		: InterfaceHandler::InterfaceHandler(mem, start, size), _mmu(m) {
	channel(0);
}

void SL2DMA::readHook(ADDR addr) {
}

void SL2DMA::writeHook(ADDR addr) {
	ADDR curAddr = offsetAddr(addr);
	for(INT i = 0; i<SL2_DMA_MAX_CHANNEL; i++) {
		if(curAddr == SL2_OCR_DMA_CMD) { ///*** WWD
			channel(i);
			_onCmdWrite((EDMA_CMD) mmu().getWord(addr));
			break;
		}
		curAddr -= SL2_DMA_REGSET_SIZE;
	}	
}

/*
 * To polling register DMAR_CMD and execute a command whenever the register
 * is changed
 */
void SL2DMA::_onCmdWrite(EDMA_CMD cmd) {
    IsTraceEnter();

    switch(cmd)
    {
        case DMA_CMD_NOP:                                break;
        case DMA_CMD_LINEAR:       _execLinear();        break;
        case DMA_CMD_L4X16BLK:       _execL4x16Blk();       break;
        case DMA_CMD_L8X8BLK:       _execL8x8Blk();       break;
        case DMA_CMD_L16X16BLK:     _execL16x16Blk();     break;
        case DMA_CMD_SEARCHWIN:     _execSearchWin();     break;
        case DMA_CMD_CHROMA:        _execChroma();        break;
        case DMA_CMD_CONST:         _execConst();         break;
        case DMA_CMD_LC4X8BLK:      _execLC4x8Blk();      break;
        case DMA_CMD_LC8X8BLK:      _execLC8x8Blk();      break;
        case DMA_CMD_LC16X16BLK:    _execLC16x16Blk();    break;
        case DMA_CMD_S4X16BLK:       _execS4x16Blk();       break;
        case DMA_CMD_S8X8BLK:       _execS8x8Blk();       break;
        case DMA_CMD_S16X16BLK:     _execS16x16Blk();     break;
        case DMA_CMD_SC4X8BLK:      _execSC4x8Blk();      break;
        case DMA_CMD_SC8X8BLK:      _execSC8x8Blk();      break;
        case DMA_CMD_SC16X16BLK:    _execSC16x16Blk();    break;
        case DMA_CMD_SLINEAR:    _execStrideXfer();    break;
        case DMA_CMD_RLINEAR:    _execRecoderXfer();    break;
        
        default:
          AppFatal((0), ("unknown DMA command: (EDMA_CMD) %d", cmd));
    }

	///*** problem of dead loop
    setOnChipRegWord(SL2_OCR_DMA_CMD, DMA_CMD_NOP);

    IsTraceLeave();
}



INT SL2DMA::_execLinear(void) {
    WORD size = getOnChipRegWord(SL2_OCR_DMA_SIZE);
    ADDR dest = getOnChipRegWord(SL2_OCR_DMA_DST);
    ADDR src = getOnChipRegWord(SL2_OCR_DMA_SRC0);
    UINT destType = mmu().accessList()->getType(dest);
    UINT srcType = mmu().accessList()->getType(src);
    
    IsTraceEnter();

    setOnChipRegWord(SL2_OCR_DMA_STATUS, DMA_STATUS_LINEAR);
	setOnChipRegWord(SL2_OCR_DMA_CMD, DMA_CMD_NOP);
    // TODO: Should we handle Memory::checkBreak()?
    // TODO: Check where DRAM is ready if dest/src is dram
	//printf("Xliner Tramsfer: dest[%08x]--type[%2d], src[%08x]--type[%2d], size[%4d]\n", dest, destType, src,srcType,size);
	if(mmu().isSRAM(destType)==TRUE&&srcType==RANGE_IDX_MEMORY) {
		mmu().copyDram2Sram(dest, src, size);
	}
	else if (destType==RANGE_IDX_MEMORY&&mmu().isSRAM(srcType)==TRUE) {
		///*** WWD: use wrong function: should change  copyDram2Sram to copySram2Dram
		mmu().copySram2Dram(dest, src, size);
	}
	else if (mmu().isSRAM(destType)==TRUE&&mmu().isSRAM(srcType)==TRUE) {
		mmu().copySram2Sram(dest, src, size);
	}
	///*** WWD: Please note we support transfer data from Dram to LUT even we do not use it at present
	else {
		AppFatal((0), ("SL2DMA: invalid transfer type."));
	}

	setOnChipRegWord(SL2_OCR_DMA_STATUS, DMA_STATUS_IDLE);

    IsTraceLeave();

    return 0;
}


INT SL2DMA::_execL4x16Blk(void) { 
    return _exec4x4BlockXfer(TRUE, FALSE, 4);
}


INT SL2DMA::_execL8x8Blk(void) {
    return _exec8x8BlockXfer(TRUE, FALSE);
}


INT SL2DMA::_execL16x16Blk(void) {
    return _exec16x16BlockXfer(TRUE, FALSE);
}


INT SL2DMA::_execS4x16Blk(void) { 
    return _exec4x4BlockXfer(FALSE, FALSE, 4);
}


INT SL2DMA::_execS8x8Blk(void) {
    return _exec8x8BlockXfer(FALSE, FALSE);
}


INT SL2DMA::_execS16x16Blk(void) {
    return _exec16x16BlockXfer(FALSE, FALSE);
}


INT SL2DMA::_execLC4x8Blk(void) { 
    return _exec4x4BlockXfer(TRUE, TRUE, 2);
}


INT SL2DMA::_execLC8x8Blk(void) {
    return _exec8x8BlockXfer(TRUE, TRUE);
}


INT SL2DMA::_execLC16x16Blk(void) {
    return _exec16x16BlockXfer(TRUE, TRUE);
}


INT SL2DMA::_execSC4x8Blk(void) { 
    return _exec4x4BlockXfer(FALSE, TRUE, 2);
}


INT SL2DMA::_execSC8x8Blk(void) {
    return _exec8x8BlockXfer(FALSE, TRUE);
}


INT SL2DMA::_execSC16x16Blk(void) {
    return _exec16x16BlockXfer(FALSE, TRUE);
}

/*
 * Load/Store 4x4 blocks from/to an image in Dram to/from vbuf
 */
INT SL2DMA::_exec4x4BlockXfer(BOOL isDramToV, BOOL isChromaLoad, INT count)
{
    ADDR dest = getOnChipRegWord(SL2_OCR_DMA_DST);
    ADDR src = getOnChipRegWord(SL2_OCR_DMA_SRC0);

    ADDR imgbase = getOnChipRegEIWord(SL2_OCR_EI_IMAGEBASE);
    ADDR drambase = getOnChipRegEIWord(SL2_OCR_EI_DRAMBASE);

    UWORD img = (UWORD) getOnChipRegEIWord(SL2_OCR_EI_IMAGESZ);

    INT img_w = img >> 16;      // TODO: Check whether the width in low bytes
    INT row = 0, col = 0;
//    INT b4num = 0;              //Number of 4x4 blocks
    UINT doffset = 0;   //Dram offset
    UINT voffset = 0;   //Vbuf offset


    if (isChromaLoad)
        img_w >>= 1;   //  Chroma width helf of that of Luma

    //Calculate the physical address for dram address
    if (isDramToV)
        src += drambase + imgbase;
    else
        dest += drambase + imgbase;

	//if(_channel != 0)
	//{
	//	printf("Ch:[%d], dest[%08x], src[%08x]\t imgbase[%08x]\n", _channel, dest, src, imgbase);
	//}
		
       
/* 
//-------------------------------------------------------//
//                     Assertions
//-------------------------------------------------------//
    if(isDramToV)
    {
        AppFatal(isInDram(src), ("src(0x%08x) is not DRAM address (pc=0x%08x;ra=0x%08x)",
          src, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
        AppFatal(isInVbuf(dest), ("dest(0x%08x) is not VBuf address (pc=0x%08x;ra=0x%08x)", 
          dest, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
        AppFatal((dest & 0xF) == 0,
          ("dest(now 0x%x) is not quad-word-aliged (pc=0x%08x;ra=0x%08x)",
          dest, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
        AppFatal((src & 0x3) == 0,
          ("src(now 0x%x) is not word-aliged (pc=0x%08x;ra=0x%08x)",
          src, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
    }
    else
    {
        AppFatal(isInVbuf(src), ("src(0x%08x) is not VBuf address (pc=0x%08x;ra=0x%08x)",
          src, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
        AppFatal(isInDram(dest), ("dest(0x%08x) is not Dram address (pc=0x%08x;ra=0x%08x)",
          dest, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
        AppFatal((dest & 0x3) == 0,
          ("dest(now 0x%x) is not word-aliged (pc=0x%08x;ra=0x%08x)",
          dest, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
        AppFatal((src & 0xF) == 0,
          ("src(now 0x%x) is not quad-word-aliged (pc=0x%08x;ra=0x%08x)",
          src, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
    }
//-------------------------------------------------------//
*/

    setOnChipRegWord(SL2_OCR_DMA_STATUS, DMA_STATUS_4XNBLK);
    // TODO: Should we handle Memory::checkBreak()?
    // TODO: Check where DRAM is ready
    
    IsTrace(TRACE_LEVEL_DETAIL,
      ("drambase=0x%x;imgbase=0x%x;dest=0x%x;src=0x%x;img_w=%d\n",
        drambase,     imgbase,     dest,     src,     img_w));
	
	for(INT c = 0; c<count; c++) {
	     for (row = 0; row < 4; row++) {
	     	for (col = 0; col < 4; col++){
	        	voffset = c << 4 | (row << 2) | col;
		        doffset = row * img_w + col;  //pos
		        if (isDramToV)	{
	   		        //printf("To V-buffer: Address is [%08x] <- [%08x] \n", (dest + voffset), (src + doffset));
		        	mmu().copyDram2Sram((dest + voffset), (src + doffset), INT8_BYTE);
		       	}
		        else {
		        	mmu().copySram2Dram((dest + doffset), (src + voffset), INT8_BYTE);
					//printf("From V-buffer : Address is [%08x] <- [%08x] \n", (dest + doffset), (src + voffset));
		        }
		        	
		         IsTrace(TRACE_LEVEL_DETAIL, ("row=%d,col=%d,doffset=%x,voffset=%x\n",
		                row, col, doffset, voffset));
	    	}
	     }
		 if (isDramToV)
		 {
		     if(c==1) { //4x16 skip 2 4x4 blocks--Should be 1
	    	 	dest += SL2_DMA_VBUF_SKIP;
	     	}
	     	src += 4;
		 }
		 else
		 {
		     if(c==1) { //4x16 skip 2 4x4 blocks--Should be 1
	    	 	src += SL2_DMA_VBUF_SKIP;
	     	}
	     	dest += 4;

		 }
		 	
	}
	
    setOnChipRegWord(SL2_OCR_DMA_STATUS, DMA_STATUS_IDLE);        
    return 0;
}


/*
 * Load/Store 8x8 blocks from/to an image in Dram to/from vbuf
 */
INT SL2DMA::_exec8x8BlockXfer(BOOL isDramToV, BOOL isChromaLoad)
{
    ADDR dest = getOnChipRegWord(SL2_OCR_DMA_DST);
    ADDR src = getOnChipRegWord(SL2_OCR_DMA_SRC0);
    ADDR imgbase = getOnChipRegEIWord(SL2_OCR_EI_IMAGEBASE);
    ADDR drambase = getOnChipRegEIWord(SL2_OCR_EI_DRAMBASE);
    UWORD img = (UWORD) getOnChipRegEIWord(SL2_OCR_EI_IMAGESZ);


    INT img_w = img >> 16;      // TODO: Check whether the width in low bytes
    INT row = 0, col = 0;
    INT b4num = 0;              //Number of 4x4 blocks
    UINT doffset = 0;   //Dram offset
    UINT voffset = 0;   //Vbuf offset
    
    if (isChromaLoad)
        img_w >>= 1;   //  Chroma width helf of that of Luma

    //Calculate the physical address for dram address
    if (isDramToV)
        src += drambase + imgbase;
    else
        dest += drambase + imgbase;
        
        
//-------------------------------------------------------//
//                     Assertions
//-------------------------------------------------------//
/*
    if(isDramToV)
    {
        AppFatal(isInDram(src), ("src(0x%08x) is not Dram address (pc=0x%08x;ra=0x%08x)", src, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
        AppFatal(isInVbuf(dest), ("dest(0x%08x) is not Vbuf address (pc=0x%08x;ra=0x%08x)", dest, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
        AppFatal((dest & 0xF) == 0,
          ("dest(now 0x%x) is not quad-word-aliged (pc=0x%08x;ra=0x%08x)", dest)), MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31);
        AppFatal((src & 0x3) == 0,
          ("src(now 0x%x) is not word-aliged (pc=0x%08x;ra=0x%08x)", src, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
    }
    else
    {
        AppFatal(isInVbuf(src), ("src(0x%08x) is not Vbuf address (pc=0x%08x;ra=0x%08x)", src, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
        AppFatal(isInDram(dest), ("dest(0x%08x) is not DRAM address (pc=0x%08x;ra=0x%08x)", dest, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
        AppFatal((dest & 0x3) == 0,
          ("dest(now 0x%x) is not word-aliged (pc=0x%08x;ra=0x%08x)", dest, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
        AppFatal((src & 0xF) == 0,
          ("src(now 0x%x) is not quad-word-aliged (pc=0x%08x;ra=0x%08x)", src, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
    }
//-------------------------------------------------------//
*/

     setOnChipRegWord(SL2_OCR_DMA_STATUS, DMA_STATUS_8X8BLK);
    // TODO: Should we handle Memory::checkBreak()?
    // TODO: Check where DRAM is ready
    
    
    IsTrace(TRACE_LEVEL_DETAIL,("dest=0x%x;src=0x%x;img_w=%d\n", dest, src, img_w));

    for (b4num = 0; b4num < 4; b4num++) {
        for (row = 0; row < 4; row++) {
        	for (col = 0; col < 4; col++) {
            	voffset = b4num << 4 | (row << 2) | col;
            	doffset = ((b4num & 0x2) <<1)  * img_w   //block(row)
                        + ((b4num & 0x1) << 2)  //block(col)
                        + row * img_w + col;    //pos
	 	     	if (isDramToV)
		        	mmu().copyDram2Sram((dest + voffset), (src + doffset), INT8_BYTE);
		        else
		        	mmu().copySram2Dram((dest + doffset), (src + voffset), INT8_BYTE);
	        	                       

           		IsTrace(TRACE_LEVEL_DETAIL, ("b4num=%d,row=%d,col=%d,doffset=%x,voffset=%x\n",
                 	b4num, row, col, doffset, voffset));
           }
        }
    }
    setOnChipRegWord(SL2_OCR_DMA_STATUS, DMA_STATUS_IDLE);        
    return 0;
}


/*
 * Load/Store 16x16 blocks from/to an image in Dram to/from vbuf
 */
INT SL2DMA::_exec16x16BlockXfer(BOOL isDramToV, BOOL isChromaLoad)
{
    ADDR dest = getOnChipRegWord(SL2_OCR_DMA_DST);
    ADDR src = getOnChipRegWord(SL2_OCR_DMA_SRC0);
    ADDR imgbase = getOnChipRegEIWord(SL2_OCR_EI_IMAGEBASE);
    ADDR drambase = getOnChipRegEIWord(SL2_OCR_EI_DRAMBASE);
    UWORD img = (UWORD) getOnChipRegEIWord(SL2_OCR_EI_IMAGESZ);
    	
    INT img_w = img >> 16;      // TODO: Check whether the width in low bytes
    INT row = 0, col = 0;
    INT b4num = 0;              //Number of 4x4 blocks
    UINT doffset = 0;   //Dram offset
    UINT voffset = 0;   //Vbuf offset


    if (isChromaLoad)
        img_w >>= 1;   //  Chroma width helf of that of Luma

    //Calculate the physical address for dram address
    if (isDramToV)
        src += drambase + imgbase;
    else
        dest += drambase + imgbase;

/*        
//-------------------------------------------------------//
//                     Assertions
//-------------------------------------------------------//
    if(isDramToV)
    {
        AppFatal(isInDram(src), ("src(0x%08x) is not DRAM address (pc=0x%08x;ra=0x%08x)", src, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
        AppFatal(isInVbuf(dest), ("dest(0x%08x) is not Vbuf address (pc=0x%08x;ra=0x%08x)", dest, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
        AppFatal((dest & 0xF) == 0,
          ("dest(now 0x%x) is not quad-word-aliged (pc=0x%08x;ra=0x%08x)", dest, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
        AppFatal((src & 0x3) == 0,
          ("src(now 0x%x) is not word-aliged (pc=0x%08x;ra=0x%08x)", src, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
    }
    else
    {
        AppFatal(isInVbuf(src), ("src(0x%08x) is not Vbuf address (pc=0x%08x;ra=0x%08x)", src, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
        AppFatal(isInDram(dest), ("dest(0x%08x) is not DRAM address (pc=0x%08x;ra=0x%08x)", dest, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
        AppFatal((dest & 0x3) == 0,
          ("dest(now 0x%x) is not word-aliged (pc=0x%08x;ra=0x%08x)", dest, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
        AppFatal((src & 0xF) == 0,
          ("src(now 0x%x) is not quad-word-aliged (pc=0x%08x;ra=0x%08x)", src, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
    }
//-------------------------------------------------------//
*/
    setOnChipRegWord(SL2_OCR_DMA_STATUS, DMA_STATUS_16X16BLK);
    // TODO: Should we handle Memory::checkBreak()?
    // TODO: Check where DRAM is ready
    
    
    IsTrace(TRACE_LEVEL_DETAIL, ("dest=0x%x;src=0x%x;img_w=%d\n", dest, src, img_w));

    for (b4num = 0; b4num < 16; b4num++) {
        for (row = 0; row < 4; row++) {
            for (col = 0; col < 4; col++) {
		    	voffset = b4num << 4 | (row << 2) | col;
		     	doffset = ((b4num & 0x8) | ((b4num & 0x2)<<1)) * img_w   //block(row)
		                   + (((b4num & 0x4) << 1) | ((b4num & 0x1)<< 2)) //block(col)
		                   + row * img_w + col;           //pos
		                        
		      	IsTrace(TRACE_LEVEL_DETAIL, ("b4num=%d,row=%d,col=%d,doffset=%x,voffset=%x\n",
		             							b4num, row, col, doffset, voffset));
		              
	 	     	if (isDramToV)
		        	mmu().copyDram2Sram((dest + voffset), (src + doffset), INT8_BYTE);
		        else
		        	mmu().copySram2Dram((dest + doffset), (src + voffset), INT8_BYTE);
		              
            }
        }
    }
    setOnChipRegWord(SL2_OCR_DMA_STATUS, DMA_STATUS_IDLE);         
    return 0;
}


// TODO: Complete the comment
/*
 *  load search window from Dram to vbuf in the unit of 4x16 block
 *
 *                              Read from Dram
 *                              ==============
 *     src + dram_base + image_base
 *     |
 *     |
 *     v
 *  -------------------------------------------------------------------------
 *..| | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | |..
 *  -------------------------------------------------------------------------
 *
 *
 *
 *
 *                               Write to vbuf
 *                               =============
 *
 *
 *     Left padding start                                       real pix
 *     |   Top padding start                      Next top padding   |
 *     |   |     dest (DMAR_DST)             Next left padding |     |
 *     |   |     |                                         |   |     |
 *     v   v     v                                         v   v     v
 *  -------------------------------------------------------------------------
 *..| | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | |..
 *  -------------------------------------------------------------------------
 *               |<--- real img width -->|
 *     |<-------------------  swin width --------------->|
 *               |<-------------------  swin width --------------->|
 *
 *
 */
INT SL2DMA::_execSearchWin(void) {
    ADDR dest = getOnChipRegWord(SL2_OCR_DMA_DST);
    ADDR vsrc = getOnChipRegWord(SL2_OCR_DMA_SRC0);
    UWORD swin = (UWORD) getOnChipRegWord(SL2_OCR_DMA_WINSZ);
    UWORD realimg = (UWORD) getOnChipRegWord(SL2_OCR_DMA_REALSZ);
    UWORD padctrl = (UWORD) getOnChipRegWord(SL2_OCR_DMA_PADCTRL);
    ADDR imgbase = getOnChipRegEIWord(SL2_OCR_EI_IMAGEBASE);
    ADDR drambase = getOnChipRegEIWord(SL2_OCR_EI_DRAMBASE);
    UWORD img = (UWORD) getOnChipRegEIWord(SL2_OCR_EI_IMAGESZ);    

    ADDR src = drambase + imgbase + vsrc;
    INT img_w = img >> 16; // TODO: Check whether the width in high bytes
    INT swin_w = swin >> 16;
    INT realimg_w = realimg >> 16;
    INT realimg_h = realimg & 0xFFFF;

    const INT SEQ_LEN = 5;
    const enum EPAD seq[SEQ_LEN]
      = { EPAD_TOP, EPAD_LEFT, EPAD_REAL, EPAD_BOTTOM, EPAD_RIGHT};
    UINT pads[SEQ_LEN];

    INT row = 0, col = 0;
    INT rowmax = 0, colmax = 0;

    INT padoffset = 0; //padding offset to offset the real pixel
    UINT doffset = 0;   //Dram offset
    INT voffset = 0;   //Vbuf offset
    pads[EPAD_REAL]   =  ~(padctrl >> 31) & 0x1; //Real pixel disable (need negation)
    pads[EPAD_TOP]    = (padctrl >> 24) & 0x3F;
    pads[EPAD_BOTTOM] = (padctrl >> 16) & 0x3F;
    pads[EPAD_LEFT]   = (padctrl >>  8) & 0x3F;
    pads[EPAD_RIGHT]  =  padctrl        & 0x3F;

    BYTE buf[4*16];

	//printf("Source address is [%08x], swin [%08x], realImage[%08x]\n", src, swin, realimg);
	//printf("Padctontrol [%08x], imgbase [%08x], dest[%08x]\n", padctrl, imgbase, dest);
    
/*     
//-------------------------------------------------------//
//                     Assertions
//-------------------------------------------------------//
    AppFatal(isInDram(src), ("src(0x%08x) is not DRAM address (pc=0x%08x;ra=0x%08x)", src, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
    AppFatal((dest & 0xF) == 0,
      ("dest(now 0x%x) is not quad-word-aliged (pc=0x%08x;ra=0x%08x)", dest, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
    //AppFatal((src & 0x3) == 0,
    //  ("src(now 0x%x) is not word-aliged", src));
    AppFatal(pads[EPAD_REAL] != 0
      || (pads[EPAD_TOP] != 0 && pads[EPAD_BOTTOM] == 0 && pads[EPAD_LEFT] == 0
          && pads[EPAD_RIGHT] == 0)
      || (pads[EPAD_BOTTOM] != 0 && pads[EPAD_LEFT] == 0
          && pads[EPAD_RIGHT] == 0)
      || (pads[EPAD_LEFT] != 0 && pads[EPAD_RIGHT] == 0)
      || (pads[EPAD_RIGHT] != 0),
      ("incorrect padding(0x%08x) (pc=0x%08x;ra=0x%08x)", padctrl, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
      
    AppFatal(pads[EPAD_TOP]%4 == 0, ("Top padding(%d) should multiple of 4 (pc=0x%08x;ra=0x%08x)",
      pads[EPAD_TOP], MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
    AppFatal(pads[EPAD_BOTTOM]%4 == 0, ("bottom padding(%d) should multiple of 4 (pc=0x%08x;ra=0x%08x)",
      pads[EPAD_BOTTOM], MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
    AppFatal(pads[EPAD_LEFT]%4 == 0, ("left padding(%d) should multiple of 4 (pc=0x%08x;ra=0x%08x)",
      pads[EPAD_LEFT], MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
    AppFatal(pads[EPAD_RIGHT]%4 == 0, ("Top padding(%d) should multiple of 4 (pc=0x%08x;ra=0x%08x)",
      pads[EPAD_RIGHT], MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
//-------------------------------------------------------//
*/
    IsTrace(TRACE_LEVEL_DETAIL, ("img_w=%d,swin_w=%d,realimg_w=%d\n", img_w, swin_w, realimg_w));
      

    setOnChipRegWord(SL2_OCR_DMA_STATUS, DMA_STATUS_SEARCHWIN);
    
    for (INT seqidx = 0; seqidx < SEQ_LEN ; seqidx++)
    {
        if (pads[seq[seqidx]] > 0)
        {
            switch(seq[seqidx])
            {
                case EPAD_REAL:
                    rowmax = realimg_h >> 2;
                    colmax = realimg_w >> 4;
                    for (row = 0; row < rowmax; row++) {
                        for (col = 0; col < colmax; col++) {
	                        doffset = row * 4 * img_w + col * 16;
	                        _load4x16Block(buf, src + doffset, img_w);

							///*** WWD: How about Left parts
	                        voffset = row * 4 * swin_w + col * 4 * 16;
	                        _store4x16Block(dest + voffset, buf);
	                        
	//                        AppFatal(isInVbuf(dest + voffset), ("dest+voffset(0x%08x) is not Vbuf address", dest+voffset));
	                        IsTrace(TRACE_LEVEL_DETAIL, ("EPAD_REAL: doffset=%d,voffset=%d\n", doffset, voffset));
                        }
    
                    } /* end of for (row...) for (col...) */
                    break;

 
                case EPAD_TOP:
                    rowmax = pads[EPAD_TOP] >> 2;
                    colmax = realimg_w >> 4;
                    padoffset = -1 * ( pads[EPAD_TOP] * swin_w);
                    for (col = 0; col < colmax; col++) {
                        doffset = col * 16;
                        _load4x16Block(buf, src + doffset, img_w);
                        for (row = 0; row < rowmax; row++) {
                            voffset = padoffset + row * 4 * swin_w + col * 4 * 16;
                            _storePad(dest + voffset, buf, 16, 4, EPAD_TOP);
	//                        AppFatal(isInVbuf(dest + voffset), ("dest+voffset(0x%08x) is not Vbuf address", dest+voffset));                              dest+voffset, 
                            IsTrace(TRACE_LEVEL_DETAIL, ("EPAD_TOP: doffset=%d,voffset=%d\n", doffset, voffset));
                        } /* end of for (row...) */
                    } /* end of for (col...) */
                    break;
                                        

                case EPAD_LEFT: 
                    rowmax = realimg_h >> 2;
                    colmax = pads[EPAD_LEFT] >> 2;
                    padoffset = -1 * pads[EPAD_LEFT] * 4;
                    for (row = 0; row < rowmax; row++) {
                        doffset = row * 4 * img_w;
                        _load4x16Block(buf, src + doffset, img_w);
                        for (col = 0; col < colmax; col++) {
                            voffset = padoffset + row * 4 * swin_w + col * 4 * 4;
                            _storePad(dest + voffset, buf, 4, 4, EPAD_LEFT);

	//                        AppFatal(isInVbuf(dest + voffset), ("dest+voffset(0x%08x) is not Vbuf address", dest+voffset));
                            IsTrace(TRACE_LEVEL_DETAIL, ("EPAD_LEFT: doffset=%d,voffset=%d\n", doffset, voffset));
                        } /* end of for (col...) */
                    } /* end of for (row...) */
                    break;

                    
                case EPAD_BOTTOM:
                    rowmax = pads[EPAD_BOTTOM] >> 2;
                    colmax = realimg_w >> 4;
                    padoffset = realimg_h * swin_w;
                    for (col = 0; col < colmax; col++)  {
                        doffset = (realimg_h - 4) * img_w /* offset to in the last row */
                                  + col * 16;
                        _load4x16Block(buf, src + doffset, img_w);
                        for (row = 0; row < rowmax; row++) {
                            voffset = padoffset + row * 4 * swin_w + col * 4 * 16;
                            _storePad(dest + voffset, buf, 16, 4, EPAD_BOTTOM);
	//                        AppFatal(isInVbuf(dest + voffset), ("dest+voffset(0x%08x) is not Vbuf address", dest+voffset));
                            IsTrace(TRACE_LEVEL_DETAIL, ("EPAD_BOTTOM: doffset=%d,voffset=%d\n", doffset, voffset));
                        } /* end of for (row...) */
                    } /* end of for (col...) */
                    break;
                    
                case EPAD_RIGHT:
                    rowmax = realimg_h >> 2;
                    colmax = pads[EPAD_RIGHT] >> 2;
                    padoffset = realimg_w * 4;
                    for (row = 0; row < rowmax; row++) {
                        doffset = row * 4 * img_w + (realimg_w - 16); /* Offset to the last block in row */
                        _load4x16Block(buf, src + doffset, img_w);
                        for (col = 0; col < colmax; col++) {
                            voffset = padoffset + row * 4 * swin_w + col * 4 * 4;
                            _storePad(dest + voffset, buf, 4, 4, EPAD_RIGHT);
	//                        AppFatal(isInVbuf(dest + voffset), ("dest+voffset(0x%08x) is not Vbuf address", dest+voffset));
                            IsTrace(TRACE_LEVEL_DETAIL,
                              ("EPAD_RIGHT: doffset=%d,voffset=%d\n", doffset, voffset));
                        } /* end of for (col...) */
                    } /* end of for (row...) */
                    break;
                    
                
                default:
                  AppFatal((0), ("unknown value in seq: (EPAD) %d", seq[seqidx]));
            } //end of switch (seq[seqidx])

        } //end of if (pads[seq[seqidx > 0]])
    }
	setOnChipRegWord(SL2_OCR_DMA_STATUS, DMA_STATUS_IDLE);                     
    return 0;
}


/*
 * Load from 4 different sources, and generate a 4x4 block from a 3x3 block
 * From each source.  Write them to 4 consecutive vbuf locations.
 * 
 * Data arrangement from 3x3 block to 4x4 block
 * 
 *   P1,P2,P3         P1,P2,P4,P5
 *   P4,P5,P6         P2,P3,P5,P6
 *   P7,P8,P9 =>   P4,P5,P7,P8
 *                        P5,P6,P8,P9
 * 
 *   3x3 block        4x4 block
 * 
 * Note: Block is loaded from an image, so take image width into account
 *       when calculate the offset for the pixel other than the first row
 */
INT SL2DMA::_execChroma(void) {
    ADDR dest = getOnChipRegWord(SL2_OCR_DMA_DST);
    ADDR imgbase = getOnChipRegEIWord(SL2_OCR_EI_IMAGEBASE);
    ADDR drambase = getOnChipRegEIWord(SL2_OCR_EI_DRAMBASE);
	///*** WWD changed
//    UWORD img = (UWORD) getOnChipRegEIWord(SL2_OCR_EI_IMAGESZ);
	UWORD img = (UWORD) getOnChipRegWord(SL2_OCR_DMA_CIMAGESZ);

    INT img_w = img >> 16; // TODO: Check whether the width in low bytes
    const INT srcsmax = 4;
    INT srcidx = 0;
    ADDR srcs[srcsmax];
    INT row = 0, col = 0;
    const INT rowmax = 4, colmax = 4;
    
    //Data arrangement from 3x3 block to 4x4 block
    const INT map[rowmax][colmax] = { {1, 2, 4, 5},
                                      {2, 3, 5, 6},
                                      {4, 5, 7, 8},
                                      {5, 6, 8, 9} };
    INT offset = 0; //pixel offset

    srcs[0] = drambase + imgbase + getOnChipRegWord(SL2_OCR_DMA_SRC0);
    srcs[1] = drambase + imgbase + getOnChipRegWord(SL2_OCR_DMA_SRC1);
    srcs[2] = drambase + imgbase + getOnChipRegWord(SL2_OCR_DMA_SRC2);
    srcs[3] = drambase + imgbase + getOnChipRegWord(SL2_OCR_DMA_SRC3);
  
  	//printf("Chroma image size is [%08x]\n", img);
/*       
//-------------------------------------------------------//
//  Assertions
//-------------------------------------------------------//
    AppFatal(isInDram(srcs[0]), ("src0(0x%08x) is not DRAM address (pc=0x%08x;ra=0x%08x)", srcs[0], MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
    AppFatal(isInDram(srcs[1]), ("src1(0x%08x) is not DRAM address (pc=0x%08x;ra=0x%08x)", srcs[1], MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
    AppFatal(isInDram(srcs[2]), ("src2(0x%08x) is not DRAM address (pc=0x%08x;ra=0x%08x)", srcs[2], MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
    AppFatal(isInDram(srcs[3]), ("src3(0x%08x) is not DRAM address (pc=0x%08x;ra=0x%08x)", srcs[3], MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
    AppFatal(isInVbuf(dest), ("dest(0x%08x) is not VBbuf address (pc=0x%08x;ra=0x%08x)", dest, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
    AppFatal((dest & 0xF) == 0,
      ("dest(now 0x%x) is not quad-word-aliged (pc=0x%08x;ra=0x%08x)", dest, MachineCore::getInstance().getPC(), PacRegsUnit::getInstance().getValue(REG_R31)));
//-------------------------------------------------------//
*/

    setOnChipRegWord(SL2_OCR_DMA_STATUS, DMA_STATUS_CHROMA);        
    
    for (srcidx = 0; srcidx < srcsmax; srcidx++) {
       for (row = 0; row < rowmax; row++) {
          for (col = 0; col < colmax; col++) {
	          IsTrace(TRACE_LEVEL_DETAIL, ("row=%d,col=%d,offset=%x,'%c'\n",
	                      row, col, offset, _memory.readByte(srcs[srcidx] + offset)));
	           AppFatal(map[row][col] >= 1 && map[row][col] <= 9,
	               ("map[%d][%d]=%d should within [1,9]", row, col, map[row][col]));
	
	            
	           offset = ((map[row][col] - 1) / 3) * img_w 
	                      + (map[row][col] - 1) % 3;
	           mmu().copyDram2Sram((dest + row * 16 + col + srcidx * 4), 
	           								(srcs[srcidx] + offset), INT8_BYTE);  
			   //printf("Size: [%08x], From Addr [%08x] --> Addr [%08x]\n", img, (srcs[srcidx] + offset), (dest + row * 16 + col + srcidx * 4));
          }
       }
    }
    setOnChipRegWord(SL2_OCR_DMA_STATUS, DMA_STATUS_IDLE);  

    return 0;
}


INT SL2DMA::_execConst(void) {
	WORD size = getOnChipRegWord(SL2_OCR_DMA_SIZE);
    ADDR dest = getOnChipRegWord(SL2_OCR_DMA_DST);
    BYTE value = (BYTE) getOnChipRegWord(DMAR_CONST);
    	
 	setOnChipRegWord(SL2_OCR_DMA_STATUS, DMA_STATUS_BROADCAST);  

    // TODO: Should we handle Memory::checkBreak()?
    // TODO: Check where DRAM is ready if dest is dram
    
    mmu().initBlock(dest, value, size);
        
	setOnChipRegWord(SL2_OCR_DMA_STATUS, DMA_STATUS_IDLE);          
    return 0;
}


/*
 * Load a 4x16 block from the memory
 */
void SL2DMA::_load4x16Block(BYTE *data, ADDR src, UINT win_w)
{
    _loadBlock(data, src, 4, 16, win_w);
}

void SL2DMA::_loadBlock(BYTE *data, ADDR src, UINT w, UINT h, UINT win_w)
{
    UINT row, col, idx = 0;
    for (row = 0; row < w; row++)
    {
        for (col = 0; col < h; col++)
            data[idx++] = mmu().getByte(src+col);

        src += win_w;
    }
}

/*
 * Store a 4x16 block to the vbuf memory
 *
 * 0123456789ABCDEF           0123 0123 0123 0123
 * 0123456789ABCDEF    ->   4567 4567 4567 4567
 * 0123456789ABCDEF           89AB 89AB 89AB 89AB
 * 0123456789ABCDEF           CDEF CDEF CDEF CDEF
 *
 *                                   Bank 0-3   4-7   8-B   C-F
 *
 * 4x16 block (data)                 vbuf
 *
 */
void SL2DMA::_store4x16Block(ADDR dest, BYTE *data)
{
    _storePad(dest, data, 16, 4, EPAD_REAL);
}

/*
 * Store a padding (4x4/4x16 block) to the vbuf memory
 *
 * padtype: EPAD_REAL
 *
 * 0123456789ABCDEF           0123 AAAA 0123 XXXX
 * AAAAAAAABBBBBBBB    ->     4567 AAAA 4567 XXXX
 * 0123456789ABCDEF           89AB BBBB 89AB YYYY
 * XXXXXXXXYYYYYYYY           CDEF BBBB CDEF YYYY
 *
 *                        Bank 0-3  4-7  8-B  C-F
 *
 * 4x16 block (data)                 vbuf
 *
 *
 *
 * padtype: EPAD_TOP - Use only the first row
 *
 * 0123456789ABCDEF           0123 0123 0123 0123
 * AAAAAAAABBBBBBBB ->   4567 4567 4567 4567
 * 0123456789ABCDEF           89AB 89AB 89AB 89AB
 * XXXXXXXXYYYYYYYY          CDEF CDEF CDEF CDEF
 *
 *                        Bank 0-3  4-7  8-B  C-F
 *
 * 4x16 block (data)                 vbuf
 *
 *
 *
 * padtype: EPAD_BOTTOM - Use only the last row
 *
 * 0123456789ABCDEF           XXXX XXXX XXXX XXXX
 * AAAAAAAABBBBBBBB    ->     XXXX XXXX XXXX XXXX
 * 0123456789ABCDEF           YYYY YYYY YYYY YYYY
 * XXXXXXXXYYYYYYYY           YYYY YYYY YYYY YYYY
 *
 *                        Bank 0-3  4-7  8-B  C-F
 *
 * 4x16 block (data)                 vbuf
 *
 *
 *
 * padtype: EPAD_LEFT - Use only the first column
 *
 * 0123456789ABCDEF           0000 AAAA 0000 XXXX
 * AAAAAAAABBBBBBBB    ->     
 * 0123456789ABCDEF           
 * XXXXXXXXYYYYYYYY           
 *
 *                        Bank 0-3  4-7  8-B  C-F
 *
 * 4x16 block (data)                 vbuf
 *
 *
 *
 * padtype: EPAD_RIGHT - Use only the last column
 *
 * 0123456789ABCDEF           FFFF BBBB FFFF YYYY
 * AAAAAAAABBBBBBBB    ->     
 * 0123456789ABCDEF           
 * XXXXXXXXYYYYYYYY           
 *
 *                        Bank 0-3  4-7  8-B  C-F
 *
 * 4x16 block (data)                 vbuf
 */
void SL2DMA::_storePad(ADDR dest, BYTE *data, UINT pad_w, UINT pad_h, EPAD padtype)
{
    UINT row, col;
    BOOL keeprow=FALSE, keepcol=FALSE;
    INT keeprow_val = 0, keepcol_val = 0;
    INT coffset;
    char buf[16];

    switch(padtype)
    {
        case EPAD_REAL:
            break;
        case EPAD_TOP:
            keeprow = TRUE;
            keeprow_val = 0x0;
            break;
        case EPAD_BOTTOM:
            keeprow = TRUE;
            keeprow_val = 0x30;
            break;
        case EPAD_LEFT:
            keepcol = TRUE;
            keepcol_val = 0x0;
            break;
        case EPAD_RIGHT:
            keepcol = TRUE;
            keepcol_val = 0xF;
            break;
        default:
            AppFatal((0), ("unknown value in padtype: (EPAD) %d", padtype));
    }

    for (row = 0; row < pad_h; row++)
    {
        for (col = 0; col < pad_w; col++)
        {
            coffset = -1*keepcol*((col&0x3) + (row<<2)) + keepcol*row*16 + keepcol_val
                      -1*keeprow*((col&0xc)<<2) + keeprow_val;
            mmu().setByte(dest+(col)+pad_w*(row), 
              data[ (col&0x3) + (row <<2) + ((col&0xc)<<2) + coffset]);
              /*     col idx    col offset    row offset   cancellation offset */
        }
    }


//============================================================
//                     TRACE
//============================================================
// Display the content of data and the content of destination

    IsTrace(TRACE_LEVEL_DETAIL,("data:\n"));
    IsTrace(TRACE_LEVEL_DETAIL,("%.16s\n", (char *)data));
    IsTrace(TRACE_LEVEL_DETAIL,("%.16s\n", (char *)data + 16));
    IsTrace(TRACE_LEVEL_DETAIL,("%.16s\n", (char *)data + 32));
    IsTrace(TRACE_LEVEL_DETAIL,("%.16s\n", (char *)data + 48));

    IsTrace(TRACE_LEVEL_DETAIL,("dest:\n"));
    for (row = 0; row < pad_h; row++)
    {
        for (col = 0; col < pad_w; col++)
        {
             coffset = -1*keepcol*((col&0x3) + (row<<2)) + keepcol*row*16 + keepcol_val
                       -1*keeprow*((col&0xc)<<2) + keeprow_val;
             buf[col] = data[ (col&0x3) + (row<<2) + ((col&0xc)<<2) + coffset];
             IsTrace(TRACE_LEVEL_DETAIL, ("total(%d),"
               "(col&0x3)(%d),(row<<2)(%d),((col&0xc)(%d),coffset(%d)"
               "col(%d),row(%d)\n",
               (col&0x3) + (row<<2) + ((col&0xc)<<2) + coffset,
               (col&0x3) , (row<<2) , ((col&0xc)<<2), coffset,
               col, row));
        }

        if (pad_w == 16)
          IsTrace(TRACE_LEVEL_DETAIL, ("%.16s\n", buf));
        else if (pad_w == 4)
          IsTrace(TRACE_LEVEL_DETAIL, ("%.4s\n", buf));
        else
          AppFatal((0), ("Invalid value of pad_w (%d)", pad_w));
    }
//==================END OF TRACE ===============================

} /* DMA::storePad */


INT SL2DMA::_execStrideXfer(void) {
	WORD size = getOnChipRegWord(SL2_OCR_DMA_SIZE);
    ADDR src = getOnChipRegWord(SL2_OCR_DMA_SRC0);
    ADDR dest = getOnChipRegWord(SL2_OCR_DMA_DST);
    WORD stride = getOnChipRegWord(SL2_OCR_DMA_STRIDE);
    ADDR src_off = getOnChipRegWord(SL2_OCR_DMA_SRCOFFSET);
    ADDR dest_off = getOnChipRegWord(SL2_OCR_DMA_DESTOFFSET);
    WORD done_size = 0;

	if(mmu().isVbuf(dest)==TRUE){
		AppFatal((stride<=SL2_DMA_STRIDE_MAX), ("SL2DMA: invalid stride value", stride));
		AppFatal(((dest_off&SL2_DMA_STRIDE_ADDR_MASK)==0), ("SL2DMA: invalid dest_off value", dest_off));
	}
	if(mmu().isVbuf(src)==TRUE){
		AppFatal((stride<=SL2_DMA_STRIDE_MAX), ("SL2DMA: invalid stride value", stride));
		AppFatal(((src_off&SL2_DMA_STRIDE_ADDR_MASK)==0), ("SL2DMA: invalid src_off value", src_off));
	}	
        	
 	setOnChipRegWord(SL2_OCR_DMA_STATUS, DMA_STATUS_STRIDE);  

    // TODO: Should we handle Memory::checkBreak()?
    // TODO: Check where DRAM is ready if dest is dram
    while(done_size < size) {
    	//for(INT i = 0; i<stride; i++) {
			//printf("[%08x] <-- [%08x] --- destoff[%04x], sourceoff[%04x]\n", dest, src, dest_off, src_off);
    		mmu().copyDMAByte(dest, src, stride);
    		done_size += stride;
    		dest += dest_off;
    		src += src_off;
    	//}
    }
        
	setOnChipRegWord(SL2_OCR_DMA_STATUS, DMA_STATUS_IDLE);          
    return 0;	
}

INT SL2DMA::_execRecoderXfer(void) {
	WORD size = getOnChipRegWord(SL2_OCR_DMA_SIZE);
    ADDR src = getOnChipRegWord(SL2_OCR_DMA_SRC0);
    ADDR dest = getOnChipRegWord(SL2_OCR_DMA_DST);
    WORD type = getOnChipRegWord(SL2_OCR_DMA_DATATYPE);

	AppFatal((size%SL2_DMA_VBUF_OFFSET==0), ("SL2DMA: invalid data size", size));
	AppFatal((type==0||type==1), ("SL2DMA: invalid datatype", type));

    WORD byte_size = type==0? HWORD_BYTE : WORD_BYTE;
    WORD done_size = 0;
    BYTE buf[64];

 	setOnChipRegWord(SL2_OCR_DMA_STATUS, DMA_STATUS_RECORDING);  

    // TODO: Should we handle Memory::checkBreak()?
    // TODO: Check where DRAM is ready if dest is dram
    while(done_size < size) {
    	for(INT i = 0; i<(byte_size*SL2_DMA_VBUF_OFFSET); i++) {
			buf[i] = mmu().getByte(src+i);
			//printf("addr[%08x] value[%02x]\n", src+i, buf[i]);
    	}
    	//printf("\n\n");
    	if(mmu().isVbuf(dest)==TRUE) {
	     	for(INT i = 0; i<SL2_DMA_VBUF_OFFSET; i++) {
	     		for(INT j = 0; j<byte_size; j++) {
	     			ADDR dest_addr = dest + i + SL2_DMA_VBUF_OFFSET*j;
					mmu().setByte(dest_addr, buf[(i*byte_size) + j]);
					//printf("addr[%08x] value[%02x]\n", dest_addr, buf[(i*byte_size) + j]);
	     		}
	    	}   		
    	}
    	else {
	     	for(INT i = 0; i<SL2_DMA_VBUF_OFFSET; i++) {
	     		for(INT j = 0; j<byte_size; j++) {
	     			ADDR dest_addr = dest + (i*byte_size) + j;
					mmu().setByte(dest_addr, buf[i + (SL2_DMA_VBUF_OFFSET*j)]);
	     		}
	    	}     		
    	}
    	
    	done_size += (SL2_DMA_VBUF_OFFSET*byte_size);
    	src       += (SL2_DMA_VBUF_OFFSET*byte_size);
    	dest      += (SL2_DMA_VBUF_OFFSET*byte_size);
    	
    }
        
	setOnChipRegWord(SL2_OCR_DMA_STATUS, DMA_STATUS_IDLE);          
    return 0;		
}


