#include "sl2decoder.h"
#include "sl2reg.h"
#include "sl2mmu.h"
#include "sl2instrtable.h"
#include "sl2instrid.h"

SL2Decoder::SL2Decoder() : CoreDecoder<SL2Instr>(TRUE) { 
	setMode(SL2_INSTR_MODE); 
}

SL2Decoder::SL2Decoder(BOOL b) : CoreDecoder<SL2Instr>(b) { 
	setMode(SL2_INSTR_MODE); 
}

UINT32 SL2Decoder::decode(SL2Instr* instr,  ADDR pc, WORD raw) {
	SL2InstrTableEntry* entry;
	DEBUG_DECODE("Entering CoreDecoder::decode\n");
	UINT size = 0;
	UBYTE gr = EGROUP_INVALID;
	union {
		WORD rawbits;
		struct {
			unsigned lv2 : 6;
			unsigned na : 10;
			unsigned lv2s : 5;
			unsigned lv2g1 : 5;
			unsigned top :6;
		} bits;
		struct {
			unsigned na : 23;
			unsigned lv2 : 6;
			unsigned top : 3;
		} c2bits;			
	} rb;	
	rb.rawbits = raw;
	gr = getGroupID(rb.bits.top);
	
	if(IS_CORE_INSTR16(gr)) {
		if((pc&WORD_ALIGN_MASK)==0) {
			raw <<= INT16_BIT;
			rb.rawbits = raw;
			gr = getGroupID(rb.bits.top);
			AppFatal((IS_CORE_INSTR16(gr)), ("Decoder: Invalid 16 bits instruction (pc=%08x, raw=%08x)", pc, raw));
		}
		else {
			raw &= UPPER_HWORD_DATA_MASK;
		}
	}

	switch (gr) {
		case EGROUP_TOP:
		case EGROUP_TOP_16:
			entry = &Top_Table[rb.bits.top];
			break;
		case EGROUP_G0:
			entry = &G0_Table[rb.bits.lv2];
			break;
		case EGROUP_G1:
			entry = &G1_Table[rb.bits.lv2g1];
			break;		
		case EGROUP_G2:
			entry = &G2_Table[rb.bits.lv2s];
			break;	
		case EGROUP_C2:
			entry = &C2_Table[rb.c2bits.lv2];
			break;					
		case EGROUP_C3:
			entry = &C3_Table[rb.bits.lv2];
			break;		
		default:
			if(assertInvalidInstr()==TRUE) {
				AppFatal((0), ("Decoder: Invalid instruction group (pc=%08x, raw=%08x, gr=%d)", pc, raw, gr));
			}
			else {
				return INT32_BYTE;	
			}
			break;
	}
	
	if(entry->enable(mode())) {
		instr->init(entry, raw);
		size = (this->*(entry->decode()))(instr, 0);
		instr->instrsize(size);
		instr->pc(pc);
	}
	else{
		if(assertInvalidInstr()==TRUE) {
			AppFatal((0), ("Decoder: Invalid instruction group (pc=%08x, raw=%08x, gr=%d)", pc, raw, gr));
		}
		else {
			return INT32_BYTE;	
		}
	}
	return size;
}

UINT32 SL2Decoder::decode(SL2Instr* instr,  ADDR pc, WORD raw, UINT meta) {
	SL2InstrTableEntry* entry;
	DEBUG_DECODE("Entering CoreDecoder::decode\n");
	UINT size = 0;
	UBYTE gr = EGROUP_INVALID;
	union {
		WORD rawbits;
		struct {
			unsigned lv2 : 6;
			unsigned na : 10;
			unsigned lv2s : 5;
			unsigned lv2g1 : 5;
			unsigned top :6;
		} bits;
		struct {
			unsigned na : 23;
			unsigned lv2 : 6;
			unsigned top : 3;
		} c2bits;			
	} rb;	
	rb.rawbits = raw;
	gr = getGroupID(rb.bits.top);
	
	switch (gr) {
		case EGROUP_TOP:
		case EGROUP_TOP_16:
			entry = &Top_Table[rb.bits.top];
			break;
		case EGROUP_G0:
			entry = &G0_Table[rb.bits.lv2];
			break;
		case EGROUP_G1:
			entry = &G1_Table[rb.bits.lv2g1];
			break;		
		case EGROUP_G2:
			entry = &G2_Table[rb.bits.lv2s];
			break;	
		case EGROUP_C2:
			entry = &C2_Table[rb.c2bits.lv2];
			break;					
		case EGROUP_C3:
			entry = &C3_Table[rb.bits.lv2];
			break;		
		default:
			if(assertInvalidInstr()==TRUE) {
				AppFatal((0), ("Decoder: Invalid instruction group (pc=%08x, raw=%08x, gr=%d)", pc, raw, gr));
			}
			else {
				return INT32_BYTE;	
			}
			break;
	}
	
	if(entry->enable(mode())) {
		instr->init(entry, raw);
		size = (this->*(entry->decode()))(instr, meta);
		instr->instrsize(size);
		instr->pc(pc);
	}
	else{
		if(assertInvalidInstr()==TRUE) {
			AppFatal((0), ("Decoder: Invalid instruction group (pc=%08x, raw=%08x, gr=%d)", pc, raw, gr));
		}
		else {
			return INT32_BYTE;	
		}
	}
	return size;
}

#if 0
UINT32 SL2Decoder::decodeC2_temp_mul (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op : 6;
			unsigned na2 : 5;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd : 5;
			unsigned top :6;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
	instr->rs2(rb.bits.rs2);
	instr->rs1(rb.bits.rs1);
	instr->rd(rb.bits.rd);
	return INT32_BYTE;	
}
#endif


// BR
UINT32 SL2Decoder::decodeC2_br (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			signed offset : 23;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	INT simm;
	rb.rawbits = instr->rawbits();	
	simm = rb.bits.offset;
	instr->offset(simm);
	//instr->c2cs1(ECR_COND);	
	return INT32_BYTE; 
}

UINT32 SL2Decoder::decodeC2_fork (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			signed offset : 22;
			unsigned mjr_fk : 1;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	INT simm;
	rb.rawbits = instr->rawbits();	
	simm = rb.bits.offset;
	instr->offset(simm);
	instr->mjr_fk(rb.bits.mjr_fk);
	return INT32_BYTE;
}

UINT32 SL2Decoder::decodeC2_joint (SL2Instr* instr, UINT meta) {
	return INT32_BYTE;	
}

// LS
UINT32 SL2Decoder::decodeC2_ld (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned multi : 1;
			unsigned size : 2;
			unsigned sign_ext : 1;
			unsigned swap : 1;
			unsigned sw_mv : 1;
			unsigned scalar : 2; //scalar workaround
			unsigned rs2 : 5;
			unsigned na2 : 5;
			unsigned rd1 : 5;
			unsigned op_mode : 2;
			unsigned imm1 : 1;
			unsigned top :6;
		} bits_gpr;
		struct {
			unsigned offset : 14;
			unsigned multi_offset14 : 1;
			unsigned size : 2;
			unsigned sign_ext : 1;
			unsigned rd1_cd : 5;
			unsigned op_mode : 2;
			unsigned imm1 : 1;
			unsigned top :6;
		} bits_imm;		
	}rb;
	UINT uimm = 0;
	rb.rawbits = instr->rawbits();
	instr->imm1(rb.bits_gpr.imm1);
	instr->op_mode(rb.bits_gpr.op_mode);
	if(rb.bits_gpr.imm1==0) {
		instr->size(rb.bits_gpr.size);
		instr->sign_ext(rb.bits_gpr.sign_ext);
		instr->swap(rb.bits_gpr.swap);
		instr->sw_mv(rb.bits_gpr.sw_mv);
		instr->multi(rb.bits_gpr.multi);
		AppFatal(((rb.bits_gpr.sw_mv==0) || (rb.bits_gpr.sw_mv==1&&rb.bits_gpr.size==2)), ("SL2Decoder: c2ld sw_mv==1 while size==2"));	
	}
	else{
		uimm = rb.bits_imm.offset;
		instr->multi(rb.bits_imm.multi_offset14);
		instr->size(rb.bits_imm.size);
		instr->sign_ext(rb.bits_imm.sign_ext);	
		instr->sw_mv(0);	
		instr->swap(0);	
	}
	switch(rb.bits_gpr.op_mode) {
		case 0: //VB-RF
			if(instr->size()==1) {
				instr->rd1_simd_pair(rb.bits_gpr.rd1);
			}
			else {
				instr->rd1_simd(rb.bits_gpr.rd1);
			}
			instr->c2cs2(EC2CR_LS_CTRL);
			if(rb.bits_imm.imm1==0) {
				instr->c2cs3(EC2CR_LS_SW);
				instr->rs2(rb.bits_gpr.rs2);
			}	
			else {
				instr->offset(uimm);
			}
			if (instr->sw_mv()==1)
				instr->c2spec1(ERS_WRITE, EC2SPEC_MOV_PAT);	
			break;	
		case 1: //VB-GPR
			instr->rd(rb.bits_gpr.rd1);
			if(rb.bits_imm.imm1==0) {
				instr->rs2(rb.bits_gpr.rs2);
			}
			else {
				instr->multi(0);
				instr->offset(((rb.bits_imm.multi_offset14<<14) | uimm));
			}	
			AppFatal((instr->macro()==0), ("SL2Decoder: c2ld invalid non-zero macro bit"));		
			break;
		case 2: //SB->GPR
			instr->rd(rb.bits_gpr.rd1);
			if(rb.bits_imm.imm1==0) {
				instr->rs2(rb.bits_gpr.rs2);
			}
			else {
				instr->offset(((rb.bits_imm.multi_offset14<<14) | uimm));
			}	
			AppFatal((instr->macro()==0), ("SL2Decoder: c2ld invalid non-zero macro bit"));			
			break;		
		case 3:
			instr->offset(uimm);
			instr->cd(rb.bits_imm.rd1_cd);
			AppFatal((instr->macro()==0), ("SL2Decoder: c2ld invalid non-zero macro bit"));
			break;	
		default:		
			AppFatal((0), ("SL2 Decode: invaild C2ld op_mode (%d).", rb.bits_imm.op_mode));
			break;					
	}
	if(instr->multi()==1) {
		instr->group(EIG_c2_macro);
	}
	if(meta!=0) {
		UINT rd1;
		UINT rd;
		UINT i = 0;
		instr->group(EIG_c2_macro);
		switch(instr->op_mode()) {
			case 0: rd = instr->rd1_simd();	break;
			case 1: rd = instr->rd(); break;
			default:		
				AppFatal((0), ("SL2 Decode: invaild C2ld op_mode for macro (%d).", rb.bits_imm.op_mode));
				break;				
		}
		
		for(i = 0; i<meta; i++) {
			SL2Instr *uCode = new SL2Instr;
			uCode->init(&Top_Table[c2ld_op], 0);
			uCode->size(instr->size());
			uCode->sign_ext(instr->sign_ext());
			uCode->swap(instr->swap());
			uCode->sw_mv(instr->sw_mv());
			uCode->multi(instr->multi());
			uCode->scalar(0);
			uCode->imm1(instr->imm1());
			uCode->op_mode(instr->op_mode());
			switch(instr->op_mode()) {
				case 0: //VB-RF
					switch (instr->size()) {
						case SL2_LS_BYTE:
							rd1 = rd + i; 
							break;
						case SL2_LS_HWORD:
						case SL2_LS_WORD:
							rd1 = rd + (int)i/2;
							if((i%INT16_BYTE)==1) { 
								uCode->rd1_simd(rd1);
							}
							break;						
						default:		
							AppFatal((0), ("SL2 Decoder: invaild C2ld size (%d).", instr->size()));
								break;					
					}	
					if(i==0) {
						uCode->c2cs2(EC2CR_LS_CTRL);
					}
					if(instr->imm1()==0) {
						if(i==0) {
							uCode->rs2(instr->rs2());
							uCode->c2cs3(EC2CR_LS_SW);
							if(instr->sw_mv()==1) {
								uCode->c2spec1(ERS_WRITE, EC2SPEC_MOV_PAT);
							}	
						}
					}	
					else {
						uCode->offset(instr->offset());
					}					
					break;
				case 1: //VB-GPR
					AppFatal((i<INT32_BYTE), ("SL2 Decoder: invaild C2ld macro cnt (%d) in VB-GPR.", i));
					switch (instr->size()) {
						case SL2_LS_HWORD:
							if((i%INT16_BYTE)==1) { 
								uCode->rd(rd);
							}
							break;							
						case SL2_LS_WORD:
							if((i%INT32_BYTE)==3) { 
								uCode->rd(rd);
							}
							break;						
						default:		
							AppFatal((0), ("SL2 Decoder: invaild C2ld size (%d).", instr->size()));
							break;					
					}						
					if(rb.bits_imm.imm1==0) {
						if(i==0) {
							uCode->rs2(rb.bits_gpr.rs2);
						}
					}
					else {
						uCode->offset(((rb.bits_imm.multi_offset14<<14) | uimm));
					}						
					break;
				default:		
					AppFatal((0), ("SL2 Decode: invaild C2ld op_mode for macro (%d).", rb.bits_imm.op_mode));
					break;				
			}
			instr->setMacro(uCode, i);
		}
		instr->macroCnt(i);	
		instr->multi(1);
	}

	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_mvgc (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned na2 : 5;
			unsigned dir : 1;
			unsigned na1 : 7;
			unsigned rs1_cs : 5;
			unsigned rd1_cd : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->dir(rb.bits.dir);
	if(rb.bits.dir==1) { 
		instr->c2cd(rb.bits.rd1_cd);
		instr->rs1(rb.bits.rs1_cs);
	}
	else {
		instr->rd(rb.bits.rd1_cd);
		instr->c2cs1(rb.bits.rs1_cs);		
	}	

	return INT32_BYTE;	
}

UINT32 SL2Decoder::decodeC2_mvgr (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned bc_dir : 1;
			unsigned size : 2;
			unsigned sign_ext : 1;
			unsigned imm_bank : 1;
			unsigned dir : 1;
			unsigned op_mode : 2;
			unsigned bank_rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->dir(rb.bits.dir);
	instr->op_mode(rb.bits.op_mode);
	instr->sign_ext(rb.bits.sign_ext);
	instr->bc_dir(rb.bits.bc_dir);
	instr->size(rb.bits.size);	
	if(rb.bits.dir==1) {
		instr->rs1(rb.bits.rs1);
		switch(rb.bits.op_mode) {
			case 0:
				if(rb.bits.size>1) {
					instr->rd1_simd_pair(rb.bits.rd1);
				}
				else {
					instr->rd1_simd(rb.bits.rd1);
				}
				break;			
			case 1:
				instr->imm1(rb.bits.imm_bank);
				if (rb.bits.imm_bank==1) {
					instr->bank(rb.bits.bank_rs2);
				}
				else {
					instr->rs2(rb.bits.bank_rs2);
				}
				if(rb.bits.size>1) {
					instr->rd1_simd_pair(rb.bits.rd1);
				}
				else {
					instr->rd1_simd(rb.bits.rd1);
				}				
				break;
			case 2:
				instr->rd1_simd(rb.bits.rd1);
				instr->bank(rb.bits.bank_rs2);
				break;
			case 3:
				instr->rd1_simd(rb.bits.rd1);
				instr->bank(rb.bits.bank_rs2);
				instr->imm1(rb.bits.imm_bank);
				break;
			default:
				AppFatal((0), ("SL2Decoder: Invalid c2.mvgr op_mode (%d).", rb.bits.op_mode));
				break;
		}
	}
	else {
		instr->rd(rb.bits.rd1);
		switch(rb.bits.op_mode) {
			case 0:
				instr->bank(rb.bits.bank_rs2);
				if(rb.bits.size>1) {
					instr->rs1_simd_pair(rb.bits.rs1);
				}
				else {
					instr->rs1_simd(rb.bits.rs1);
				}				
				break;
			case 1:
				instr->rs2(rb.bits.bank_rs2);
				if(rb.bits.size>1) {
					instr->rs1_simd_pair(rb.bits.rs1);
				}
				else {
					instr->rs1_simd(rb.bits.rs1);
				}				
				break;			
			default:
				AppFatal((0), ("SL2Decoder: Invalid c2.mvgr op_mode (%d).", rb.bits.op_mode));
				break;
				//error
		}		
	}

	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_st (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned multi : 1;
			unsigned size : 2;
			unsigned na4 : 1;
			unsigned swap : 1;
			unsigned na3 : 3;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned na2: 5;
			unsigned op_mode : 2;
			unsigned imm1 : 1;
			unsigned top :6;
		} bits_gpr;
		struct {
			unsigned offset : 14;
			unsigned multi_offset14 : 1;
			unsigned size : 2;
			unsigned na : 1;
			unsigned rs1_cs : 5;
			unsigned op_mode : 2;
			unsigned imm1 : 1;
			unsigned top :6;
		} bits_imm;		
	}rb;
	UINT uimm = 0;
	rb.rawbits = instr->rawbits();
	instr->imm1(rb.bits_gpr.imm1);
	instr->op_mode(rb.bits_gpr.op_mode);
	if(rb.bits_gpr.imm1==0) {
		instr->size(rb.bits_gpr.size);
		instr->swap(rb.bits_gpr.swap);
		instr->macro(rb.bits_gpr.multi);
	}
	else{
		uimm = rb.bits_imm.offset;
		instr->macro(rb.bits_imm.multi_offset14);
		instr->size(rb.bits_imm.size);
		instr->swap(0);
	}

	switch(rb.bits_gpr.op_mode) {
		case 0: //RF->VB
			instr->c2cs2(EC2CR_LS_CTRL);
			if(rb.bits_imm.imm1==0) {
				instr->rs2(rb.bits_gpr.rs2);
				if(instr->size()==1) {
					instr->rs1_simd_pair(rb.bits_gpr.rs1);
				}		
				else {
					instr->rs1_simd(rb.bits_gpr.rs1);
				}		
			}	
			else {
				if(instr->size()==1) {
					instr->rs1_simd_pair(rb.bits_imm.rs1_cs);
				}	
				else {
					instr->rs1_simd(rb.bits_imm.rs1_cs);
				}			
				instr->offset(uimm);
			}	
			break;	
		case 1: //GPR->VB
			if(rb.bits_imm.imm1==0) {
				instr->rs2(rb.bits_gpr.rs2);
				instr->rs1(rb.bits_gpr.rs1);
			}
			else {
				instr->multi(0);
				instr->rs1(rb.bits_imm.rs1_cs);
				instr->offset(((rb.bits_imm.multi_offset14<<14) | uimm));
			}	
			AppFatal((instr->macro()==0), ("SL2Decoder: c2st invalid non-zero macro bit"));			
			break;
		case 2: //GPR->SB
			if(rb.bits_imm.imm1==0) {
				instr->rs2(rb.bits_gpr.rs2);
				instr->rs1(rb.bits_gpr.rs1);
			}
			else {
				instr->rs1(rb.bits_imm.rs1_cs);
				instr->offset(((rb.bits_imm.multi_offset14<<14) | uimm));
			}	
			AppFatal((instr->macro()==0), ("SL2Decoder: c2st invalid non-zero macro bit"));				
			break;		
		case 3:
			instr->offset(uimm);
			instr->c2cs1(rb.bits_imm.rs1_cs);
			AppFatal((instr->macro()==0), ("SL2Decoder: c2st invalid non-zero macro bit"));	
			break;	
		default:		
			AppFatal((0), ("SL2 Decode: invaild C2st op_mode (%d).", rb.bits_imm.op_mode));
			break;					
	}
	if(instr->multi()==1) {
		instr->group(EIG_c2_macro);
	}		
	if(meta!=0) {
		UINT i = 0;
		UINT rs;
		UINT rs1;
		instr->group(EIG_c2_macro);
		switch (instr->op_mode()) {
			case 0:	rs = instr->rs1_simd(); break;
			case 1:	rs = instr->rs1(); break;
			default:		
				AppFatal((0), ("SL2 Decoder: invaild C2st op mode (%d).", instr->size()));
				break;					
		}		
		for(i = 0; i<meta; i++) {
			SL2Instr *uCode = new SL2Instr;
			uCode->init(&Top_Table[c2st_op], 0);
			uCode->size(instr->size());
			uCode->swap(instr->swap());
			uCode->multi(instr->multi());
			uCode->imm1(instr->imm1());
			uCode->op_mode(instr->op_mode());				
			switch(instr->op_mode()) {
				case 0: //RF->VB
					if(i==0) {
						uCode->c2cs3(EC2CR_LS_CTRL);
					}
					switch (instr->size()) {
						case SL2_LS_BYTE:	
							rs1 = rs + i; 
							uCode->rs1_simd(rs1);
							break;
						case SL2_LS_HWORD:	
						case SL2_LS_WORD:	
							if((i%INT16_BYTE)==0) {
								rs1 = rs + (int)i/2; 
								uCode->rs1_simd(rs1);
							}							
							break;
						default:		
							AppFatal((0), ("SL2 Decoder: invaild C2st size (%d).", instr->size()));
								break;					
					}						
					break;	
				case 1: //GPR->VB
					AppFatal((i<INT32_BYTE), ("SL2 Decoder: invaild C2st macro cnt (%d) in GPR->VB.", i));
					switch (instr->size()) {
						case SL2_LS_HWORD:	
							if((i%INT16_BYTE)==0) {
								uCode->rs1(rs);
							}							
							break;						
						case SL2_LS_WORD:	
							if((i%INT16_BYTE)==0) {
								uCode->rs1(rs);
							}							
							break;
						default:		
							AppFatal((0), ("SL2 Decoder: invaild C2st size (%d).", instr->size()));
								break;					
					}				
					break;
				default:		
					AppFatal((0), ("SL2 Decode: invaild C2st op_mode (%d).", instr->op_mode()));
					break;					
			}			
			if(instr->imm1()==0) {
				if(i==0) {
					uCode->rs2(instr->rs2());
				}
			}	
			else {
				uCode->offset(instr->offset());
			}			
			instr->setMacro(uCode, i);
		}
		instr->macroCnt(i);	
		instr->multi(1);
	}
	return INT32_BYTE;	
}

// Macro
UINT32 SL2Decoder::decodeC2_intra (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op_mode : 5;
			unsigned na : 8;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->op_mode(rb.bits.op_mode);
	instr->rd1_simd(rb.bits.rd1);
	instr->rs1_simd(rb.bits.rs1);
	instr->macro(1);
	
//macro decode
	SL2Instr *uCode;
	INT i = 0;
	switch(rb.bits.op_mode) {
		case 0:
			//psum4t1 - 1
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 0, 2, 1, 2, 1, 2, 0x0001);
			instr->setMacro(uCode, i++);	
			//psum4t1 - 2
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 1, 3, 2, 2, 1, 2, 0x0012);
			instr->setMacro(uCode, i++);
			//psum4t1 - 3
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 2, 4, 3, 2, 1, 2, 0x0124);
			instr->setMacro(uCode, i++);
			//psum4t1 - 4
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 3, 5, 4, 2, 1, 2, 0x1248);
			instr->setMacro(uCode, i++);
			//psum4t1 - 5
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 4, 6, 5, 2, 1, 2, 0x2480);
			instr->setMacro(uCode, i++);
			//psum4t1 - 6
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 5, 7, 6, 2, 1, 2, 0x4800);
			instr->setMacro(uCode, i++);
			//psum4t1 - 7
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 6, 7, 7, 2, 1, 2, 0x8000);
			instr->setMacro(uCode, i++);																		
			break;		
		case 1:
			//psum4t1 - 1
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 12, 1, 0, 2, 1, 2, 0x0842);
			instr->setMacro(uCode, i++);	
			//psum4t1 - 2
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 0, 2, 1, 2, 1, 2, 0x0084);
			instr->setMacro(uCode, i++);
			//psum4t1 - 3
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 1, 3, 2, 2, 1, 2, 0x0008);
			instr->setMacro(uCode, i++);
			//psum4t1 - 4
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 12, 9, 8, 2, 1, 2, 0x4210);
			instr->setMacro(uCode, i++);
			//psum4t1 - 5
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 8, 10, 9, 2, 1, 2, 0x2100);
			instr->setMacro(uCode, i++);
			//psum4t1 - 6
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 9, 11, 10, 2, 1, 2, 0x1000);
			instr->setMacro(uCode, i++);
			//psum4t1 - 7
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 0, 8, 12, 2, 1, 2, 0x8421);
			instr->setMacro(uCode, i++);																		
			break;		
		case 2:
			//padds - 1
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 12, 0, 1, 1, 0x0201);
			instr->setMacro(uCode, i++);	
			//padds - 2
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 0, 1, 1, 1, 0x0402);
			instr->setMacro(uCode, i++);	
			//padds - 3
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 1, 2, 1, 1, 0x0804);
			instr->setMacro(uCode, i++);	
			//padds - 4
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 2, 3, 1, 1, 0x0008);
			instr->setMacro(uCode, i++);
			//psum4t1 - 5
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 8, 0, 12, 2, 1, 2, 0x2010);
			instr->setMacro(uCode, i++);	
			//psum4t1 - 6
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 12, 1, 0, 2, 1, 2, 0x4020);
			instr->setMacro(uCode, i++);
			//psum4t1 - 7
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 0, 2, 1, 2, 1, 2, 0x8040);
			instr->setMacro(uCode, i++);
			//psum4t1 - 8
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 1, 3, 2, 2, 1, 2, 0x0080);
			instr->setMacro(uCode, i++);
			//psum4t1 - 9
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 12, 9, 8, 2, 1, 2, 0x0100);
			instr->setMacro(uCode, i++);
			//psum4t1 - 10
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 8, 10, 9, 2, 1, 2, 0x1000);
			instr->setMacro(uCode, i++);	
			break;
		case 3:
			//padds - 1
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 12, 8, 1, 1, 0x0041);
			instr->setMacro(uCode, i++);	
			//padds - 2
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 8, 9, 1, 1, 0x0410);
			instr->setMacro(uCode, i++);	
			//padds - 3
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 9, 10, 1, 1, 0x4100);
			instr->setMacro(uCode, i++);	
			//padds - 4
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 10, 11, 1, 1, 0x1000);
			instr->setMacro(uCode, i++);
			//psum4t1 - 5
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 8, 0, 12, 2, 1, 2, 0x0082);
			instr->setMacro(uCode, i++);	
			//psum4t1 - 6
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 12, 1, 0, 2, 1, 2, 0x0004);
			instr->setMacro(uCode, i++);
			//psum4t1 - 7
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 0, 2, 1, 2, 1, 2, 0x0008);
			instr->setMacro(uCode, i++);
			//psum4t1 - 8
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 12, 9, 8, 2, 1, 2, 0x0820);
			instr->setMacro(uCode, i++);
			//psum4t1 - 9
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 8, 10, 9, 2, 1, 2, 0x8200);
			instr->setMacro(uCode, i++);
			//psum4t1 - 10
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 9, 11, 10, 2, 1, 2, 0x2000);
			instr->setMacro(uCode, i++);	
			break;
		case 4:
			//padds - 1
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 0, 1, 1, 1, 0x0001);
			instr->setMacro(uCode, i++);	
			//padds - 2
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 1, 2, 1, 1, 0x0102);
			instr->setMacro(uCode, i++);	
			//padds - 3
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 2, 3, 1, 1, 0x0204);
			instr->setMacro(uCode, i++);	
			//padds - 4
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 3, 4, 1, 1, 0x0408);
			instr->setMacro(uCode, i++);
			//padds - 5
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 4, 5, 1, 1, 0x0800);
			instr->setMacro(uCode, i++);	
			//psum4t1 - 6
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 0, 2, 1, 2, 1, 2, 0x0010);
			instr->setMacro(uCode, i++);
			//psum4t1 - 7
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 1, 3, 2, 2, 1, 2, 0x1020);
			instr->setMacro(uCode, i++);
			//psum4t1 - 8
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 2, 4, 3, 2, 1, 2, 0x2040);
			instr->setMacro(uCode, i++);
			//psum4t1 - 9
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 3, 5, 4, 2, 1, 2, 0x4080);
			instr->setMacro(uCode, i++);
			//psum4t1 - 10
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 4, 6, 5, 2, 1, 2, 0x8000);
			instr->setMacro(uCode, i++);	
			break;		
		case 5:
			//padds - 1
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 8, 9, 1, 1, 0x0001);
			instr->setMacro(uCode, i++);	
			//padds - 2
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 9, 10, 1, 1, 0x0014);
			instr->setMacro(uCode, i++);	
			//padds - 3
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 10, 11, 1, 1, 0x0140);
			instr->setMacro(uCode, i++);	
			//psum4t1 - 4
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 8, 10, 9, 2, 1, 2, 0x0002);
			instr->setMacro(uCode, i++);
			//psum4t1 - 5
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 9, 11, 10, 2, 1, 2, 0x0028);
			instr->setMacro(uCode, i++);
			//psum4t1 - 6
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 10, 11, 11, 2, 1, 2, 0x0280);
			instr->setMacro(uCode, i++);
			//pmov - 7
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2pmov_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_pmov_private(uCode, 11, 0xfc00);
			instr->setMacro(uCode, i++);
			break;	
		case 6:
			//psum4t1 - 1
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 1, 3, 2, 4, 1, 0, 0x0001);
			instr->setMacro(uCode, i++);
			//psum4t2 - 2
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t2_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t2_private(uCode, 5, 7, 6, 1, 3, 0x0001);
			instr->setMacro(uCode, i++);
			//psum4t1 - 3
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 2, 4, 3, 4, 1, 0, 0x0002);
			instr->setMacro(uCode, i++);
			//psum4t2 - 4
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t2_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t2_private(uCode, 6, 8, 7, 1, 3, 0x0012);
			instr->setMacro(uCode, i++);
			//psum4t1 - 5
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 3, 4, 4, 4, 1, 0, 0x0004);
			instr->setMacro(uCode, i++);
			//psum4t2 - 6
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t2_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t2_private(uCode, 7, 8, 8, 1, 3, 0x0124);
			instr->setMacro(uCode, i++);
			//psum4t1 - 7
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 4, 4, 4, 4, 1, 0, 0x0008);
			instr->setMacro(uCode, i++);
			//psum4t2 - 8
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t2_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t2_private(uCode, 8, 8, 8, 1, 3, 0x7ec8);
			instr->setMacro(uCode, i++);
			//psum4t1 - 9
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 4, 4, 8, 2, 1, 2, 0x8000);
			instr->setMacro(uCode, i++);
			break;		
		case 7:
			//padds - 1
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 1, 2, 1, 1, 0x0001);
			instr->setMacro(uCode, i++);	
			//padds - 2
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 2, 3, 1, 1, 0x0102);
			instr->setMacro(uCode, i++);	
			//padds - 3
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 3, 4, 1, 1, 0x0204);
			instr->setMacro(uCode, i++);
			//padds - 4
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 4, 4, 1, 1, 0x0c08);
			instr->setMacro(uCode, i++);					
			//psum4t1 - 5
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 1, 3, 2, 2, 1, 2, 0x0010);
			instr->setMacro(uCode, i++);
			//psum4t1 - 6
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 2, 4, 3, 2, 1, 2, 0x1020);
			instr->setMacro(uCode, i++);	
			//psum4t1 - 7
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 3, 4, 4, 2, 1, 2, 0x2040);
			instr->setMacro(uCode, i++);
			//psum4t1 - 8
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 4, 4, 4, 2, 1, 2, 0xc080);
			instr->setMacro(uCode, i++);
			break;
		case 8:
			//padds - 1
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 0, 1, 1, 1, 0x0201);
			instr->setMacro(uCode, i++);	
			//padds - 2
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 1, 2, 1, 1, 0x0402);
			instr->setMacro(uCode, i++);	
			//padds - 3
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 2, 3, 1, 1, 0x0804);
			instr->setMacro(uCode, i++);
			//padds - 4
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 3, 4, 1, 1, 0x0008);
			instr->setMacro(uCode, i++);					
			//psum4t1 - 5
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 5, 1, 0, 2, 1, 2, 0x2010);
			instr->setMacro(uCode, i++);
			//psum4t1 - 6
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 0, 2, 1, 2, 1, 2, 0x4020);
			instr->setMacro(uCode, i++);	
			//psum4t1 - 7
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 1, 3, 2, 2, 1, 2, 0x8040);
			instr->setMacro(uCode, i++);
			//psum4t1 - 8
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 2, 4, 3, 2, 1, 2, 0x0080);
			instr->setMacro(uCode, i++);
			//psum4t1 - 9
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 0, 6, 5, 2, 1, 2, 0x0100);
			instr->setMacro(uCode, i++);
			//psum4t1 - 10
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 5, 7, 6, 2, 1, 2, 0x1000);
			instr->setMacro(uCode, i++);			
			break;	
		case 9:
			//psum4t1 - 1
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 6, 8, 7, 2, 1, 2, 0x1000);
			instr->setMacro(uCode, i++);	
			//psum4t1 - 2
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 5, 7, 6, 2, 1, 2, 0x2100);
			instr->setMacro(uCode, i++);
			//psum4t1 - 3
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 0, 6, 5, 2, 1, 2, 0x4210);
			instr->setMacro(uCode, i++);
			//psum4t1 - 4
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 1, 5, 0, 2, 1, 2, 0x8421);
			instr->setMacro(uCode, i++);
			//psum4t1 - 5
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 0, 2, 1, 2, 1, 2, 0x0842);
			instr->setMacro(uCode, i++);
			//psum4t1 - 6
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 1, 3, 2, 2, 1, 2, 0x0084);
			instr->setMacro(uCode, i++);
			//psum4t1 - 7
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 2, 4, 3, 2, 1, 2, 0x0008);
			instr->setMacro(uCode, i++);																		
			break;	
		case 10:
			//padds - 1
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 0, 5, 1, 1, 0x0041);
			instr->setMacro(uCode, i++);	
			//padds - 2
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 5, 6, 1, 1, 0x0410);
			instr->setMacro(uCode, i++);	
			//padds - 3
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 6, 7, 1, 1, 0x4100);
			instr->setMacro(uCode, i++);
			//padds - 4
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 7, 8, 1, 1, 0x1000);
			instr->setMacro(uCode, i++);					
			//psum4t1 - 5
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 1, 5, 0, 2, 1, 2, 0x0082);
			instr->setMacro(uCode, i++);
			//psum4t1 - 6
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 0, 2, 1, 2, 1, 2, 0x0004); ///*** WWD modified this in 20070202
			instr->setMacro(uCode, i++);	
			//psum4t1 - 7
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 1, 3, 2, 2, 1, 2, 0x0008);
			instr->setMacro(uCode, i++);
			//psum4t1 -8
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 0, 6, 5, 2, 1, 2, 0x0820);
			instr->setMacro(uCode, i++);
			//psum4t1 - 9
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 5, 7, 6, 2, 1, 2, 0x8200);
			instr->setMacro(uCode, i++);		
			//psum4t1 - 10
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 6, 8, 7, 2, 1, 2, 0x2000);
			instr->setMacro(uCode, i++);					
			break;	
		case 11:
			//padds - 1
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 5, 6, 1, 1, 0x0001);
			instr->setMacro(uCode, i++);	
			//padds - 2
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 6, 7, 1, 1, 0x0014);
			instr->setMacro(uCode, i++);	
			//padds - 3
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2padds_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_padds_private(uCode, 7, 8, 1, 1, 0x0140);
			instr->setMacro(uCode, i++);	
			//psum4t1 - 4
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 5, 7, 6, 2, 1, 2, 0x0002);
			instr->setMacro(uCode, i++);
			//psum4t1 - 5
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 6, 8, 7, 2, 1, 2, 0x0028);
			instr->setMacro(uCode, i++);
			//psum4t1 - 6
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 7, 8, 8, 2, 1, 2, 0x0280);
			instr->setMacro(uCode, i++);
			//pmov - 7
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2pmov_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_pmov_private(uCode, 8, 0xfc00);
			instr->setMacro(uCode, i++);
			break;		
		case 12:   // New added in ISA3.1
			//psum4t1 - 1
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 5, 1, 0, 2, 1, 2, 0x1111);
			instr->setMacro(uCode, i++);
			//psum4t1 - 2
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 0, 2, 1, 2, 1, 2, 0x2222);
			instr->setMacro(uCode, i++);
			//psum4t1 - 3
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 1, 3, 2, 2, 1, 2, 0x4444);
			instr->setMacro(uCode, i++);
			//psum4t1 - 4
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 2, 4, 3, 2, 1, 2, 0x8888);
			instr->setMacro(uCode, i++);
			break;		
		case 13:   // New added in ISA3.1
			//psum4t1 - 1
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 5, 1, 0, 2, 1, 2, 0x000f);
			instr->setMacro(uCode, i++);
			//psum4t1 - 2
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 0, 2, 1, 2, 1, 2, 0x00f0);
			instr->setMacro(uCode, i++);
			//psum4t1 - 3
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 1, 3, 2, 2, 1, 2, 0x0f00);
			instr->setMacro(uCode, i++);
			//psum4t1 - 4
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 2, 4, 3, 2, 1, 2, 0xf000);
			instr->setMacro(uCode, i++);
			break;	

		case 14:   // New added in ISA3.1
			//psum4t1 - 1
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 0, 2, 1, 2, 1, 2, 0x0001);
			instr->setMacro(uCode, i++);
			//psum4t1 - 2
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 1, 3, 2, 2, 1, 2, 0x0012);
			instr->setMacro(uCode, i++);
			//psum4t1 - 3
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 2, 4, 3, 2, 1, 2, 0x0124);
			instr->setMacro(uCode, i++);
			//psum4t1 - 4
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 3, 5, 4, 2, 1, 2, 0x1248);
			instr->setMacro(uCode, i++);
			//psum4t1 - 5
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 4, 6, 5, 2, 1, 2, 0x2480);
			instr->setMacro(uCode, i++);		
			//psum4t1 - 6
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 5, 7, 6, 2, 1, 2, 0x4800);
			instr->setMacro(uCode, i++);
			//psum4t1 - 7
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 6, 8, 7, 2, 1, 2, 0x8000);
			instr->setMacro(uCode, i++);		
			break;	
		case 15:   // New added in ISA3.1
			//psum4t1 - 1
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 0, 2, 1, 2, 1, 2, 0x0001);
			instr->setMacro(uCode, i++);
			//psum4t1 - 2
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 1, 3, 2, 2, 1, 2, 0x0002);
			instr->setMacro(uCode, i++);
			//psum4t1 - 3
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 9, 1, 0, 2, 1, 2, 0x0010);
			instr->setMacro(uCode, i++);
			//psum4t1 - 4
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 2, 4, 3, 2, 1, 2, 0x0124);
			instr->setMacro(uCode, i++);
			//psum4t1 - 5
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 3, 5, 4, 2, 1, 2, 0x1248);
			instr->setMacro(uCode, i++);
			//psum4t1 - 6
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 4, 6, 5, 2, 1, 2, 0x2480);
			instr->setMacro(uCode, i++);
			//psum4t1 - 7
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 5, 7, 6, 2, 1, 2, 0x4800);
			instr->setMacro(uCode, i++);
			//psum4t1 - 8
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 6, 8, 7, 2, 1, 2, 0x8000);
			instr->setMacro(uCode, i++);			
			break;	
		case 16:   // New added in ISA3.1
			//psum4t1 - 1
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 0, 4, 8, 2, 1, 2, 0x8421);
			instr->setMacro(uCode, i++);
			//psum4t1 - 2
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 8, 1, 0, 2, 1, 2, 0x0842);
			instr->setMacro(uCode, i++);
			//psum4t1 - 3
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 3, 5, 4, 2, 1, 2, 0x0084);
			instr->setMacro(uCode, i++);
			//psum4t1 - 4
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 1, 3, 2, 2, 1, 2, 0x0008);
			instr->setMacro(uCode, i++);
			//psum4t1 - 5
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 4, 6, 5, 2, 1, 2, 0x4210);
			instr->setMacro(uCode, i++);
			//psum4t1 - 6
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 5, 7, 6, 2, 1, 2, 0x2100);
			instr->setMacro(uCode, i++);
			//psum4t1 - 7
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 6, 8, 7, 2, 1, 2, 0x1000);
			instr->setMacro(uCode, i++);			
			break;	
		case 17:   // New added in ISA3.1
			//psum4t1 - 1
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 2, 4, 3, 2, 1, 2, 0x0421);
			instr->setMacro(uCode, i++);
			//psum4t1 - 2
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 10, 11, 12, 2, 1, 2, 0x8000);
			instr->setMacro(uCode, i++);
			//psum4t1 - 3
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 3, 5, 4, 2, 1, 2, 0x0842);
			instr->setMacro(uCode, i++);
			//psum4t1 - 4
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 4, 6, 5, 2, 1, 2, 0x0084);
			instr->setMacro(uCode, i++);
			//psum4t1 - 5
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 5, 7, 6, 2, 1, 2, 0x0008);
			instr->setMacro(uCode, i++);
			//psum4t1 - 6
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 11, 13, 12, 2, 1, 2, 0x4210);
			instr->setMacro(uCode, i++);
			//psum4t1 - 7
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 12, 14, 13, 2, 1, 2, 0x2100);
			instr->setMacro(uCode, i++);
			//psum4t1 - 8
			uCode = new SL2Instr;
			uCode->init(&C2_Private_Table[c2psum4t1_op], 0);
			uCode->rs1_simd(rb.bits.rs1);
			uCode->rd1_simd(rb.bits.rd1);
			decodeC2_psum4t1_private(uCode, 13, 15, 14, 2, 1, 2, 0x1000);
			instr->setMacro(uCode, i++);			
			break;			
		default:
			AppFatal((0), ("Decoder: Invalid intra op_mode (%d).", rb.bits.op_mode));
			break;	
	}
	instr->macroCnt(i);	
	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_mads (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned rs3 : 5;
			unsigned imm1 : 1;
			unsigned imm2 : 2;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->imm1(rb.bits.imm1);
	instr->imm2(rb.bits.imm2);
	instr->rd(rb.bits.rd1);
	instr->rs1(rb.bits.rs1);
	instr->rs2(rb.bits.rs2);
	instr->rs3(rb.bits.rs3);
	instr->macro(1);
	
//macro decode
	SL2Instr *uCode;
	INT i = 0;	
	uCode = new SL2Instr;
	uCode->init(&C2_Table[c2muls_op], 0);
	uCode->rs1(rb.bits.rs1);
	uCode->rs2(rb.bits.rs2);
	uCode->rd(rb.bits.rd1);
	decodeC2_muls_private(uCode, 0, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	uCode->init(&C2_Table[c2adds_op], 0);
	uCode->rs1(rb.bits.rs3);
	uCode->rs2(rb.bits.rd1);
	uCode->rd(rb.bits.rd1);
	decodeC2_adds_private(uCode, rb.bits.imm1, 0, 1, 0, 0, rb.bits.imm2);
	instr->setMacro(uCode, i++);

	instr->macroCnt(i);		
	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_mvsel (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op_mode : 3;
			unsigned na : 5;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	SL2Instr *uCode;
	INT i = 0;		
	rb.rawbits = instr->rawbits();	
	instr->op_mode(rb.bits.op_mode);
	switch(rb.bits.op_mode) {
		case 1:
		case 6:
			break;
		case 0:
		case 7:
			instr->rs2(rb.bits.rs2);
			instr->rs1(rb.bits.rs1);			
			break;
		case 2:
			instr->rs2(rb.bits.rs2);
			instr->rs1(rb.bits.rs1);	
			instr->macro(1);	
			
			//macro decode
			uCode = new SL2Instr;
			uCode->init(&C2_Table[c2mvsel_op], 0);
			uCode->rs1(rb.bits.rs1);
			uCode->rs2(rb.bits.rs2);
			uCode->rd(rb.bits.rd1);
			decodeC2_mvsel_private(uCode, 6);
			instr->setMacro(uCode, i++);
		
			uCode = new SL2Instr;
			uCode->init(&C2_Table[c2mvsel_op], 0);
			uCode->rs1(rb.bits.rs1);
			uCode->rs2(rb.bits.rs2);
			uCode->rd(rb.bits.rd1);
			decodeC2_mvsel_private(uCode, 7);
			instr->setMacro(uCode, i++);
			
			instr->macroCnt(i);				
			break;
		case 3:
		case 4:
		case 5:
			instr->rd(rb.bits.rd1);
			break;
		default:
			AppFatal((0), ("SL2Decoder: Invalid c2.mvsel op_mode (%d).", rb.bits.op_mode));
			break;
	}
	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_satd_old (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned rs3 : 5;
			unsigned na : 3;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
//	instr->acc(TRUE, EC2ACC_SIMD_ACC);	
	instr->rs1_simd(rb.bits.rs1);
	instr->rs2_simd(rb.bits.rs2);
	instr->rd1_simd(rb.bits.rd1);
	instr->rs3(rb.bits.rs3); //gpr target of last macro
	instr->macro(1);
	
//macro decode
	INT i = 0;
	SL2Instr *uCode = new SL2Instr;
	//vsubs
	uCode->init(&C2_Table[c2vsubs_op], 0);
	uCode->rs1_simd(rb.bits.rs1);
	uCode->rs2_simd(rb.bits.rd1);
	uCode->rd1_simd(rb.bits.rd1);
	decodeC2_vsubs_private(uCode, 0, 0, 0, 0);
	instr->setMacro(uCode, i++);

	//first hadamard
	uCode = new SL2Instr;
	//step1
	uCode->init(&C2_Table[c2mmul_op], 0);
	uCode->rs1_simd(rb.bits.rs2);
	uCode->rs2_simd(rb.bits.rd1);	
	uCode->rd1_simd(rb.bits.rs1);
	decodeC2_mmul_private(uCode, 0, 0, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//step2
	uCode->init(&C2_Table[c2mmul_op], 0);
	uCode->rs1_simd(rb.bits.rs2);
	uCode->rs2_simd(rb.bits.rd1);	
	uCode->rd1_simd(rb.bits.rs3);
	decodeC2_mmul_private(uCode, 1, 0, 1);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//vadds
	uCode->init(&C2_Table[c2vadds_op], 0);
	uCode->rs1_simd(rb.bits.rs1);
	uCode->rs2_simd(rb.bits.rs3);	
	uCode->rd1_simd(rb.bits.rs1);
	decodeC2_vadds_private(uCode, 0, 0, 0, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//step 3
	uCode->init(&C2_Table[c2mmul_op], 0);
	uCode->rs1_simd(rb.bits.rs2);
	uCode->rs2_simd(rb.bits.rd1);	
	uCode->rd1_simd(rb.bits.rs3);
	decodeC2_mmul_private(uCode, 4, 0, 4);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//vadds
	uCode->init(&C2_Table[c2vadds_op], 0);
	uCode->rs1_simd(rb.bits.rs1);
	uCode->rs2_simd(rb.bits.rs3);	
	uCode->rd1_simd(rb.bits.rs1);
	decodeC2_vadds_private(uCode, 0, 0, 0, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//step 3
	uCode->init(&C2_Table[c2mmul_op], 0);
	uCode->rs1_simd(rb.bits.rs2);
	uCode->rs2_simd(rb.bits.rd1);	
	uCode->rd1_simd(rb.bits.rs3);
	decodeC2_mmul_private(uCode, 5, 0, 5);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//vadds
	uCode->init(&C2_Table[c2vadds_op], 0);
	uCode->rs1_simd(rb.bits.rs1);
	uCode->rs2_simd(rb.bits.rs3);	
	uCode->rd1_simd(rb.bits.rd1);  ///*** MUST be rd1 -- WWD in 20070127
	decodeC2_vadds_private(uCode, 0, 0, 0, 0);
	instr->setMacro(uCode, i++);
	
	//second hadamard
	uCode = new SL2Instr;
	//step1
	uCode->init(&C2_Table[c2mmul_op], 0);
	uCode->rs1_simd(rb.bits.rs2);
	uCode->rs2_simd(rb.bits.rd1);	
	uCode->rd1_simd(rb.bits.rs1);
	decodeC2_mmul_private(uCode, 0, 0, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//step2
	uCode->init(&C2_Table[c2mmul_op], 0);
	uCode->rs1_simd(rb.bits.rs2);
	uCode->rs2_simd(rb.bits.rd1);	
	uCode->rd1_simd(rb.bits.rs3);
	decodeC2_mmul_private(uCode, 1, 0, 1);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//vadds
	uCode->init(&C2_Table[c2vadds_op], 0);
	uCode->rs1_simd(rb.bits.rs1);
	uCode->rs2_simd(rb.bits.rs3);	
	uCode->rd1_simd(rb.bits.rs1);
	decodeC2_vadds_private(uCode, 0, 0, 0, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//step 3
	uCode->init(&C2_Table[c2mmul_op], 0);
	uCode->rs1_simd(rb.bits.rs2);
	uCode->rs2_simd(rb.bits.rd1);	
	uCode->rd1_simd(rb.bits.rs3);
	decodeC2_mmul_private(uCode, 4, 0, 4);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//vadds
	uCode->init(&C2_Table[c2vadds_op], 0);
	uCode->rs1_simd(rb.bits.rs1);
	uCode->rs2_simd(rb.bits.rs3);	
	uCode->rd1_simd(rb.bits.rs1);
	decodeC2_vadds_private(uCode, 0, 0, 0, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//step 3
	uCode->init(&C2_Table[c2mmul_op], 0);
	uCode->rs1_simd(rb.bits.rs2);
	uCode->rs2_simd(rb.bits.rd1);	
	uCode->rd1_simd(rb.bits.rs3);
	decodeC2_mmul_private(uCode, 5, 0, 5);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//vadds
	uCode->init(&C2_Table[c2vadds_op], 0);
	uCode->rs1_simd(rb.bits.rs1);
	uCode->rs2_simd(rb.bits.rs3);	
	uCode->rd1_simd(rb.bits.rd1);  ///*** MUST be rd1 -- WWD in 20070127
	decodeC2_vadds_private(uCode, 0, 0, 0, 0);
	instr->setMacro(uCode, i++);
	
	//absolute acc
	uCode = new SL2Instr;
	//vsubs
	uCode->init(&C2_Table[c2vsubs_op], 0);
	uCode->rs2_simd(rb.bits.rd1);
	uCode->rd1_simd(rb.bits.rd1);
	decodeC2_vsubs_private (uCode, 0, 0, 2, 0);	
	instr->setMacro(uCode, i++);
	
	uCode = new SL2Instr;
	//psum16 - 1
	uCode->init(&C2_Private_Table[c2psum16_op], 0);
	uCode->rs1_simd(rb.bits.rd1);
	uCode->rd1_simd(rb.bits.rd1);
	decodeC2_psum16_private (uCode, 0, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//psum16 - 2
	uCode->init(&C2_Private_Table[c2psum16_op], 0);
	uCode->rs1_simd(rb.bits.rd1);
	uCode->rd1_simd(rb.bits.rd1);
	decodeC2_psum16_private (uCode, 1, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//psum16 - 3
	uCode->init(&C2_Private_Table[c2psum16_op], 0);
	uCode->rs1_simd(rb.bits.rd1);
	uCode->rd1_simd(rb.bits.rd1);
	decodeC2_psum16_private (uCode, 2, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//psum16 - 4
	uCode->init(&C2_Private_Table[c2psum16_op], 0);
	uCode->rs1_simd(rb.bits.rd1);
	uCode->rd1_simd(rb.bits.rd1);
	decodeC2_psum16_private (uCode, 3, 1);
	instr->setMacro(uCode, i++);
	
	instr->macroCnt(i);	
	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_satd (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned rd2 : 5;
			unsigned slut_indx : 3;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
	instr->rd1_simd(rb.bits.rd1);
	instr->rs1_simd(rb.bits.rs1);
	instr->rs2_simd(rb.bits.rs2);
	instr->sl_indx(rb.bits.slut_indx + 8); //SLUT table index : SPECICAL PROCESS
	instr->rd(rb.bits.rd2);
	instr->macro(1);
	
//macro decode
	INT i = 0;
	SL2Instr *uCode = new SL2Instr;
	//vsubs
	uCode->init(&C2_Table[c2vsubs_op], 0);
	uCode->rs1_simd(rb.bits.rs1);
	uCode->rs2_simd(rb.bits.rd1);
	uCode->rd1_simd(rb.bits.rd1);
	decodeC2_vsubs_private(uCode, 0, 0, 0, 0);
	instr->setMacro(uCode, i++);

	//first hadamard
	uCode = new SL2Instr;
	//step1
	uCode->init(&C2_Private_Table[c2pxsub_op], 0);
	uCode->rs1_simd(rb.bits.rd1);
	uCode->rs2_simd(rb.bits.rd1);	
	uCode->rd1_simd(rb.bits.rs2);
	decodeC2_pxsub_private(uCode, instr->sl_indx());
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//step2
	uCode->init(&C2_Private_Table[c2pxadd_op], 0);
	uCode->rs1_simd(rb.bits.rd1);
	uCode->rs2_simd(rb.bits.rd1);	
	uCode->rd1_simd(rb.bits.rs2);
	decodeC2_pxadd_private(uCode, instr->sl_indx()+1);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//step3
	uCode->init(&C2_Private_Table[c2pxsub_op], 0);
	uCode->rs1_simd(rb.bits.rs2);
	uCode->rs2_simd(rb.bits.rs2);	
	uCode->rd1_simd(rb.bits.rd1);
	decodeC2_pxsub_private(uCode, instr->sl_indx()+2);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//step 4
	uCode->init(&C2_Private_Table[c2pxadd_op], 0);
	uCode->rs1_simd(rb.bits.rs2);
	uCode->rs2_simd(rb.bits.rs2);	
	uCode->rd1_simd(rb.bits.rd1);
	decodeC2_pxadd_private(uCode, instr->sl_indx()+3);
	instr->setMacro(uCode, i++);

	
	//second hadamard
	uCode = new SL2Instr;
	//step1
	uCode->init(&C2_Private_Table[c2pxsub_op], 0);
	uCode->rs1_simd(rb.bits.rd1);
	uCode->rs2_simd(rb.bits.rd1);	
	uCode->rd1_simd(rb.bits.rs2);
	decodeC2_pxsub_private(uCode, instr->sl_indx()+4);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//step2
	uCode->init(&C2_Private_Table[c2pxadd_op], 0);
	uCode->rs1_simd(rb.bits.rd1);
	uCode->rs2_simd(rb.bits.rd1);	
	uCode->rd1_simd(rb.bits.rs2);
	decodeC2_pxadd_private(uCode, instr->sl_indx()+5);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//step3
	uCode->init(&C2_Private_Table[c2pxsub_op], 0);
	uCode->rs1_simd(rb.bits.rs2);
	uCode->rs2_simd(rb.bits.rs2);	
	uCode->rd1_simd(rb.bits.rd1);
	decodeC2_pxsub_private(uCode, instr->sl_indx()+6);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//step4
	uCode->init(&C2_Private_Table[c2pxadd_op], 0);
	uCode->rs1_simd(rb.bits.rs2);
	uCode->rs2_simd(rb.bits.rs2);	
	uCode->rd1_simd(rb.bits.rd1);
	decodeC2_pxadd_private(uCode, instr->sl_indx()+7);
	instr->setMacro(uCode, i++);


	//absolute acc
	uCode = new SL2Instr;
	//vsubs
	uCode->init(&C2_Table[c2vsubs_op], 0);
	uCode->rs2_simd(rb.bits.rd1);
	uCode->rd1_simd(rb.bits.rd1);
	decodeC2_vsubs_private (uCode, 0, 0, 2, 0);	
	instr->setMacro(uCode, i++);
	
	uCode = new SL2Instr;
	//psum16.tmp - 1
	uCode->init(&C2_Private_Table[c2psum16_op], 0);
	uCode->rs1_simd(rb.bits.rd1);
	uCode->acc(ERS_WRITE, EC2ACC_SUM);
	decodeC2_psum16_private (uCode, 0, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//psum16.tmp  - 2
	uCode->init(&C2_Private_Table[c2psum16_op], 0);
	uCode->rs1_simd(rb.bits.rd1);
	uCode->acc(ERS_RW, EC2ACC_SUM);
	decodeC2_psum16_private (uCode, 1, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//psum16.tmp  - 3
	uCode->init(&C2_Private_Table[c2psum16_op], 0);
	uCode->rs1_simd(rb.bits.rd1);
	uCode->acc(ERS_RW, EC2ACC_SUM);
	decodeC2_psum16_private (uCode, 2, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//psum16.tmp  - 4
	uCode->init(&C2_Private_Table[c2psum16_op], 0);
	uCode->rs1_simd(rb.bits.rd1);
	uCode->acc(ERS_RW, EC2ACC_SUM);
	decodeC2_psum16_private (uCode, 3, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//psum16.tmp  - 5
	uCode->init(&C2_Private_Table[c2psum16_op], 0);
	uCode->rs1_simd(rb.bits.rd1);
	uCode->acc(ERS_READ, EC2ACC_SUM);
	uCode->rd(rb.bits.rd2);
	decodeC2_psum16_private (uCode, 4, 1);
	instr->setMacro(uCode, i++);


	instr->macroCnt(i);	
	return INT32_BYTE;		
}


UINT32 SL2Decoder::decodeC2_smads (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned rs3 : 5;
			unsigned na2 : 3;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->rd(rb.bits.rd1);
	instr->rs1(rb.bits.rs1);
	instr->rs2(rb.bits.rs2);
	instr->rs3(rb.bits.rs3);
	instr->macro(1);
	
	//macro decode
	SL2Instr* uCode = new SL2Instr;
	INT i = 0;
	uCode->init(&C2_Table[c2muls_op], 0);
	uCode->rs1(rb.bits.rs1);
	uCode->rs2(rb.bits.rs2);
	uCode->rd(rb.bits.rd1);
	decodeC2_muls_private(uCode, 2, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	uCode->init(&C2_Private_Table[c2psadds_op], 0);
	uCode->rs1(rb.bits.rd1);
	uCode->rs2(rb.bits.rs3);
	uCode->rd(rb.bits.rd1);
	instr->setMacro(uCode, i++);
	
	instr->macroCnt(i);			
	
	return INT32_BYTE;	
}

UINT32 SL2Decoder::decodeC2_vsad_old (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned rd2 : 5;
			unsigned na : 3;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
//	instr->acc(TRUE, EC2ACC_SIMD_ACC);	
	instr->rs1_simd(rb.bits.rs1);
	instr->rs2_simd(rb.bits.rs2);
	instr->rd1_simd(rb.bits.rd1);
	instr->rd(rb.bits.rd2); //GPR target of last macro
	instr->macro(1);
	
//macro decode
	INT i = 0;
	SL2Instr *uCode = new SL2Instr;
	//vsubs
	uCode->init(&C2_Table[c2vsubs_op], 0);
	uCode->rs1_simd(rb.bits.rs1);
	uCode->rs2_simd(rb.bits.rs2);
	uCode->rd1_simd(rb.bits.rd1);
	decodeC2_vsubs_private(uCode, 0, 0, 1, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//psum16 - 1
	uCode->init(&C2_Private_Table[c2psum16_op], 0);
	uCode->rd1_simd(rb.bits.rd1);
	uCode->rs1_simd(rb.bits.rd1);
	decodeC2_psum16_private(uCode, 0, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//psum16 - 2
	uCode->init(&C2_Private_Table[c2psum16_op], 0);
	uCode->rd1_simd(rb.bits.rd1);
	uCode->rs1_simd(rb.bits.rd1);
	decodeC2_psum16_private(uCode, 1, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//psum16 - 3
	uCode->init(&C2_Private_Table[c2psum16_op], 0);
	uCode->rd1_simd(rb.bits.rd1);
	uCode->rs1_simd(rb.bits.rd1);
	decodeC2_psum16_private(uCode, 2, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//psum16 - 4
	uCode->init(&C2_Private_Table[c2psum16_op], 0);
	uCode->rd1_simd(rb.bits.rd1);
	uCode->rs1_simd(rb.bits.rd1);
	decodeC2_psum16_private(uCode, 3, 0);
	instr->setMacro(uCode, i++);
	
	uCode = new SL2Instr;
	//mvgr
	uCode->init(&C2_Table[c2mvgr_op], 0);
	uCode->rs1_simd(rb.bits.rd1);
	uCode->rd(rb.bits.rd2);	
	decodeC2_mvgr_private (uCode, 15, 0, 0, 1, 0, 0);	
	instr->setMacro(uCode, i++);
	
	instr->macroCnt(i);
	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_vsad (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned rd2 : 5;
			unsigned na : 3;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
//	instr->acc(TRUE, EC2ACC_SIMD_ACC);	
	instr->rs1_simd(rb.bits.rs1);
	instr->rs2_simd(rb.bits.rs2);
	instr->rd1_simd(rb.bits.rd1);
	instr->rd(rb.bits.rd2); //GPR target of last macro
	instr->macro(1);
	
//macro decode
	INT i = 0;
	SL2Instr *uCode = new SL2Instr;
	//vsubs
	uCode->init(&C2_Table[c2vsubs_op], 0);
	uCode->rs1_simd(rb.bits.rs1);
	uCode->rs2_simd(rb.bits.rs2);
	uCode->rd1_simd(rb.bits.rd1);
	decodeC2_vsubs_private(uCode, 0, 0, 1, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//psum16.tmp - 1
	uCode->init(&C2_Private_Table[c2psum16_op], 0);
	uCode->rs1_simd(rb.bits.rd1);
	uCode->acc(ERS_WRITE, EC2ACC_SUM);
	decodeC2_psum16_private (uCode, 0, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//psum16.tmp  - 2
	uCode->init(&C2_Private_Table[c2psum16_op], 0);
	uCode->rs1_simd(rb.bits.rd1);
	uCode->acc(ERS_RW, EC2ACC_SUM);
	decodeC2_psum16_private (uCode, 1, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//psum16.tmp  - 3
	uCode->init(&C2_Private_Table[c2psum16_op], 0);
	uCode->rs1_simd(rb.bits.rd1);
	uCode->acc(ERS_RW, EC2ACC_SUM);
	decodeC2_psum16_private (uCode, 2, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//psum16.tmp  - 4
	uCode->init(&C2_Private_Table[c2psum16_op], 0);
	uCode->rs1_simd(rb.bits.rd1);
	uCode->acc(ERS_RW, EC2ACC_SUM);
	decodeC2_psum16_private (uCode, 3, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	//psum16.tmp  - 5
	uCode->init(&C2_Private_Table[c2psum16_op], 0);
	uCode->rs1_simd(rb.bits.rd1);
	uCode->acc(ERS_READ, EC2ACC_SUM);
	uCode->rd(rb.bits.rd2);
	decodeC2_psum16_private (uCode, 4, 0); // Diiferent from SATD
	instr->setMacro(uCode, i++);
	
	instr->macroCnt(i);
	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_vspel (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned sl_indx : 9;
			unsigned op_mode : 1;
			unsigned na1 : 2;
			unsigned size : 1;
			unsigned rs1_clindx : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->op_mode(rb.bits.op_mode);
	instr->size(rb.bits.size);
	//instr->shft(rb.bits.shft);
	instr->sl_indx(rb.bits.sl_indx);
	
	// cl_indx?
	
	if(rb.bits.op_mode==1) {
		instr->rs1_simd(rb.bits.rs1_clindx); // no need in case 0
	}
	if(meta>0) {
		instr->rs2_simd(meta-1);
	}	
	instr->cl_indx(rb.bits.rs1_clindx);
	
	if(rb.bits.size==1){
		instr->rd1_simd_pair(rb.bits.rd1);
	}
	else {
		instr->rd1_simd(rb.bits.rd1);
	}
	return INT32_BYTE;		
}

ADDR SL2Decoder::decodeC2_vspmac (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned sl_indx : 9;
			unsigned cl_indx : 3;
			unsigned size : 1;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->size(rb.bits.size);
	instr->cl_indx(rb.bits.cl_indx);
	instr->sl_indx(rb.bits.sl_indx);

	instr->rs1_simd(rb.bits.rs1); 
	
	if(rb.bits.size==1){
		instr->rd1_simd_pair(rb.bits.rd1);
	}
	else {
		instr->rd1_simd(rb.bits.rd1);
	}
	if(meta>0) {
		instr->rs2_simd(meta-1);
	}	
	instr->macro(1);
	
//macro decode
	SL2Instr *uCode;
	INT i = 0;	
	uCode = new SL2Instr;
	uCode->init(&C2_Table[c2vspel_op], 0);
	uCode->rd1_simd(rb.bits.rd1);
	if(meta>0) {
		uCode->rs1_simd(meta-1);
	}
	disasmC2_vspel_private(uCode, rb.bits.cl_indx, rb.bits.size, 0, rb.bits.sl_indx);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	uCode->init(&C2_Private_Table[c2pspadd_op], 0);
	uCode->rs1_simd(rb.bits.rs1); ///*** Changes WWD
	uCode->rs2_simd(rb.bits.rd1);
	uCode->rd1_simd(rb.bits.rd1);
	disasmC2_pspadd_private(uCode, rb.bits.size, rb.bits.sl_indx);
	instr->setMacro(uCode, i++);

	instr->macroCnt(i);		
	return INT32_BYTE;		
}

// VMULT
UINT32 SL2Decoder::decodeC2_mmul (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned sl_indx : 4;
			unsigned op_mode : 3;
			unsigned size : 1;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->sl_indx(rb.bits.sl_indx);
	instr->op_mode(rb.bits.op_mode);
	instr->size(rb.bits.size);
	if(rb.bits.size) {
		instr->rd1_simd_pair(rb.bits.rd1);
	}
	else {
		instr->rd1_simd(rb.bits.rd1);
	}
	instr->rs1_simd(rb.bits.rs1);
	instr->rs2_simd(rb.bits.rs2);
	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_vcopy (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned na2 : 8;
			unsigned rs2 : 5;
			unsigned na1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->rs2_simd(rb.bits.rs2);
	instr->rd1_simd(rb.bits.rd1);

	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_vmov (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned sl_indx : 7;
			unsigned mov_pat : 1;
			unsigned rs2 : 5;
			unsigned rev_pat : 1;
			unsigned na : 4;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
	instr->mov_pat(rb.bits.mov_pat);
	instr->sl_indx(rb.bits.sl_indx);
	instr->rev_pat(rb.bits.rev_pat);
	instr->rs2_simd(rb.bits.rs2);
	instr->rd1_simd(rb.bits.rd1);
	if(rb.bits.mov_pat==1) {
		instr->c2spec1(ERS_READ, EC2SPEC_MOV_PAT);
	}
	return INT32_BYTE;
}

UINT32 SL2Decoder::decodeC2_vmul (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned na : 7;
			unsigned size : 1;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
	instr->size(rb.bits.size);
	instr->rs2_simd(rb.bits.rs2);
	instr->rs1_simd(rb.bits.rs1);
	if(rb.bits.size==1){
		instr->rd1_simd_pair(rb.bits.rd1);		
	}	
	else {
		instr->rd1_simd(rb.bits.rd1);
	}	
	return INT32_BYTE;
}

//VADD
UINT32 SL2Decoder::decodeC2_lczero (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned zero : 1;
			unsigned na2 : 6;
			unsigned dir : 1;
			unsigned na1 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->zero(rb.bits.zero);
	instr->dir(rb.bits.dir);
	//instr->acc(rb.bits.kp_acc, EC2ACC_SIMD_ACC);
	instr->rs1_simd(rb.bits.rs1);
	instr->rd1_simd(rb.bits.rd1);
	// internal reg zero_cnt
	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_vadds (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned shft_mode : 3;
			unsigned carry : 1;
			unsigned in_pair : 1;
			unsigned na1 : 2;
			unsigned size : 1;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->size(rb.bits.size);
	instr->shft_mode(rb.bits.shft_mode);
	instr->carry(rb.bits.carry);
	instr->in_pair(rb.bits.in_pair);
	if(rb.bits.in_pair==1||rb.bits.size==1){
		instr->rd1_simd_pair(rb.bits.rd1);
		instr->rs1_simd_pair(rb.bits.rs1);
		instr->rs2_simd_pair(rb.bits.rs2);		
	}
	else {
		instr->rd1_simd(rb.bits.rd1);
		instr->rs1_simd(rb.bits.rs1);
		instr->rs2_simd(rb.bits.rs2);
	}
	if((rb.bits.shft_mode&0x2)>0) {
		instr->c2cs1(EC2CR_DCAC_SHFT);
	}
	else
		if((rb.bits.shft_mode&0x2) == 0){
			instr->c2cs1(EC2CR_VADD_SHFT);
	}
	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_vclg (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op_mode : 4;
			unsigned in_pair : 1;
			unsigned na1 : 2;
			unsigned size : 1;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->op_mode(rb.bits.op_mode);
	instr->in_pair(rb.bits.in_pair);
	instr->size(rb.bits.size);
	if(rb.bits.in_pair==1) {
		instr->rs1_simd_pair(rb.bits.rs1);
		if(rb.bits.op_mode>=0xc) {
			instr->rd1_simd_pair(rb.bits.rd1);
		}
		else {
			AppFatal((0), ("Do not such mode [%01x] in pair mode from ISA2.6.\n", rb.bits.op_mode));
			//instr->rd1_simd(rb.bits.rd1);
		}
	}
	else{
		instr->rd1_simd(rb.bits.rd1);
		if(rb.bits.op_mode<0xc) {
			if(rb.bits.size==1) {
				instr->rs1_simd_pair(rb.bits.rs1);
				instr->rs2_simd_pair(rb.bits.rs2);
			}
			else {
				instr->rs1_simd(rb.bits.rs1);
				instr->rs2_simd(rb.bits.rs2);				
			}
		}
		else {
			if(rb.bits.size==1) {
				instr->rs1_simd_pair(rb.bits.rs1);
			}	
			else {
				instr->rs1_simd(rb.bits.rs1);
			}		
		}
	}
	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_vclp (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op_mode : 3;
			unsigned na2 : 1;
			unsigned in_pair : 1;
			unsigned na1 : 3;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->op_mode(rb.bits.op_mode);
	instr->in_pair(rb.bits.in_pair);
	if(rb.bits.op_mode>0){
		instr->rs2_simd(rb.bits.rs2);
	}
	if(rb.bits.in_pair==1){
		instr->rd1_simd_pair(rb.bits.rd1);
		instr->rs1_simd_pair(rb.bits.rs1);
	}
	else {
		instr->rs1_simd(rb.bits.rs1);
		instr->rd1_simd(rb.bits.rd1);
	}
	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_vcmov (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned cmp_bit : 1;
			unsigned na : 6;
			unsigned size : 1;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->size(rb.bits.size);
	instr->cmp_bit(rb.bits.cmp_bit);
	instr->rs1_simd(rb.bits.rs1);
	if(rb.bits.size==1){
		instr->rd1_simd_pair(rb.bits.rd1);
		instr->rs2_simd_pair(rb.bits.rs2);
	}
	else {
		instr->rs2_simd(rb.bits.rs2);
		instr->rd1_simd(rb.bits.rd1);
	}
	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_vcmpr (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned eq : 1;
			unsigned lt : 1;
			unsigned gt : 1;
			unsigned na : 4;
			unsigned size : 1;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->size(rb.bits.size);
	instr->eq(rb.bits.eq);
	instr->lt(rb.bits.lt);
	instr->gt(rb.bits.gt);
	instr->rd1_simd(rb.bits.rd1);
	if(rb.bits.size==1){
		instr->rs1_simd_pair(rb.bits.rs1);
		instr->rs2_simd_pair(rb.bits.rs2);
	}
	else {
		instr->rs1_simd(rb.bits.rs1);
		instr->rs2_simd(rb.bits.rs2);
	}
	return INT32_BYTE;	
}

UINT32 SL2Decoder::decodeC2_vneg (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned na2 : 4;
			unsigned in_pair : 1;
			unsigned na1 : 2;
			unsigned size : 1;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
	instr->in_pair(rb.bits.in_pair);
	instr->size(rb.bits.size);
	if(rb.bits.size==1||rb.bits.in_pair==1){
		instr->rs2_simd_pair(rb.bits.rs2);
		instr->rs1_simd_pair(rb.bits.rs1);
		instr->rd1_simd_pair(rb.bits.rd1);		
	}	
	else {
		instr->rs2_simd(rb.bits.rs2);
		instr->rs1_simd(rb.bits.rs1);
		instr->rd1_simd(rb.bits.rd1);
	}
	return INT32_BYTE;
}

UINT32 SL2Decoder::decodeC2_vrnd (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op_mode : 3;
			unsigned na2 : 4;
			unsigned size : 1;
			unsigned na1 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();
	instr->op_mode(rb.bits.op_mode);
	instr->size(rb.bits.size);
	instr->rd1_simd(rb.bits.rd1);		
	if(rb.bits.size==1){
		instr->rs1_simd_pair(rb.bits.rs1);
	}
	else {
		instr->rs1_simd(rb.bits.rs1);
	}
	return INT32_BYTE;		
}


UINT32 SL2Decoder::decodeC2_vshft (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned shft_amnt : 4;
			unsigned in_pair : 1;
			unsigned dir : 1;			
			unsigned na2 : 1;
			unsigned size : 1;
			unsigned na1 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->shft_amnt(rb.bits.shft_amnt);
	instr->size(rb.bits.size);
	instr->in_pair(rb.bits.in_pair);
	instr->dir(rb.bits.dir);

	if(rb.bits.size==1||rb.bits.in_pair==1) {
		instr->rs1_simd_pair(rb.bits.rs1);
		instr->rd1_simd_pair(rb.bits.rd1);
	}
	else {
		instr->rs1_simd(rb.bits.rs1);
		instr->rd1_simd(rb.bits.rd1);
	}
	return INT32_BYTE;	
}

UINT32 SL2Decoder::decodeC2_vspas (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned shft_amnt : 2;
			unsigned na : 6;
			unsigned imm5 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	UINT uimm;
	rb.rawbits = instr->rawbits();	
	instr->shft_amnt(rb.bits.shft_amnt);
	uimm = rb.bits.imm5;
	instr->imm5(uimm);
	
	instr->rs1_simd_pair(rb.bits.rs1);
	instr->rd1_simd_pair(rb.bits.rd1);
	return INT32_BYTE;	
}

UINT32 SL2Decoder::decodeC2_vsubs (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned shf_mode : 2;
			unsigned op_mode : 2;
			unsigned in_pair : 1;
			unsigned dir : 1;
			unsigned na : 1;
			unsigned size : 1;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->op_mode(rb.bits.op_mode);
	instr->shft_mode(rb.bits.shf_mode);
	instr->in_pair(rb.bits.in_pair);
	instr->size(rb.bits.size);
	instr->dir(rb.bits.dir);
	if(rb.bits.in_pair==1||rb.bits.size==1){
		instr->rd1_simd_pair(rb.bits.rd1);
		instr->rs1_simd_pair(rb.bits.rs1);
		instr->rs2_simd_pair(rb.bits.rs2);
	}
	else {
		instr->rs1_simd(rb.bits.rs1);
		instr->rs2_simd(rb.bits.rs2);
		instr->rd1_simd(rb.bits.rd1);
	}
	if((rb.bits.shf_mode&0x2)>0) {
		instr->c2cs1(EC2CR_VADD_SHFT);
	}
	return INT32_BYTE;		
	
}

//MULT
UINT32 SL2Decoder::decodeC2_muls (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned rs3 : 5;
			unsigned dir : 1;
			unsigned opd_shft : 2;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->rs3(rb.bits.rs3);
	instr->opd_shft(rb.bits.opd_shft);
	instr->dir(rb.bits.dir);
	instr->rs2(rb.bits.rs2);
	instr->rs1(rb.bits.rs1);
	instr->rd(rb.bits.rd1);
	return INT32_BYTE;		
}



//ADD
UINT32 SL2Decoder::decodeC2_adds (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned shft_amnt : 2;
			unsigned dir : 1;
			unsigned carry : 1;
			unsigned gpr : 1;
			unsigned imm1 : 1;
			unsigned opd_shft : 1;
			unsigned size : 1;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->shft_amnt(rb.bits.shft_amnt);
	instr->dir(rb.bits.dir);
	instr->carry(rb.bits.carry);
	instr->imm1(rb.bits.imm1);
	instr->gpr(rb.bits.gpr);
	instr->size(rb.bits.size);
	instr->opd_shft(rb.bits.opd_shft);

	if(rb.bits.gpr==0) {
		if(rb.bits.size==1) {
			instr->rd1_simd_pair(rb.bits.rd1);
			instr->rs1_simd_pair(rb.bits.rs1);
			if(rb.bits.imm1==0) {
				instr->rs2_simd_pair(rb.bits.rs2);
			}
		}
		else{
			instr->rs1_simd(rb.bits.rs1);
			instr->rd1_simd(rb.bits.rd1);
			if(rb.bits.imm1==0) {
				instr->rs2_simd(rb.bits.rs2);
			}			
		}
		instr->c2cs1(EC2CR_ADD_CTRL);
	}
	else {
		instr->rs1(rb.bits.rs1);
		instr->rd(rb.bits.rd1);
		if(rb.bits.imm1==0) {
			instr->rs2(rb.bits.rs2);
		}	
	}
	
	if(rb.bits.imm1==1) {
		instr->rs2_imm(rb.bits.rs2);
	}
	
	return INT32_BYTE;			
}

UINT32 SL2Decoder::decodeC2_bcst (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned shft : 1;
			unsigned na : 12;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->shft(rb.bits.shft);
	instr->rd(rb.bits.rd1);
	instr->rs1(rb.bits.rs1);
	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_chkrng (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned lo_indx : 3;
			unsigned na : 5;
			unsigned hi_indx : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->lo_indx(rb.bits.lo_indx);
	instr->hi_indx(rb.bits.hi_indx);
	instr->rd(rb.bits.rd1);
	instr->rs1(rb.bits.rs1);
	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_cmov (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned rs3 : 5;
			unsigned na : 3;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->rd(rb.bits.rd1);
	instr->rs1(rb.bits.rs1);
	instr->rs2(rb.bits.rs2);
	instr->rs3(rb.bits.rs3);
	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_clp (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned rs3 : 5;
			unsigned imm1 : 1;
			unsigned na : 2;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->imm1(rb.bits.imm1);
	instr->rd(rb.bits.rd1);
	instr->rs1(rb.bits.rs1);
	if(rb.bits.imm1==0)
		instr->rs2_imm(rb.bits.rs2);
	else
		instr->rs2(rb.bits.rs2);
	instr->rs3(rb.bits.rs3);
	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_med (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned rs3 : 5;
			unsigned na : 3;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->rd(rb.bits.rd1);
	instr->rs1(rb.bits.rs1);
	instr->rs2(rb.bits.rs2);
	instr->rs3(rb.bits.rs3);
	instr->macro(1);

//macro decode
	SL2Instr *uCode;
	INT i = 0;	
	uCode = new SL2Instr;
	uCode->init(&C2_Private_Table[c2pmedc_op], 0);
	uCode->rs1(rb.bits.rs1);
	uCode->rs2(rb.bits.rs2);
	uCode->rs3(rb.bits.rs3);
	uCode->rd(rb.bits.rd1);
	decodeC2_pmedc_private(uCode, 0);
	instr->setMacro(uCode, i++);

	uCode = new SL2Instr;
	uCode->init(&C2_Private_Table[c2pmedc_op], 0);
	uCode->rs1(rb.bits.rs1);
	uCode->rs2(rb.bits.rs2);
	uCode->rs3(rb.bits.rs3);
	uCode->rd(rb.bits.rd1);
	decodeC2_pmedc_private(uCode, 1);
	instr->setMacro(uCode, i++);
	
	instr->macroCnt(i);	
	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_scond (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned eq : 1;
			unsigned lt : 1;
			unsigned gt : 1;
			unsigned wr_back : 1;
			unsigned gpr : 1;
			unsigned imm1 : 1;
			unsigned na2 : 1;
			unsigned size : 1; // Add in ISA2.8
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->eq(rb.bits.eq);
	instr->lt(rb.bits.lt);
	instr->gt(rb.bits.gt);
	instr->wr_back(rb.bits.wr_back);
	instr->imm1(rb.bits.imm1);
	instr->gpr(rb.bits.gpr);
	instr->c2spec1(ERS_WRITE, EC2SPEC_COND);

	if(rb.bits.wr_back==1) {
		instr->rd(rb.bits.rd1);
	}
	
	if(rb.bits.gpr==1) {
		instr->rs1(rb.bits.rs1);
		if(rb.bits.imm1==0) {
			instr->rs2(rb.bits.rs2);
		}
		else {
			instr->rs2_imm(rb.bits.rs2);
		}
	}
	else {
		instr->c2cs1(EC2CR_ADD_CTRL);
		instr->size(rb.bits.size);
		//instr->rs1_simd(rb.bits.rs1);
		if(rb.bits.size==1) {
			instr->rs1_simd_pair(rb.bits.rs1);
		}
		else {
			instr->rs1_simd(rb.bits.rs1);
		}
		
		if(rb.bits.imm1==1) {
			instr->rs2_imm(rb.bits.rs2);
		}
		else {
			//instr->rs2_imm(rb.bits.rs2);
			if(rb.bits.size==1) {
				instr->rs2_simd_pair(rb.bits.rs2);
			}
			else {
				instr->rs2_simd(rb.bits.rs2);
			}			
		}
	}
	return INT32_BYTE;		
}


UINT32 SL2Decoder::decodeC2_subs (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned shft_amnt : 3;
			unsigned abs : 1;
			unsigned gpr : 1;
			unsigned imm1 : 1;
			unsigned na1 : 1;
			unsigned size : 1;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->shft_amnt(rb.bits.shft_amnt);
	instr->abs(rb.bits.abs);
	instr->imm1(rb.bits.imm1);
	instr->gpr(rb.bits.gpr);
	instr->size(rb.bits.size);
	
	if(rb.bits.gpr==0) {
		instr->c2cs1(EC2CR_ADD_CTRL);
		if(rb.bits.size==1) {
			instr->rd1_simd_pair(rb.bits.rd1);
			instr->rs1_simd_pair(rb.bits.rs1);
			if(rb.bits.imm1==0) {
				instr->rs2_simd_pair(rb.bits.rs2);
			}			
		}
		else {
			instr->rs1_simd(rb.bits.rs1);
			instr->rd1_simd(rb.bits.rd1);
			if(rb.bits.imm1==0) {
				instr->rs2_simd(rb.bits.rs2);
			}				
		}
	}
	else {
		instr->rs1(rb.bits.rs1);
		instr->rd(rb.bits.rd1);
		if(rb.bits.imm1==0) {
			instr->rs2(rb.bits.rs2);
		}		
	}
	if(rb.bits.imm1==1) {
		instr->rs2_imm(rb.bits.rs2);
	}
	return INT32_BYTE;		
}


//BIT
UINT32 SL2Decoder::decodeC2_bdep (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned na3 : 5;
			unsigned na2 : 1;
			unsigned lsb : 1;
			unsigned na1 : 1;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->lsb(rb.bits.lsb);

	instr->rd(rb.bits.rd1);
	instr->rs1(rb.bits.rs1);
	instr->rs2(rb.bits.rs2);
	//instr->rs3(rb.bits.rs3);
	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_bop (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op_mode : 2;
			unsigned dir : 1;
			unsigned na2 : 2;
			unsigned imm1 : 1;
			unsigned na1 : 2;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->op_mode(rb.bits.op_mode);
	instr->dir(rb.bits.dir);
	instr->imm1(rb.bits.imm1);
	if(rb.bits.imm1==0) {
		instr->rs2(rb.bits.rs2);
	}
	else {
		instr->rs2_imm(rb.bits.rs2);
	}
	instr->rd(rb.bits.rd1);
	instr->rs1(rb.bits.rs1);
	return INT32_BYTE;	
}


UINT32 SL2Decoder::decodeC2_bxtr (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned rs3 : 5;
			unsigned sign_ext : 1;
			unsigned lsb : 1;
			unsigned na : 1;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->sign_ext(rb.bits.sign_ext);
	instr->lsb(rb.bits.lsb);
	instr->rd(rb.bits.rd1);
	instr->rs1(rb.bits.rs1);
	instr->rs2(rb.bits.rs2);
	instr->rs3(rb.bits.rs3);
	return INT32_BYTE;	
}

UINT32 SL2Decoder::decodeC2_clzob (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op_mode : 2;
			unsigned na2 : 3;
			unsigned imm : 1;
			unsigned na : 2;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->rd(rb.bits.rd1);
	instr->rs1(rb.bits.rs1);
	instr->imm1(rb.bits.imm);
	instr->op_mode(rb.bits.op_mode);
	if(rb.bits.imm)
		instr->rs2_imm(rb.bits.rs2);
	else
		instr->rs2(rb.bits.rs2);
	return INT32_BYTE;	
}


//SUM4
ADDR SL2Decoder::decodeC2_gsum4s (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned imm5 : 5;
			unsigned shft_amnt : 3;
			unsigned rs2 : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	UINT uimm;
	rb.rawbits = instr->rawbits();	
	uimm = rb.bits.imm5;
	instr->imm5(uimm);
	instr->rs1(rb.bits.rs1);
	instr->rs2(rb.bits.rs2);
	instr->rd(rb.bits.rd1);
	instr->shft_amnt(rb.bits.shft_amnt);
	return INT32_BYTE;	
}

UINT32 SL2Decoder::decodeC2_sum4 (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned rs3 : 5;
			unsigned op_mode : 3;//JQ: changed from 2 to 3
		//	unsigned na : 1;
			unsigned rs2_bank : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->op_mode(rb.bits.op_mode);
	switch(rb.bits.op_mode) {
		case 0:
//			instr->acc(TRUE, EC2ACC_SUM);
			instr->rs1_simd(rb.bits.rs1);
			instr->bank(rb.bits.rs2_bank);
			break;
		case 1:
		case 2:
			instr->rs1_simd(rb.bits.rs1);
			instr->bank(rb.bits.rs2_bank);
			instr->rd(rb.bits.rd1);
			break;		
		case 3:
			instr->rs1_simd(rb.bits.rs1);
			instr->rs2_simd(rb.bits.rs2_bank);
			instr->rs3_simd(rb.bits.rs3);
			instr->c2cs1(EC2CR_SUM_CTRL);
//			instr->acc(FALSE, EC2ACC_SUM);
			instr->rd1_simd(rb.bits.rd1);
			break;		
		case 4:
			instr->rs1(rb.bits.rs1);
			instr->rs2(rb.bits.rs2_bank);
			instr->rs3(rb.bits.rs3);
			instr->rd(rb.bits.rd1);
			break;		
		default:
			AppFatal((0), ("SL2Decoder: Invalid c2.sum4 op_mode (%d).", rb.bits.op_mode));
			break;
	}
	return INT32_BYTE;		
}

UINT32 SL2Decoder::decodeC2_mov (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned dstbank : 5;
			unsigned op_mode : 3;
			unsigned srcbank : 5;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->op_mode(rb.bits.op_mode);
	instr->bank(rb.bits.srcbank);
	switch(rb.bits.op_mode) {
		case 0:
			instr->rs1(rb.bits.rs1);
			instr->rd(rb.bits.rd1);
			break;			
		case 1:
			instr->c2cs1(EC2CR_SUM_CTRL);
			instr->rs1_simd(rb.bits.rs1);
			instr->rd1_simd(rb.bits.rd1);
			break;
		case 2:
//			instr->acc(TRUE, EC2ACC_SUM);
			instr->rs1_simd(rb.bits.rs1);
			break;		
		case 3:
//			instr->acc(TRUE, EC2ACC_SUM);
			instr->rs1_simd(rb.bits.rs1);
			//instr->c2cs1(EC2CR_SUM_CTRL);
			break;
		case 4:
			instr->dstbank(rb.bits.dstbank);
			instr->rs1_simd(rb.bits.rs1);
			instr->rd1_simd(rb.bits.rd1);
			break;
		case 5:
			instr->dstbank(rb.bits.dstbank);
			instr->rs1_simd(rb.bits.rs1);
			instr->rd1_simd(rb.bits.rd1);
			break;	
		default:
			AppFatal((0), ("SL2Decoder: Invalid c2.mov op_mode (%d).", rb.bits.op_mode));
			break;	
	}
	return INT32_BYTE;			
}


// VLCS
UINT32 SL2Decoder::decodeC2_vlcs (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned na2 : 5;
			unsigned op_mode : 2;
			unsigned na1 : 6;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	UBYTE op_mode = rb.bits.op_mode;
	instr->op_mode(op_mode);
	if((op_mode&1)==0) {
		instr->rs1_simd(rb.bits.rs1);
		instr->rd1_simd_pair(rb.bits.rd1);
	}
	else {
		instr->rd(rb.bits.rd1);
	}
	
	return INT32_BYTE;
}

// THCTRL
UINT32 SL2Decoder::decodeC2_thctrl (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned op_mode : 3;
			unsigned thread : 2;
			unsigned na : 18;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->op_mode(rb.bits.op_mode);
	instr->thread(rb.bits.thread);
	
	return INT32_BYTE;
}

// PRRET
UINT32 SL2Decoder::decodeC2_prret  (SL2Instr* instr, UINT meta) {
	union {
		WORD rawbits;
		struct {
			unsigned na : 13;
			unsigned rs1 : 5;
			unsigned rd1 : 5;
			unsigned op : 6;
			unsigned top :3;
		} bits;
	}rb;
	rb.rawbits = instr->rawbits();	
	instr->rd(rb.bits.rd1);
	instr->rs1(rb.bits.rs1);
	return INT32_BYTE;	
}

